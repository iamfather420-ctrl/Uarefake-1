import { readFileSync } from "node:fs";
import { verifyReceipt } from "../engine/proof-engine.mjs";

const file = process.argv[2];
if (!file) {
  console.error("Usage: node scripts/verify-receipt.mjs receipt.json");
  process.exit(2);
}
const receipt = JSON.parse(readFileSync(file, "utf8"));
const result = verifyReceipt(receipt);
console.log(result.ok ? "VERIFIED" : "FAIL CLOSED");
console.log(result.reason);
process.exit(result.ok ? 0 : 1);
