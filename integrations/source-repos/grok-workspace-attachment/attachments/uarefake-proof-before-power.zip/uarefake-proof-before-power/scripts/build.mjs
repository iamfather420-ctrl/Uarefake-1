import { cp, mkdir, rm } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const dist = join(root, "dist");
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
for (const name of ["public", "engine", "agents", "adapters", "scripts", "server.mjs", "package.json", "README.md", "JUDGE-SCRIPT.md", "VIDEO-SHOT-LIST.md", "SOCIAL-POST.md", "SUBMISSION.md"]) {
  await cp(join(root, name), join(dist, name), { recursive: true });
}
console.log("built", dist);
