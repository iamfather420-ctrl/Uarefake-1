import { judgeScorecard } from "../engine/scorecard.mjs";

const card = judgeScorecard(1_700_000_000_000);
console.log(card.score);
for (const check of card.checks) console.log(`${check.pass ? "PASS" : "FAIL"}  ${check.id}`);
if (card.passed !== card.total) process.exit(1);
