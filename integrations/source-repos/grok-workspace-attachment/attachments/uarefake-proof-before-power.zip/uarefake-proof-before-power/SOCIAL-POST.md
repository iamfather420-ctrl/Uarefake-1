Daisy can propose a production update. She cannot run it.

I built the gate because a plausible tool call was being treated as permission. The unsafe call now returns REFUSE, the tool does not run, a forged token fails, and a tampered receipt fails outside the screen.

Proof before power. The refusal is the product.
