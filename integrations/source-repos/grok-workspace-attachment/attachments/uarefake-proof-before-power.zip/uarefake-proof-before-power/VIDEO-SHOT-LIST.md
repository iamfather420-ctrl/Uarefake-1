# Record this. Do not narrate the old film alone.

1. Open on the old walkthrough: a button advances a story, and the proof is a paragraph.
2. Cut to this cockpit. Press Daisy Haminja, act. Read the line: tool not invoked.
3. Press Run the 8 checks. Leave the frame on 8/8.
4. Sign, execute, reverse.
5. Tamper one field. Run node scripts/verify-receipt.mjs on the file outside the browser. Show FAIL CLOSED.
6. Say, in your own voice, why you refused to let the model grade the action.

The before-and-after is the 24-hour score. The 8/8 card is the execution score. Your voice is the story score.
