# Solvex Production Release Readiness

## Hardening gate

`npm run verify:hardening` must report **10/10 PASS** before release. The gate covers:

1. Platform-admin-only rollback
2. Global HTTP body-size enforcement
3. Distributed per-order payment lease
4. Stable PayPal provider idempotency
5. Mandatory Neon persistence in production
6. Platform-admin-only global offer publication
7. No persistent GitHub OAuth token in `localStorage`
8. ZIP traversal/decompression-bomb defenses
9. PayPal amount/currency validation
10. Compiled production server startup

## Production build contract

```text
npm ci
npm run lint
npm run build
npm run verify:hardening
npm run verify:all
NODE_ENV=production npm start
```

Production requires `NEON_DATABASE_URL` and `SOLVEX_AUTH_SECRET` (32+ characters). Live PayPal execution is fail-closed unless durable payment evidence and the distributed order lease are available.

The release archive must also be accompanied by its SHA-256 checksum.
