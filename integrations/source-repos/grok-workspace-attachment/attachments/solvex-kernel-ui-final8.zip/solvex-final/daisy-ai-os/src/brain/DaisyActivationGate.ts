/**
 * Activation gate — computed from LIVE state, never hardcoded.
 *
 * ACTIVE only when the Solvex core is reachable and its Pipeline Kernel reports
 * state=running with every node process online. Anything else is INACTIVE (fail-closed).
 *
 * The verification corpus is reported separately and honestly: the presence and hash of
 * the evidence artifact are shown, but this runtime does NOT re-execute the 120-case /
 * 46-gate suite, so it never claims those as verified.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { CoreClient } from '../native-os/core/CoreClient.ts';

export type DaisyActivationStatus = 'INACTIVE' | 'ACTIVE' | 'BLOCKED';

export interface DaisyActivationGateRecord {
  schema_version: '2.0.0';
  status: DaisyActivationStatus;
  reason: string;
  core: { reachable: boolean; kernel_state: string | null; nodes_online: number; nodes_total: number };
  verification: {
    artifact_present: boolean;
    artifact_sha256: string | null;
    re_executed_in_this_runtime: false;
    note: string;
  };
  generated_at: string;
}

export class DaisyActivationGate {
  private core: CoreClient;
  private root: string;

  constructor(core: CoreClient, root: string) {
    this.core = core;
    this.root = root;
  }

  private artifact(): DaisyActivationGateRecord['verification'] {
    const p = path.join(this.root, 'artifacts', 'COMPLETE-VERIFICATION-REPORT.json');
    let present = false;
    let sha: string | null = null;
    try {
      const buf = fs.readFileSync(p);
      present = true;
      sha = createHash('sha256').update(buf).digest('hex');
    } catch { /* absent */ }
    return {
      artifact_present: present,
      artifact_sha256: sha,
      re_executed_in_this_runtime: false,
      note: 'Evidence file exists but was not re-run here. Regenerate with the verify:* scripts before relying on it.',
    };
  }

  async read(): Promise<DaisyActivationGateRecord> {
    const r = await this.core.get<any>('/api/kernel/status');
    const k = r.data;
    const core = {
      reachable: r.reachable && r.status === 200,
      kernel_state: k?.state ?? null,
      nodes_online: Number(k?.nodes?.online ?? 0),
      nodes_total: Number(k?.nodes?.total ?? 0),
    };
    let status: DaisyActivationStatus = 'INACTIVE';
    let reason = 'Solvex core unreachable';
    if (core.reachable) {
      if (core.kernel_state === 'running' && core.nodes_total > 0 && core.nodes_online === core.nodes_total) {
        status = 'ACTIVE';
        reason = `Kernel running, ${core.nodes_online}/${core.nodes_total} node processes online`;
      } else if (core.kernel_state === 'error') {
        status = 'BLOCKED';
        reason = 'Kernel reported error state';
      } else {
        reason = `Kernel ${core.kernel_state}, ${core.nodes_online}/${core.nodes_total} nodes online`;
      }
    }
    return {
      schema_version: '2.0.0',
      status,
      reason,
      core,
      verification: this.artifact(),
      generated_at: new Date().toISOString(),
    };
  }

  async assertActive(): Promise<DaisyActivationGateRecord> {
    const rec = await this.read();
    if (rec.status !== 'ACTIVE') throw new Error(`DAISY_FAIL_CLOSED: activation gate is ${rec.status} (${rec.reason})`);
    return rec;
  }
}
