/**
 * AI-OS NATIVE BRANCH — Process layer
 * Tracks REAL OS processes: this shell itself, plus children it spawns.
 * Spawning is restricted to Node scripts located inside the project root.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import path from 'node:path';
import type { PlatformTarget, ProcessHandle } from '../types.ts';

export class ProcessLayer {
  private handles = new Map<string, ProcessHandle>();
  private children = new Map<string, ChildProcess>();
  private seq = 0;
  private root: string;
  private platform: PlatformTarget;

  constructor(root: string, platform: PlatformTarget = 'linux') {
    this.root = path.resolve(root);
    this.platform = platform;
    this.handles.set('self', {
      pid: 'self',
      os_pid: process.pid,
      name: 'daisy-os-shell',
      status: 'running',
      started_at: new Date().toISOString(),
      platform,
    });
  }

  spawnScript(name: string, scriptRel: string, args: string[] = []): ProcessHandle {
    const script = path.resolve(this.root, scriptRel);
    if (!script.startsWith(this.root + path.sep) || !/\.(mjs|js|ts)$/.test(script)) {
      throw new Error('spawn refused: script must be a .mjs/.js/.ts file inside the project root');
    }
    const child = spawn(process.execPath, ['--experimental-strip-types', script, ...args], { stdio: 'ignore' });
    this.seq += 1;
    const handle: ProcessHandle = {
      pid: `p${this.seq}`,
      os_pid: child.pid,
      name,
      status: 'running',
      started_at: new Date().toISOString(),
      platform: this.platform,
    };
    this.handles.set(handle.pid, handle);
    this.children.set(handle.pid, child);
    child.on('exit', () => { handle.status = 'stopped'; this.children.delete(handle.pid); });
    child.on('error', () => { handle.status = 'zombie'; });
    return handle;
  }

  stop(pid: string): boolean {
    const child = this.children.get(pid);
    if (!child) return false;
    child.kill('SIGTERM');
    return true;
  }

  stopAll(): void {
    for (const c of this.children.values()) c.kill('SIGTERM');
  }

  list(): ProcessHandle[] {
    return [...this.handles.values()];
  }
}
