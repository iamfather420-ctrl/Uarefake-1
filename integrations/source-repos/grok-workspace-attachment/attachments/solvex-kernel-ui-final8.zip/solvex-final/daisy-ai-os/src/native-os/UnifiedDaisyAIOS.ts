/**
 * Unified Daisy AI OS — composition root.
 * An application-level AI shell: permissioned tools + live gate + LLM agent,
 * supervising the Solvex core. It is NOT a host-OS kernel.
 */
import path from 'node:path';
import type { PlatformTarget } from './types.ts';
import { DaisyRuntime } from './runtime/DaisyRuntime.ts';
import { ProcessLayer } from './process/ProcessLayer.ts';
import { PermissionKernel } from './permissions/PermissionKernel.ts';
import { SystemTools } from './system-tools/SystemTools.ts';
import { CoreClient } from './core/CoreClient.ts';
import { DaisyActivationGate } from '../brain/DaisyActivationGate.ts';
import { DaisyAgent, llmConfigFromEnv, type LlmConfig } from '../brain/DaisyAgent.ts';

export interface OsOptions {
  coreUrl?: string;
  root?: string;
  platform?: PlatformTarget;
  llm?: LlmConfig | null;
}

export class UnifiedDaisyAIOS {
  readonly runtime: DaisyRuntime;
  readonly processes: ProcessLayer;
  readonly permissions: PermissionKernel;
  readonly core: CoreClient;
  readonly tools: SystemTools;
  readonly gate: DaisyActivationGate;
  readonly agent: DaisyAgent;
  readonly root: string;

  constructor(opts: OsOptions = {}) {
    this.root = path.resolve(opts.root ?? path.join(import.meta.dirname, '..', '..', '..'));
    const platform = opts.platform ?? 'linux';
    this.core = new CoreClient(opts.coreUrl ?? process.env.DAISY_CORE_URL ?? 'http://127.0.0.1:3000');
    this.runtime = new DaisyRuntime(platform);
    this.processes = new ProcessLayer(this.root, platform);
    this.permissions = new PermissionKernel();
    this.tools = new SystemTools(this.permissions, this.processes, this.core, this.root);
    this.gate = new DaisyActivationGate(this.core, this.root);
    this.agent = new DaisyAgent(this.tools, opts.llm === undefined ? llmConfigFromEnv() : opts.llm);
  }

  /** Evaluate the live gate and set runtime activation from it. */
  async activate() {
    const gate = await this.gate.read();
    this.runtime.setActivation(gate.status);
    return { os: 'Daisy AI OS', runtime: this.runtime.snapshot(), gate, processes: this.processes.list() };
  }

  async status() {
    return this.activate();
  }
}
