/**
 * AI-OS NATIVE BRANCH — System tools
 * Every tool does real work against the real host / the real Solvex core.
 * No canned results: if something is unreachable the result says so.
 */
import fs from 'node:fs';
import path from 'node:path';
import { PermissionKernel, TOOL_RISK, type Subject } from '../permissions/PermissionKernel.ts';
import { ProcessLayer } from '../process/ProcessLayer.ts';
import { CoreClient } from '../core/CoreClient.ts';

export type ToolId =
  | 'fs_list' | 'proc_status' | 'mem_summary' | 'audit_tail'
  | 'node_ping' | 'grid_status' | 'node_diagnostic' | 'node_reboot';

export interface ToolResult {
  ok: boolean;
  tool: string;
  result: unknown;
  message: string;
  needs_approval?: boolean;
}

export const TOOL_DOCS: Record<ToolId, string> = {
  fs_list: 'List a directory inside the project. args: { path?: string }',
  proc_status: 'List OS processes managed by this shell. args: {}',
  mem_summary: 'Memory usage of the shell process (bytes). args: {}',
  audit_tail: 'Most recent permission/audit entries. args: { n?: number }',
  node_ping: 'Is the Solvex core reachable, and what is the kernel state? args: {}',
  grid_status: 'Live status of the 54 pipeline nodes (pid, port, health). args: {}',
  node_diagnostic: 'Run a live health probe against one node. args: { id: "DN-02" }',
  node_reboot: 'Kill and respawn one node process (needs operator approval). args: { id: "DN-02" }',
};

export class SystemTools {
  private permissions: PermissionKernel;
  private processes: ProcessLayer;
  private core: CoreClient;
  private root: string;

  constructor(permissions: PermissionKernel, processes: ProcessLayer, core: CoreClient, root: string) {
    this.permissions = permissions;
    this.processes = processes;
    this.core = core;
    this.root = path.resolve(root);
  }

  list(): string[] {
    return Object.keys(TOOL_RISK);
  }

  async invoke(subject: Subject | string, tool: string, args: Record<string, any> = {}, approvedByOperator = false): Promise<ToolResult> {
    const grant = this.permissions.request(subject, `tool:${tool}`, 'execute', approvedByOperator);
    if (!grant.granted) {
      const needs = subject === 'daisy' && TOOL_RISK[tool] === 'mutate';
      return { ok: false, tool, result: null, message: grant.reason, needs_approval: needs || undefined };
    }

    switch (tool as ToolId) {
      case 'fs_list': {
        const rel = String(args.path ?? '.');
        const target = path.resolve(this.root, rel);
        if (target !== this.root && !target.startsWith(this.root + path.sep)) {
          return { ok: false, tool, result: null, message: 'path escapes project root' };
        }
        try {
          const entries = fs.readdirSync(target, { withFileTypes: true }).slice(0, 200).map((d) => ({
            name: d.name,
            type: d.isDirectory() ? 'dir' : 'file',
            size: d.isFile() ? fs.statSync(path.join(target, d.name)).size : null,
          }));
          return { ok: true, tool, result: { path: path.relative(this.root, target) || '.', entries }, message: 'ok' };
        } catch (e: any) {
          return { ok: false, tool, result: null, message: String(e?.message || e) };
        }
      }
      case 'proc_status':
        return { ok: true, tool, result: { processes: this.processes.list() }, message: 'ok' };
      case 'mem_summary': {
        const m = process.memoryUsage();
        return { ok: true, tool, result: { rss: m.rss, heapUsed: m.heapUsed, heapTotal: m.heapTotal, external: m.external }, message: 'ok' };
      }
      case 'audit_tail': {
        const n = Math.max(1, Math.min(200, Number(args.n ?? 20)));
        return { ok: true, tool, result: { entries: this.permissions.list().slice(-n) }, message: 'ok' };
      }
      case 'node_ping': {
        const r = await this.core.get<any>('/api/kernel/status');
        if (!r.reachable) return { ok: false, tool, result: { reachable: false }, message: `core unreachable: ${r.error}` };
        return { ok: r.status === 200, tool, result: { reachable: true, kernel: r.data }, message: r.status === 200 ? 'ok' : `core returned ${r.status}` };
      }
      case 'grid_status': {
        const r = await this.core.get<any[]>('/api/grid/nodes');
        if (!r.reachable) return { ok: false, tool, result: { reachable: false }, message: `core unreachable: ${r.error}` };
        const nodes = Array.isArray(r.data) ? r.data : [];
        const online = nodes.filter((n: any) => n.status === 'online').length;
        return { ok: r.status === 200, tool, result: { total: nodes.length, online, nodes }, message: 'ok' };
      }
      case 'node_diagnostic':
      case 'node_reboot': {
        const id = String(args.id ?? '');
        if (!/^DN-\d{2}$/.test(id)) return { ok: false, tool, result: null, message: 'id must look like DN-02' };
        const action = tool === 'node_reboot' ? 'reboot' : 'diagnostic';
        const r = await this.core.post<any>(`/api/grid/nodes/${id}/${action}`);
        if (!r.reachable) return { ok: false, tool, result: { reachable: false }, message: `core unreachable: ${r.error}` };
        return { ok: r.status === 200 && r.data?.ok !== false, tool, result: r.data, message: r.data?.message || r.data?.detail || `core returned ${r.status}` };
      }
      default:
        return { ok: false, tool, result: null, message: 'unknown tool' };
    }
  }
}
