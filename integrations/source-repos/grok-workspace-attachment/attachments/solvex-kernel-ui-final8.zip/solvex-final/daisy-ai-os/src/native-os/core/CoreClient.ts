/**
 * Talks to the Solvex core (the root server: PipelineKernel + 54 real node processes).
 * Nothing here is simulated: if the core is down, callers get reachable=false.
 */
export interface CoreResult<T = unknown> {
  reachable: boolean;
  status: number;
  data: T | null;
  error?: string;
}

export class CoreClient {
  baseUrl: string;
  timeoutMs: number;

  constructor(baseUrl: string, timeoutMs = 4000) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.timeoutMs = timeoutMs;
  }

  async request<T = unknown>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<CoreResult<T>> {
    try {
      const res = await fetch(this.baseUrl + path, {
        method,
        headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(this.timeoutMs),
      });
      let data: unknown = null;
      const text = await res.text();
      try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
      return { reachable: true, status: res.status, data: data as T };
    } catch (e: any) {
      return { reachable: false, status: 0, data: null, error: String(e?.message || e) };
    }
  }

  get<T = unknown>(path: string) { return this.request<T>('GET', path); }
  post<T = unknown>(path: string, body?: unknown) { return this.request<T>('POST', path, body ?? {}); }
}
