/**
 * AI-OS NATIVE BRANCH — Runtime state
 * Activation is set from the live activation gate, never assumed.
 */
import type { PlatformTarget, RuntimeState, ClaimScope } from '../types.ts';

export class DaisyRuntime {
  private startedAt = Date.now();
  private state: RuntimeState;

  constructor(platform: PlatformTarget = 'linux') {
    this.state = {
      os_name: 'Daisy AI OS',
      version: '2.0.0',
      environment: 'local',
      platform,
      uptime_ms: 0,
      activation: 'INACTIVE',
    };
  }

  setActivation(a: RuntimeState['activation']): void {
    this.state.activation = a;
  }

  halt(): RuntimeState {
    this.state.activation = 'BLOCKED';
    return this.snapshot();
  }

  snapshot(): RuntimeState {
    this.state.uptime_ms = Date.now() - this.startedAt;
    return { ...this.state };
  }

  claimScope(): ClaimScope {
    return this.state.environment === 'production' ? 'PRODUCTION_VERIFIED' : 'LOCAL_VERIFIED';
  }
}
