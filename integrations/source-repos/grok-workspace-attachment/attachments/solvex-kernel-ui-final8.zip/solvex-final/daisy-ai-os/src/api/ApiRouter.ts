/**
 * Daisy OS API.
 *   GET  /api/os/status    public   live gate + runtime + process list
 *   GET  /api/os/tools     public   tool names and docs
 *   POST /api/os/tool      operator {tool, args}
 *   POST /api/os/command   operator {text}   deterministic shell commands
 *   POST /api/os/ask       operator {prompt} LLM agent (read/probe tools only)
 *   POST /api/os/approve   operator {tool, args} run an action the agent proposed
 *   GET  /api/os/audit     operator
 * "operator" = request carries `Authorization: Bearer <DAISY_OS_TOKEN>`.
 */
import { timingSafeEqual } from 'node:crypto';
import type { UnifiedDaisyAIOS } from '../native-os/UnifiedDaisyAIOS.ts';
import { TOOL_DOCS } from '../native-os/system-tools/SystemTools.ts';

export interface ApiResult {
  status: number;
  data?: unknown;
  error?: string;
  timestamp: number;
}

export class SovereignApiRouter {
  private os: UnifiedDaisyAIOS;
  private token: string;

  constructor(os: UnifiedDaisyAIOS, token: string) {
    this.os = os;
    this.token = token;
  }

  private isOperator(headers: Record<string, string | string[] | undefined>): boolean {
    const h = headers['authorization'];
    const v = Array.isArray(h) ? h[0] : h;
    if (!v) return false;
    const given = Buffer.from(v.replace(/^Bearer\s+/i, '').trim());
    const want = Buffer.from(this.token);
    return given.length === want.length && timingSafeEqual(given, want);
  }

  private parseCommand(text: string): { tool: string; args: Record<string, unknown> } | { error: string } {
    const [cmd, ...rest] = text.trim().split(/\s+/);
    const arg = rest.join(' ');
    switch ((cmd || '').toLowerCase()) {
      case 'status': case 'nodes': case 'grid': return { tool: 'grid_status', args: {} };
      case 'ping': case 'kernel': return { tool: 'node_ping', args: {} };
      case 'ls': return { tool: 'fs_list', args: { path: arg || '.' } };
      case 'mem': return { tool: 'mem_summary', args: {} };
      case 'ps': return { tool: 'proc_status', args: {} };
      case 'audit': return { tool: 'audit_tail', args: { n: Number(arg) || 20 } };
      case 'diag': return { tool: 'node_diagnostic', args: { id: arg.toUpperCase() } };
      case 'reboot': return { tool: 'node_reboot', args: { id: arg.toUpperCase() } };
      default: return { error: 'commands: status | ping | ls [path] | mem | ps | audit [n] | diag DN-xx | reboot DN-xx  (or use "ask")' };
    }
  }

  async handleRequest(
    path: string,
    method: string,
    body: any,
    headers: Record<string, string | string[] | undefined> = {},
  ): Promise<ApiResult> {
    const timestamp = Date.now();
    try {
      if (path === '/api/os/status' && method === 'GET') {
        return { status: 200, data: { ...(await this.os.status()), llm_configured: this.os.agent.isConfigured() }, timestamp };
      }
      if (path === '/api/os/tools' && method === 'GET') {
        return { status: 200, data: TOOL_DOCS, timestamp };
      }

      // everything below needs the operator token
      if (path.startsWith('/api/os/')) {
        if (!this.isOperator(headers)) return { status: 401, error: 'operator token required', timestamp };
      }

      if (path === '/api/os/tool' && method === 'POST') {
        if (!body?.tool) return { status: 400, error: 'tool required', timestamp };
        const r = await this.os.tools.invoke('operator', String(body.tool), body.args ?? {});
        return { status: r.ok ? 200 : 422, data: r, timestamp };
      }
      if (path === '/api/os/command' && method === 'POST') {
        const parsed = this.parseCommand(String(body?.text ?? ''));
        if ('error' in parsed) return { status: 400, error: parsed.error, timestamp };
        const r = await this.os.tools.invoke('operator', parsed.tool, parsed.args);
        return { status: r.ok ? 200 : 422, data: r, timestamp };
      }
      if (path === '/api/os/ask' && method === 'POST') {
        const prompt = String(body?.prompt ?? '').slice(0, 4000);
        if (!prompt) return { status: 400, error: 'prompt required', timestamp };
        return { status: 200, data: await this.os.agent.ask(prompt), timestamp };
      }
      if (path === '/api/os/approve' && method === 'POST') {
        const r = await this.os.tools.invoke('operator', String(body?.tool ?? ''), body?.args ?? {}, true);
        return { status: r.ok ? 200 : 422, data: r, timestamp };
      }
      if (path === '/api/os/audit' && method === 'GET') {
        return { status: 200, data: this.os.permissions.list().slice(-100), timestamp };
      }
      return { status: 404, error: `no route ${method} ${path}`, timestamp };
    } catch (e: any) {
      return { status: 500, error: String(e?.message || e), timestamp };
    }
  }
}
