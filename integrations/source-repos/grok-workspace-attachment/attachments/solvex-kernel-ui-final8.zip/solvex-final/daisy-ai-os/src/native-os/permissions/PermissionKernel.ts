/**
 * AI-OS NATIVE BRANCH — Permissions
 * Fail-closed, table-driven policy. Subjects are assigned by the API layer from
 * authentication (bearer token), never taken from the request body.
 *
 *   anonymous : no tools
 *   operator  : authenticated human — every tool
 *   daisy     : the AI agent — read-only tools + live diagnostics; mutating tools
 *               are refused unless the operator has explicitly approved the action
 */
import type { PermissionGrant } from '../types.ts';

export type Subject = 'anonymous' | 'operator' | 'daisy';

export const TOOL_RISK: Record<string, 'read' | 'probe' | 'mutate'> = {
  fs_list: 'read',
  proc_status: 'read',
  mem_summary: 'read',
  audit_tail: 'read',
  node_ping: 'read',
  grid_status: 'read',
  node_diagnostic: 'probe',
  node_reboot: 'mutate',
};

export interface AuditEntry extends PermissionGrant {
  ts: string;
}

export class PermissionKernel {
  private log: AuditEntry[] = [];
  private readonly maxLog = 1000;

  request(subject: string, resource: string, action: PermissionGrant['action'], approvedByOperator = false): PermissionGrant {
    let granted = false;
    let reason = 'Fail-closed: no policy matches';

    if (resource.startsWith('tool:')) {
      const tool = resource.slice(5);
      const risk = TOOL_RISK[tool];
      if (!risk) {
        reason = `Fail-closed: unknown tool ${tool}`;
      } else if (subject === 'operator') {
        granted = true;
        reason = 'operator: authenticated, all tools allowed';
      } else if (subject === 'daisy') {
        if (risk === 'read' || risk === 'probe') {
          granted = true;
          reason = `daisy: ${risk} tools allowed`;
        } else if (approvedByOperator) {
          granted = true;
          reason = 'daisy: mutating tool allowed with explicit operator approval';
        } else {
          reason = 'daisy: mutating tool requires operator approval';
        }
      } else {
        reason = 'anonymous: authentication required';
      }
    }

    const grant: PermissionGrant = { subject, resource, action, granted, reason };
    this.log.push({ ...grant, ts: new Date().toISOString() });
    if (this.log.length > this.maxLog) this.log.splice(0, this.log.length - this.maxLog);
    return grant;
  }

  list(): AuditEntry[] {
    return [...this.log];
  }
}
