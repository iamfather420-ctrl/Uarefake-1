/**
 * Daisy AI OS shell server (pure Node, no dependencies).
 *   node --experimental-strip-types server.mjs
 * Env: PORT (3100), DAISY_CORE_URL (http://127.0.0.1:3000), DAISY_OS_TOKEN,
 *      DAISY_LLM_URL / DAISY_LLM_KEY / DAISY_LLM_MODEL (optional agent)
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { SovereignApiRouter } from './src/api/ApiRouter.ts';
import { UnifiedDaisyAIOS } from './src/native-os/UnifiedDaisyAIOS.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => { size += c.length; if (size < 1_000_000) chunks.push(c); });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve(undefined);
      try { resolve(JSON.parse(raw)); } catch { resolve(undefined); }
    });
  });
}

export function createOsServer({ coreUrl, token, llm, root } = {}) {
  const os = new UnifiedDaisyAIOS({ coreUrl, llm, root });
  const authToken = token || process.env.DAISY_OS_TOKEN || randomBytes(18).toString('hex');
  const api = new SovereignApiRouter(os, authToken);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url || '/', 'http://localhost');
    const method = (req.method || 'GET').toUpperCase();
    // Same-origin only: no CORS headers are sent, so other websites cannot call this API from a browser.

    if (url.pathname.startsWith('/api/')) {
      const body = ['POST', 'PUT', 'PATCH'].includes(method) ? await readBody(req) : undefined;
      const r = await api.handleRequest(url.pathname, method, body, req.headers);
      res.writeHead(r.status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify(r.data !== undefined ? r.data : { error: r.error, status: r.status }));
    }

    const rel = url.pathname === '/' ? 'daisy-os.html' : url.pathname.replace(/^\/+/, '');
    const file = path.resolve(PUBLIC, rel);
    if (file.startsWith(PUBLIC + path.sep) && fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
      return res.end(fs.readFileSync(file));
    }
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'not found' }));
  });

  return { server, os, token: authToken };
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const PORT = Number(process.env.PORT || 3100);
  const { server, os, token } = createOsServer({});
  const boot = await os.activate();
  console.log(`[Daisy OS] gate=${boot.gate.status} (${boot.gate.reason})`);
  console.log(`[Daisy OS] llm agent: ${os.agent.isConfigured() ? 'configured' : 'NOT configured (set DAISY_LLM_URL + DAISY_LLM_MODEL)'}`);
  if (!process.env.DAISY_OS_TOKEN) console.log(`[Daisy OS] operator token (set DAISY_OS_TOKEN to fix it): ${token}`);
  server.listen(PORT, '127.0.0.1', () => console.log(`[Daisy OS] http://127.0.0.1:${PORT}`));
  const stop = () => { os.processes.stopAll(); server.close(); process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
