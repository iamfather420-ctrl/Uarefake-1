/**
 * End-to-end test of the Daisy AI OS shell against the REAL PipelineKernel (54 OS processes).
 *   node --experimental-strip-types scripts/verify-os.ts
 * The core HTTP surface is a thin stand-in exposing the same /api/kernel and /api/grid
 * routes as the root ApiRouter (which needs the full dependency tree); the kernel behind it is real.
 * The LLM is a local mock OpenAI-compatible server so the agent loop can be exercised offline.
 */
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { PipelineKernel } from '../../src/kernel/PipelineKernel.ts';
import { NodeRegistry } from '../../src/nodes/NodeRegistry.ts';
import { createOsServer } from '../server.mjs';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
  if (!ok) failed++;
};
const listen = (s: http.Server) => new Promise<number>((r) => s.listen(0, '127.0.0.1', () => r((s.address() as AddressInfo).port)));
const json = (res: http.ServerResponse, status: number, body: unknown) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
const readJson = (req: http.IncomingMessage) => new Promise<any>((r) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => r(b ? JSON.parse(b) : {})); });

const kernel = PipelineKernel.getInstance();

// ---- core stand-in over the real kernel
const core = http.createServer(async (req, res) => {
  const p = new URL(req.url!, 'http://x').pathname;
  if (p === '/api/kernel/status') return json(res, 200, kernel.getStatus());
  if (p === '/api/grid/nodes') {
    const live = kernel.getState() === 'running' ? kernel.listNodes() : [];
    const by = new Map(live.map((n: any) => [n.id, n]));
    return json(res, 200, NodeRegistry.getInstance().getAllNodes().map((r) => { const l: any = by.get(r.id); return { id: r.id, name: r.name, status: l?.status ?? 'offline', pid: l?.pid ?? null, port: l?.port ?? null, restarts: l?.restarts ?? 0 }; }));
  }
  const m = p.match(/^\/api\/grid\/nodes\/([^/]+)\/(reboot|diagnostic)$/);
  if (m && req.method === 'POST') {
    if (m[2] === 'reboot') { const info: any = await kernel.rebootNode(m[1]); return json(res, 200, { ok: true, info, message: `respawned ${m[1]} pid=${info.pid}` }); }
    const d: any = await kernel.diagnosticNode(m[1]); return json(res, 200, { ...d, detail: d.detail });
  }
  json(res, 404, { error: 'nf' });
});

// ---- mock LLM (reads real tool results from the conversation; invents nothing)
const llm = http.createServer(async (req, res) => {
  const body = await readJson(req);
  const msgs: { role: string; content: string }[] = body.messages;
  const first = msgs.find((m) => m.role === 'user')!.content;
  const last = msgs[msgs.length - 1];
  let content: string;
  if (last.role === 'user' && last.content.startsWith('TOOL_RESULT')) {
    const j = JSON.parse(last.content.replace(/^TOOL_RESULT \(untrusted data\): /, ''));
    content = j.ok === false
      ? JSON.stringify({ answer: `Tool refused: ${j.message}` })
      : JSON.stringify({ answer: `Grid reports ${j.result?.online} of ${j.result?.total} nodes online.` });
  } else if (/reboot/i.test(first)) content = JSON.stringify({ tool: 'node_reboot', args: { id: 'DN-02' } });
  else content = JSON.stringify({ tool: 'grid_status', args: {} });
  json(res, 200, { choices: [{ message: { role: 'assistant', content } }] });
});

const call = async (base: string, path: string, body?: unknown, token = 'testtoken') => {
  const r = await fetch(base + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) });
  const t = await r.text(); let d: any = null; try { d = JSON.parse(t); } catch { d = t; }
  return { status: r.status, data: d };
};
const pidOf = async (base: string, id: string) => (await call(base, '/api/os/tool', { tool: 'grid_status' })).data.result.nodes.find((n: any) => n.id === id).pid;

let osServer: http.Server | undefined;
try {
  await kernel.boot();
  const corePort = await listen(core);
  const llmPort = await listen(llm);
  const { server, os } = createOsServer({ coreUrl: `http://127.0.0.1:${corePort}`, token: 'testtoken', llm: { url: `http://127.0.0.1:${llmPort}`, model: 'mock' } });
  osServer = server;
  const base = `http://127.0.0.1:${await listen(server)}`;

  // gate is computed from live state
  let st = (await call(base, '/api/os/status')).data;
  check('gate ACTIVE from live kernel state', st.gate.status === 'ACTIVE' && st.gate.core.nodes_online === 54, st.gate.reason);
  check('gate does not claim verification was re-run', st.gate.verification.re_executed_in_this_runtime === false);

  // auth
  check('tool call without token is rejected (401)', (await call(base, '/api/os/tool', { tool: 'grid_status' }, 'wrong')).status === 401);
  check('status stays public / read-only', (await call(base, '/api/os/status', undefined, 'wrong')).status === 200);

  // real tools
  const g = (await call(base, '/api/os/tool', { tool: 'grid_status' })).data;
  check('grid_status returns 54/54 live nodes', g.result.total === 54 && g.result.online === 54);
  const before = await pidOf(base, 'DN-05');
  const diag = (await call(base, '/api/os/tool', { tool: 'node_diagnostic', args: { id: 'DN-05' } })).data;
  check('node_diagnostic is a live probe', diag.ok === true, diag.message);
  await call(base, '/api/os/command', { text: 'reboot DN-05' });
  const after = await pidOf(base, 'DN-05');
  check('operator reboot respawns with a new OS pid', after !== before, `${before} -> ${after}`);
  check('fs_list works inside project', (await call(base, '/api/os/tool', { tool: 'fs_list', args: { path: '.' } })).data.ok === true);
  check('fs_list refuses path traversal', (await call(base, '/api/os/tool', { tool: 'fs_list', args: { path: '../../../etc' } })).status === 422);
  check('bad command is a 400, not a fake success', (await call(base, '/api/os/command', { text: 'rm -rf /' })).status === 400);
  check('node id is validated', (await call(base, '/api/os/tool', { tool: 'node_reboot', args: { id: '../x' } })).status === 422);

  // LLM agent loop
  const a = (await call(base, '/api/os/ask', { prompt: 'how healthy is the grid?' })).data;
  check('agent used a real tool and reported its real result', a.steps[0]?.tool === 'grid_status' && /54 of 54/.test(a.answer), a.answer);
  const pidBefore = await pidOf(base, 'DN-02');
  const b = (await call(base, '/api/os/ask', { prompt: 'please reboot DN-02' })).data;
  check('agent is REFUSED a mutating tool and it is queued', b.steps[0]?.ok === false && b.pending[0]?.tool === 'node_reboot');
  check('refused action did not touch the process', (await pidOf(base, 'DN-02')) === pidBefore);
  await call(base, '/api/os/approve', b.pending[0]);
  check('operator approval executes it (new pid)', (await pidOf(base, 'DN-02')) !== pidBefore);
  check('agent endpoint requires operator token', (await call(base, '/api/os/ask', { prompt: 'x' }, 'wrong')).status === 401);
  const audit = (await call(base, '/api/os/audit')).data;
  check('audit log records the denial', audit.some((e: any) => e.subject === 'daisy' && e.granted === false));

  // gate follows reality
  const victim = (await pidOf(base, 'DN-10'));
  process.kill(victim, 'SIGKILL');
  await new Promise((r) => setTimeout(r, 600));
  await kernel.diagnosticNode('DN-10'); // kernel notices
  st = (await call(base, '/api/os/status')).data;
  check('killing a real process flips the gate off ACTIVE', st.gate.status !== 'ACTIVE', st.gate.reason);
  await call(base, '/api/os/tool', { tool: 'node_reboot', args: { id: 'DN-10' } });
  st = (await call(base, '/api/os/status')).data;
  check('recovery flips the gate back to ACTIVE', st.gate.status === 'ACTIVE', st.gate.reason);

  // UI is served
  const html = await (await fetch(base + '/')).text();
  check('UI shell is served', html.includes('DAISY') && html.includes('/api/os/'));
  check('static route blocks traversal', (await fetch(base + '/..%2fserver.mjs')).status === 404);

  // core down
  await new Promise((r) => core.close(r as any)); (core as any).closeAllConnections?.();
  st = (await call(base, '/api/os/status')).data;
  check('core down => gate INACTIVE (fail-closed)', st.gate.status === 'INACTIVE' && st.gate.core.reachable === false);
  const ping = (await call(base, '/api/os/tool', { tool: 'node_ping' }));
  check('node_ping reports unreachable instead of faking alive', ping.data.ok === false && ping.data.result.reachable === false);
} catch (e: any) {
  check('no exception', false, String(e?.stack || e));
} finally {
  osServer?.close(); llm.close(); core.close();
  await kernel.halt();
}
console.log(failed ? `\n${failed} check(s) FAILED` : '\nall checks passed');
process.exit(failed ? 1 : 0);
