import { execFileSync } from 'node:child_process';
import { RELEASE_GATES } from './release_gate_registry.ts';

let failed = 0;
for (const { name, script } of RELEASE_GATES) {
  console.log(`\n=== ${name} ===`);
  try {
    execFileSync('node', ['--experimental-strip-types', script], { stdio: 'inherit', env: process.env });
  } catch {
    failed++;
  }
}
if (failed) {
  console.error(`VERIFY ALL: ${failed} gate(s) failed`);
  process.exit(1);
}
console.log(`VERIFY ALL: ${RELEASE_GATES.length}/${RELEASE_GATES.length} gates passed`);
