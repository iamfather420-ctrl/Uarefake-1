/**
 * Smoke test: start 3 real node processes, probe health, reboot one, stop all.
 */
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const worker = path.join(__dirname, '../src/runtime/node-worker.mjs');

function startNode(id, name, port) {
  const child = spawn(process.execPath, [worker, id, name, String(port)], {
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  return child;
}

async function probe(port) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(500) });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

const nodes = [
  { id: 'DN-01', name: 'Daisy Genesis Core', port: 41001 },
  { id: 'DN-02', name: 'MMTAI Authority Gate', port: 41002 },
  { id: 'DN-03', name: 'Z3 Theorem Prover Kernel', port: 41003 },
];

const children = nodes.map((n) => startNode(n.id, n.name, n.port));
console.log('Spawned', children.length, 'worker processes');

await new Promise((r) => setTimeout(r, 400));

for (const n of nodes) {
  const h = await probe(n.port);
  console.log(n.id, h ? `ONLINE pid=${h.pid}` : 'OFFLINE');
}

// Reboot DN-02
console.log('Rebooting DN-02...');
children[1].kill('SIGTERM');
await new Promise((r) => setTimeout(r, 300));
const replacement = startNode(nodes[1].id, nodes[1].name, nodes[1].port);
children[1] = replacement;
await new Promise((r) => setTimeout(r, 300));
const h2 = await probe(nodes[1].port);
console.log('DN-02 after reboot:', h2 ? `ONLINE new_pid=${h2.pid}` : 'OFFLINE');

for (const c of children) {
  try { c.kill('SIGTERM'); } catch { /* */ }
}
console.log('Smoke test complete.');
process.exit(0);
