import { existsSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync, spawnSync } from 'node:child_process';
import { RELEASE_GATES } from './release_gate_registry.ts';


type GateStatus = 'PASS' | 'FAIL' | 'NOT_EXECUTED';
type GateResult = {
  status: GateStatus;
  reason?: 'TIMEOUT' | 'NETWORK_UNAVAILABLE' | 'COMMAND_FAILED' | 'MISSING_PREREQUISITE';
  stage: string;
  exitCode?: number;
};

const resultPath = 'release-check-result.json';
const startedAt = new Date().toISOString();
const results: GateResult[] = [];

const writeResult = (overall: GateStatus, reason?: GateResult['reason']) => {
  const payload = {
    schemaVersion: 1,
    command: 'release:check',
    status: overall,
    reason: reason ?? null,
    startedAt,
    completedAt: new Date().toISOString(),
    stages: results,
  };
  try { writeFileSync(resultPath, JSON.stringify(payload, null, 2) + '\n'); } catch {}
  return payload;
};

const fail = (stage: string, reason: GateResult['reason'], exitCode = 1): never => {
  const status: GateStatus = reason === 'TIMEOUT' || reason === 'NETWORK_UNAVAILABLE' ? 'NOT_EXECUTED' : 'FAIL';
  results.push({ status, reason, stage, exitCode });
  writeResult(status, reason);
  console.error(`RELEASE GATE: ${stage} [${status}${reason ? `:${reason}` : ''}]`);
  process.exit(exitCode);
};


const forbidden = ['PROVENANCE_' + 'UNAVAILABLE'];
const productionRoots = ['src', 'server.ts', 'daisy-ai-os', 'Solvex-core'];
const scan = (dir: string): string[] => {
  const out: string[] = [];
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'dist', '.git', 'artifacts', 'scripts', 'tests'].includes(e.name)) continue;
    const p = `${dir}/${e.name}`;
    if (e.isDirectory()) out.push(...scan(p));
    else if (/\.(ts|tsx|js|jsx|json|yml|yaml|md)$/.test(e.name)) out.push(p);
  }
  return out;
};
const stale = productionRoots.flatMap(root => {
  if (!existsSync(root)) return [];
  return root === 'server.ts' ? [root] : scan(root);
}).filter(f => forbidden.some(x => readFileSync(f, 'utf8').includes(x)));
if (stale.length) fail('provenance source scan', 'COMMAND_FAILED', 1);

const run = (label: string, cmd: string, args: string[], options: { timeoutMs?: number; networkStage?: boolean } = {}) => {
  console.log(`RELEASE GATE: ${label} [RUNNING]`);
  try {
    execFileSync(cmd, args, { stdio: 'inherit', env: process.env, timeout: options.timeoutMs });
    results.push({ status: 'PASS', stage: label });
    console.log(`RELEASE GATE: ${label} [PASS]`);
  } catch (error: any) {
    const timedOut = error?.code === 'ETIMEDOUT' || error?.signal === 'SIGTERM';
    const networkUnavailable = options.networkStage && (error?.code === 'EAI_AGAIN' || error?.code === 'ENETUNREACH' || error?.code === 'ENOTFOUND');
    fail(label, timedOut ? 'TIMEOUT' : networkUnavailable ? 'NETWORK_UNAVAILABLE' : 'COMMAND_FAILED', timedOut || networkUnavailable ? 2 : 1);
  }
};

const handleTermination = (signal: NodeJS.Signals) => {
  results.push({ status: 'NOT_EXECUTED', reason: 'TIMEOUT', stage: 'release:check', exitCode: 2 });
  writeResult('NOT_EXECUTED', 'TIMEOUT');
  console.error(`RELEASE GATE: release:check [NOT_EXECUTED:TIMEOUT:${signal}]`);
  process.exit(2);
};
process.once('SIGTERM', () => handleTermination('SIGTERM'));
process.once('SIGINT', () => handleTermination('SIGINT'));

if (!existsSync('package.json')) fail('package.json prerequisite', 'MISSING_PREREQUISITE');
if (!existsSync('package-lock.json')) fail('package-lock.json prerequisite', 'MISSING_PREREQUISITE');

console.log('RELEASE GATE: registry reachability');
const registryProbe = spawnSync('npm', ['ping', '--fetch-retries=0', '--fetch-timeout=10000'], { encoding: 'utf8', env: process.env, timeout: 15000 });
if (registryProbe.status === 0) {
  results.push({ status: 'PASS', stage: 'registry reachability' });
  console.log('RELEASE GATE: registry reachability [PASS]');
} else {
  const registryOutput = `${registryProbe.stdout ?? ''}\n${registryProbe.stderr ?? ''}`;
  const networkUnavailable = registryProbe.error?.code === 'ETIMEDOUT' || /EAI_AGAIN|ENETUNREACH|ENOTFOUND|EHOSTUNREACH/.test(registryOutput);
  if (networkUnavailable) {
    fail('registry reachability', 'NETWORK_UNAVAILABLE', 2);
  }
  fail('registry reachability', 'COMMAND_FAILED', 2);
}
console.log('RELEASE GATE: clean dependency installation');
run('clean dependency installation', 'npm', ['ci', '--ignore-scripts', '--no-audit', '--no-fund', '--fetch-retries=0', '--fetch-timeout=10000'], { timeoutMs: 30000, networkStage: true });
console.log('RELEASE GATE: type-check');
run('type-check', 'npm', ['run', 'lint']);
console.log('RELEASE GATE: production build');
run('production build', 'npm', ['run', 'build']);
if (!existsSync('dist/server.cjs')) fail('production server bundle', 'MISSING_PREREQUISITE');
run(`canonical verification suite (${RELEASE_GATES.length} gates)`, 'npm', ['run', 'verify:all']);
run('release provenance manifest', 'npm', ['run', 'release:provenance']);
run('release manifest binding verification', 'npm', ['run', 'verify:release-manifest']);
run('production startup smoke', 'npm', ['run', 'verify:production-start']);
writeResult('PASS');
console.log(`RELEASE BUILD CONTRACT: PASS\nRESULT: ${resultPath}`);
