import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import cp from 'child_process';

function sha256File(file: string): string {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'dist', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const root = process.cwd();
const files = walk(root).filter(f => !f.includes(`${path.sep}artifacts${path.sep}`) && !f.includes(`${path.sep}dist${path.sep}`)).sort();
const sourceEntries = files
  .filter(f => /\.(ts|tsx|js|jsx|json|md|yml|yaml|kts|gradle|properties)$/.test(f))
  .map(f => ({ path: path.relative(root, f).replaceAll(path.sep, '/'), sha256: sha256File(f) }))
  .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);

const commit_sha = (process.env.GITHUB_SHA || (() => { try { return cp.execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim(); } catch { return ''; } })());
if (!commit_sha || !/^[0-9a-f]{40}$/i.test(commit_sha)) throw new Error('Release provenance unavailable: run this command from a Git checkout or CI with GITHUB_SHA.');

const releaseRoot = crypto.createHash('sha256')
  .update(sourceEntries.map(e => `${e.path}:${e.sha256}`).join('\n'))
  .digest('hex');

const canonicalGateRegistryPath = 'scripts/release_gate_registry.ts';
const canonicalGateRegistryFile = path.join(root, canonicalGateRegistryPath);
if (!fs.existsSync(canonicalGateRegistryFile)) throw new Error('Canonical release gate registry is required for release provenance.');
const canonical_gate_registry_sha256 = sha256File(canonicalGateRegistryFile);
const canonical_gate_registry = {
  path: canonicalGateRegistryPath,
  sha256: canonical_gate_registry_sha256,
  gate_count: 15
};

const buildAttestationPath = path.join(root, 'artifacts', 'build-attestation.json');
if (!fs.existsSync(buildAttestationPath)) throw new Error('Build attestation is required before release provenance.');
const buildAttestationBytes = fs.readFileSync(buildAttestationPath);
const buildAttestation = JSON.parse(buildAttestationBytes.toString('utf8'));
if (buildAttestation.attestation_type !== 'SOLVEX_PRODUCTION_BUILD') throw new Error('Invalid build attestation type.');
const build_attestation_sha256 = sha256File(buildAttestationPath);
const build_output_root_sha256 = buildAttestation.build_output_root_sha256;
if (!/^[0-9a-f]{64}$/i.test(build_output_root_sha256)) throw new Error('Build attestation output root is invalid.');

const packageLock = path.join(root, 'package-lock.json');
if (!fs.existsSync(packageLock)) throw new Error('package-lock.json is required for release provenance.');
const package_lock_sha256 = sha256File(packageLock);
const node_version = cp.execSync('node --version', { encoding: 'utf8' }).trim();
const npm_version = cp.execSync('npm --version', { encoding: 'utf8' }).trim();

const manifest = {
  schema_version: '1.2.0',
  manifest_type: 'SOURCE_RELEASE_INTEGRITY',
  generated_at: new Date().toISOString(),
  commit_sha,
  node_version,
  npm_version,
  package_lock_sha256,
  build_attestation_sha256,
  build_output_root_sha256,
  release_root_sha256: releaseRoot,
  canonical_gate_registry,
  verification_status: 'GENERATED_BY_EXECUTION',
  canonical_verification_commands: [
    'npm run verify:all',
    'npm run release:check',
    'npm run verify:release-manifest'
  ],
  canonical_dh_authority: 'src/formal/dhAuthoritativeFormalContracts.ts + src/proofs/DHFormalVerifier.ts',
  legacy_dh_corpus_status: 'RETAINED_FOR_COMPATIBILITY_ONLY',
  source_entries: sourceEntries
};

const out = path.join(root, 'artifacts', 'source-release-integrity-manifest.json');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(manifest, null, 2));
console.log(`Wrote ${out}`);
console.log(`Release root: ${releaseRoot}`);
