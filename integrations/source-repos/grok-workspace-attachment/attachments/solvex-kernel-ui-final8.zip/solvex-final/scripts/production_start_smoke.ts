import { spawn } from 'node:child_process';
import { request } from 'node:http';

const port = Number(process.env.PORT || 3900);
const env = { ...process.env, NODE_ENV: 'production', SOLVEX_ENV: 'production', PORT: String(port) };
if (!env.NEON_DATABASE_URL) throw new Error('NEON_DATABASE_URL is required for production startup smoke.');
if (!env.SOLVEX_AUTH_SECRET || env.SOLVEX_AUTH_SECRET.length < 32) throw new Error('SOLVEX_AUTH_SECRET >= 32 characters is required for production startup smoke.');

const child = spawn(process.execPath, ['dist/server.cjs'], { env, stdio: ['ignore', 'pipe', 'pipe'] });
let output = '';
child.stdout.on('data', b => { output += b.toString(); });
child.stderr.on('data', b => { output += b.toString(); });

const deadline = Date.now() + 20000;
const wait = (ms: number) => new Promise(r => setTimeout(r, ms));
const check = () => new Promise<boolean>(resolve => {
  const req = request({ hostname: '127.0.0.1', port, path: '/api/system/health', method: 'GET', timeout: 2000 }, res => {
    let body = ''; res.setEncoding('utf8'); res.on('data', c => body += c);
    res.on('end', () => resolve(res.statusCode === 200 && body.includes('HEALTHY')));
  });
  req.on('error', () => resolve(false)); req.end();
});

try {
  let healthy = false;
  while (Date.now() < deadline && !healthy && child.exitCode === null) { healthy = await check(); if (!healthy) await wait(250); }
  if (!healthy) throw new Error(`Production server did not reach healthy state.\n${output}`);
  console.log('PRODUCTION START SMOKE: PASS');
} finally {
  child.kill('SIGTERM');
  await wait(500);
  if (child.exitCode === null) child.kill('SIGKILL');
}
