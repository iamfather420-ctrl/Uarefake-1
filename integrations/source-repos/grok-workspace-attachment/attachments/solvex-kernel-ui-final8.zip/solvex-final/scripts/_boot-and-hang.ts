// helper for verify-kernel.ts: boots the kernel, prints worker PIDs, then idles until killed
import { PipelineKernel } from '../src/kernel/PipelineKernel.ts';
const k = PipelineKernel.getInstance();
await k.boot();
console.log('PIDS ' + JSON.stringify(k.listNodes().map((n) => n.pid)));
setInterval(() => {}, 1 << 30);
