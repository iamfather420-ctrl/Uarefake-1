/**
 * Compatibility entrypoint. The canonical implementation is npm run verify:120,
 * backed by DHFormalVerifier + DFRLFormalVerifier + System46Gates.
 */
import { spawnSync } from 'child_process';

const result = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'verify:120'], {
  stdio: 'inherit',
  env: process.env
});

process.exit(result.status ?? 1);
