/**
 * Integration test for the real runtime: boots PipelineKernel and exercises it.
 * Run: node --experimental-strip-types scripts/verify-kernel.ts   (or: npx tsx scripts/verify-kernel.ts)
 * Exits non-zero on any failed check.
 */
import { PipelineKernel } from '../src/kernel/PipelineKernel.ts';
import { MessageBus } from '../src/bus/MessageBus.ts';

let failed = 0;
function check(name: string, ok: boolean, detail = '') {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`);
  if (!ok) failed++;
}

const kernel = PipelineKernel.getInstance();
try {
  const status = await kernel.boot();
  check('kernel boots', status.state === 'running', `state=${status.state}`);
  check('54 nodes registered', status.nodes.total === 54, `total=${status.nodes.total}`);
  check('54 nodes online', status.nodes.online === 54, `online=${status.nodes.online}`);

  const nodes = kernel.listNodes();
  const pids = new Set(nodes.map((n) => n.pid).filter(Boolean));
  check('54 distinct OS PIDs', pids.size === 54, `distinct pids=${pids.size}`);
  check('none of them is the supervisor itself', !pids.has(process.pid));

  const target = nodes[1];
  const before = target.pid;
  const rebooted = await kernel.rebootNode(target.id);
  check('reboot yields a NEW pid', rebooted.pid !== before && rebooted.pid !== null, `${before} -> ${rebooted.pid}`);
  check('rebooted node is online again', rebooted.status === 'online', `status=${rebooted.status}`);

  const diag = await kernel.diagnosticNode(target.id);
  check('live diagnostic probe passes', diag.ok === true, diag.detail);

  // kill a worker out from under the kernel and make sure the probe notices
  try { process.kill(rebooted.pid as number, 'SIGKILL'); } catch {}
  await new Promise((r) => setTimeout(r, 400));
  const diag2 = await kernel.diagnosticNode(target.id);
  check('diagnostic detects a killed process (not a canned success)', diag2.ok === false, diag2.detail);

  const recent = MessageBus.getInstance().getRecent();
  check('bus recorded kernel events', Array.isArray(recent) && recent.length > 0, `events=${recent.length}`);
} catch (e: any) {
  check('no exception', false, String(e?.message || e));
} finally {
  await kernel.halt();
  const after = kernel.getStatus();
  check('halt stops all nodes', after.state === 'halted' && after.nodes.online === 0, `state=${after.state}`);
}
// crash safety: SIGKILL the supervisor and make sure no worker is left behind
{
  const { spawn } = await import('node:child_process');
  const sup = spawn(process.execPath, ['--experimental-strip-types', new URL('./_boot-and-hang.ts', import.meta.url).pathname], { stdio: ['ignore', 'pipe', 'ignore'] });
  const pids: number[] = await new Promise((resolve, reject) => {
    let buf = '';
    sup.stdout.on('data', (d) => { buf += d; const m = buf.match(/PIDS (\[.*\])/); if (m) resolve(JSON.parse(m[1])); });
    setTimeout(() => reject(new Error('supervisor did not boot')), 60000);
  });
  sup.kill('SIGKILL');
  await new Promise((r) => setTimeout(r, 3000));
  const alive = pids.filter((p) => { try { process.kill(p, 0); return true; } catch { return false; } });
  check('workers exit when the supervisor is SIGKILLed (no orphans)', alive.length === 0, `${pids.length} workers, ${alive.length} still alive`);
  for (const p of alive) { try { process.kill(p, 'SIGKILL'); } catch {} }
}
console.log(failed ? `\n${failed} check(s) FAILED` : '\nall checks passed');
process.exit(failed ? 1 : 0);
