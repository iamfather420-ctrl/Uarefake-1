import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const checks: Array<[string, boolean, string]> = [];
const read = (p: string) => fs.readFileSync(path.join(root, p), 'utf8');

const api = read('src/api/ApiRouter.ts');
const neon = read('src/database/NeonPersistence.ts');
const paypal = read('src/payments/PayPalAdapter.ts');
const auth = read('src/auth/AuthService.ts');
const server = read('server.ts');
const repo = read('src/components/RepoSelector.tsx');
const zip = read('src/lib/binaryPackageProcessor.ts');
const sqlite = read('src/database/SqliteStore.ts');
const manifest = fs.existsSync(path.join(root, 'solvex-manifest.json')) ? fs.readFileSync(path.join(root, 'solvex-manifest.json'), 'utf8') : '';


checks.push(['rollback-platform-admin-only', api.includes("rollback is restricted to PLATFORM_ADMIN") && !api.includes("if (!user || ['PLATFORM_ADMIN', 'OWNER', 'ADMIN'].includes(user.role))"), 'Rollback must be platform-admin only.']);
checks.push(['global-body-limit', api.includes('MAX_BODY_BYTES = 1024 * 1024') && api.includes('413'), 'HTTP body buffering must be bounded.']);
checks.push(['distributed-order-payment-lease', neon.includes('payment_order_leases') && neon.includes('acquirePaymentOrderLease'), 'Production payment capture needs a per-order distributed lease.']);
checks.push(['stable-paypal-order-idempotency', paypal.includes('solvex-order-${orderId}') && paypal.includes('solvex-order-${orderId}-capture'), 'Provider idempotency must be order-stable.']);
checks.push(['strict-production-neon', auth.includes('NEON_DATABASE_URL is required in production') && server.includes('NEON_DATABASE_URL is required in production'), 'Production must require distributed persistence.']);
checks.push(['platform-offer-publish', auth.includes("PUBLISH_OFFER: ['PLATFORM_ADMIN']"), 'Global marketplace publication must be platform-authorized.']);
checks.push(['no-github-localstorage-token', !repo.includes('localStorage.getItem("github_tether_token")') && !repo.includes('localStorage.setItem("github_tether_token"'), 'GitHub tokens must not persist in localStorage.']);
checks.push(['zip-slip-defense', zip.includes('path.resolve(outputRoot, entryName)') && zip.includes('Unsafe archive path rejected'), 'Archive extraction must reject traversal.']);
checks.push(['payee-amount-currency-validation', paypal.includes("capturedCurrency === 'USD'") && paypal.includes('capturedAmount === Number(amountFormatted)'), 'Provider capture must match persisted amount and currency.']);
checks.push(['no-mock-database-fallback', !sqlite.includes('in-memory SQL interface') && !sqlite.includes('mock runner') && sqlite.includes('SQLite runtime unavailable'), 'Production/release source must not contain a mock or in-memory database fallback.']);
checks.push(['no-fake-provenance-markers', !manifest.includes('PROVENANCE_UNAVAILABLE') && !manifest.includes('MODEL_VERIFIED'), 'Release source must not ship unverifiable provenance claims.']);
checks.push(['compiled-production-start', JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).scripts.start === 'node dist/server.cjs', 'Production start must use compiled server.']);

let failed = 0;
for (const [name, ok, detail] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}: ${detail}`);
  if (!ok) failed++;
}
if (failed) process.exit(1);
console.log(`PRODUCTION HARDENING: ${checks.length}/${checks.length} PASS`);
