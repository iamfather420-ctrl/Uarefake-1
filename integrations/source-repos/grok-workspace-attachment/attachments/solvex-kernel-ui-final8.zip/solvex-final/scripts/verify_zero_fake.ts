import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const roots = [
  path.join(root, 'src'),
  path.join(root, 'server.ts'),
  path.join(root, 'daisy-ai-os'),
  path.join(root, 'Solvex-core'),
];
const excluded = [/[/\\]tests[/\\]/, /[/\\]node_modules[/\\]/, /[/\\]dist[/\\]/, /[/\\]\.git[/\\]/];
const forbidden: Array<[RegExp, string]> = [
  [/PROVENANCE_UNAVAILABLE/i, 'unverifiable provenance marker'],
  [/mockLeanCertificate/i, 'fabricated Lean certificate'],
  [/simulatedRepos/i, 'fabricated repository fallback'],
  [/Simulate Successful Payment/i, 'simulated production payment action'],
  [/handleSimulateSuccess/i, 'simulated production payment action'],
  [/synthetic payment receipt/i, 'synthetic payment receipt'],
  [/running in simulated fallback mode/i, 'provider fallback presented as runtime'],
  [/deterministic simulation fallback/i, 'deterministic provider fallback'],
  [/Zero Mocks Certified/i, 'unsupported zero-mock certification claim'],
  [/CONTRACT SIGNED & SECURED[^\n]*EFTPS/i, 'unsupported contract/payment/EFTPS success claim'],
  [/SECURED & REALTIME/i, 'unsupported realtime external-transfer claim'],
];
const hits: string[] = [];
function walk(p: string) {
  if (!fs.existsSync(p)) return;
  const st = fs.statSync(p);
  if (st.isDirectory()) {
    if (excluded.some(r => r.test(p))) return;
    for (const n of fs.readdirSync(p)) walk(path.join(p, n));
    return;
  }
  if (!/\.(ts|tsx|js|jsx|mjs)$/.test(p) || excluded.some(r => r.test(p))) return;
  const text = fs.readFileSync(p, 'utf8');
  for (const [rx, label] of forbidden) if (rx.test(text)) hits.push(`${path.relative(root, p)}: ${label}`);
}
for (const r of roots) walk(r);
if (hits.length) {
  console.error('ZERO-FAKE POLICY: FAIL');
  for (const h of hits) console.error(`- ${h}`);
  process.exit(1);
}
console.log('ZERO-FAKE POLICY: PASS');
