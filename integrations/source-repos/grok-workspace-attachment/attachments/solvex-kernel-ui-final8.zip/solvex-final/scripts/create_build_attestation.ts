import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import cp from 'node:child_process';

const sha256 = (data: Buffer | string) => crypto.createHash('sha256').update(data).digest('hex');
const gitSha = process.env.GITHUB_SHA || (() => { try { return cp.execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim(); } catch { return ''; } })();
if (!/^[0-9a-f]{40}$/i.test(gitSha)) throw new Error('Build attestation requires a real Git commit SHA.');
if (!fs.existsSync('package-lock.json')) throw new Error('Build attestation requires package-lock.json.');
if (!fs.existsSync('dist/server.cjs')) throw new Error('Build attestation requires dist/server.cjs.');

const walk = (dir: string, out: string[] = []) => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out); else out.push(full);
  }
  return out;
};
const outputs = walk('dist').sort().map(file => ({ path: path.relative(process.cwd(), file).replaceAll(path.sep, '/'), sha256: sha256(fs.readFileSync(file)), size_bytes: fs.statSync(file).size }));
const source = {
  git_commit_sha: gitSha,
  package_lock_sha256: sha256(fs.readFileSync('package-lock.json')),
  node_version: process.version,
  npm_version: cp.execSync('npm --version', { encoding: 'utf8' }).trim(),
  generated_at: new Date().toISOString(),
  outputs
};
const attestation = { schema_version: '1.0.0', attestation_type: 'SOLVEX_PRODUCTION_BUILD', source, build_output_root_sha256: sha256(outputs.map(o => `${o.path}:${o.sha256}:${o.size_bytes}`).join('\n')) };
fs.mkdirSync('artifacts', { recursive: true });
fs.writeFileSync('artifacts/build-attestation.json', JSON.stringify(attestation, null, 2));
console.log(`Build attestation created for ${gitSha}`);
