import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const sha256 = (data: Buffer | string) => crypto.createHash('sha256').update(data).digest('hex');
const sha256File = (file: string) => sha256(fs.readFileSync(file));
const root = process.cwd();
const manifestPath = path.join(root, 'artifacts/source-release-integrity-manifest.json');
const attestationPath = path.join(root, 'artifacts/build-attestation.json');
const registryPath = path.join(root, 'scripts/release_gate_registry.ts');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'dist', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

function computeSourceEntries() {
  return walk(root)
    .filter(f => !f.includes(`${path.sep}artifacts${path.sep}`) && !f.includes(`${path.sep}dist${path.sep}`))
    .sort()
    .filter(f => /\.(ts|tsx|js|jsx|json|md|yml|yaml|kts|gradle|properties)$/.test(f))
    .map(f => ({ path: path.relative(root, f).replaceAll(path.sep, '/'), sha256: sha256File(f) }))
    .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
}

if (!fs.existsSync(manifestPath)) throw new Error('RELEASE MANIFEST: missing.');
if (!fs.existsSync(attestationPath)) throw new Error('RELEASE MANIFEST: build attestation missing.');
if (!fs.existsSync(registryPath)) throw new Error('RELEASE MANIFEST: canonical gate registry missing.');

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const attestationBytes = fs.readFileSync(attestationPath);
const attestation = JSON.parse(attestationBytes.toString('utf8'));
const actualAttestationHash = sha256(attestationBytes);

if (manifest.manifest_type !== 'SOURCE_RELEASE_INTEGRITY') throw new Error('RELEASE MANIFEST: wrong type.');
if (!Array.isArray(manifest.source_entries)) throw new Error('RELEASE MANIFEST: source_entries missing.');
if (manifest.build_attestation_sha256 !== actualAttestationHash) throw new Error('RELEASE MANIFEST: build attestation hash mismatch.');
if (manifest.build_output_root_sha256 !== attestation.build_output_root_sha256) throw new Error('RELEASE MANIFEST: build output root mismatch.');
if (manifest.commit_sha !== attestation.source.git_commit_sha) throw new Error('RELEASE MANIFEST: commit mismatch.');
if (manifest.package_lock_sha256 !== attestation.source.package_lock_sha256) throw new Error('RELEASE MANIFEST: package-lock mismatch.');

const actualRegistryHash = sha256File(registryPath);
const registry = manifest.canonical_gate_registry;
if (!registry || registry.path !== 'scripts/release_gate_registry.ts') throw new Error('RELEASE MANIFEST: canonical gate registry binding missing.');
if (registry.sha256 !== actualRegistryHash) throw new Error('RELEASE MANIFEST: canonical gate registry hash mismatch.');
if (registry.gate_count !== 15) throw new Error(`RELEASE MANIFEST: canonical gate count mismatch: expected 15, got ${registry.gate_count}.`);

const actualEntries = computeSourceEntries();
const expectedEntries = [...manifest.source_entries].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
if (expectedEntries.length !== actualEntries.length) {
  throw new Error(`RELEASE MANIFEST: source entry count mismatch: manifest=${expectedEntries.length}, actual=${actualEntries.length}.`);
}
for (let i = 0; i < actualEntries.length; i++) {
  const expected = expectedEntries[i];
  const actual = actualEntries[i];
  if (expected.path !== actual.path || expected.sha256 !== actual.sha256) {
    throw new Error(`RELEASE MANIFEST: source entry mismatch at index ${i}: expected=${expected.path}:${expected.sha256}, actual=${actual.path}:${actual.sha256}.`);
  }
}

const actualReleaseRoot = sha256(actualEntries.map(e => `${e.path}:${e.sha256}`).join('\n'));
if (manifest.release_root_sha256 !== actualReleaseRoot) throw new Error('RELEASE MANIFEST: release root recomputation mismatch.');

console.log(`RELEASE MANIFEST: PASS (attestation ${actualAttestationHash}, release root ${actualReleaseRoot}, gate registry ${actualRegistryHash})`);
