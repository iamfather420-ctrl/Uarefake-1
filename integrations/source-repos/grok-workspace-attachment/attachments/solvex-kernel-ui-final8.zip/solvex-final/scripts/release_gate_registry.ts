export type ReleaseGate = { name: string; script: string };

/** Single canonical verification-gate registry used by verify:all and release:check. */
export const RELEASE_GATES: readonly ReleaseGate[] = [
  ['zero-fake', 'scripts/verify_zero_fake.ts'],
  ['build-attestation', 'scripts/verify_build_attestation.ts'],
  ['production-hardening', 'scripts/verify_production_hardening.ts'],
  ['api-security', 'scripts/verify_api_security.ts'],
  ['authoritative', 'scripts/verify_authoritative.ts'],
  ['enterprise', 'scripts/verify_enterprise.ts'],
  ['dfrl', 'scripts/verify_dfrl.ts'],
  ['dh-formal', 'scripts/verify_dh_formal.ts'],
  ['120-aggregation', 'scripts/verify_120_aggregation.ts'],
  ['nodes', 'scripts/verify_nodes.ts'],
  ['paypal', 'scripts/verify_paypal_dual_env.ts'],
  ['sandbox', 'scripts/verify_sandbox.ts'],
  ['proof-closure', 'scripts/full_build_verification_closure.ts'],
  ['ci-closure', 'scripts/ci_proof_closure_check.ts'],
  ['production-runtime', 'scripts/verify_production_runtime.ts'],
].map(([name, script]) => ({ name, script }));
