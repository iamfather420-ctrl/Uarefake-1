import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import cp from 'node:child_process';

const sha256 = (data: Buffer | string) => crypto.createHash('sha256').update(data).digest('hex');
const file = 'artifacts/build-attestation.json';
if (!fs.existsSync(file)) throw new Error('BUILD ATTESTATION: missing; run npm run build first.');
const a = JSON.parse(fs.readFileSync(file, 'utf8'));
if (a.attestation_type !== 'SOLVEX_PRODUCTION_BUILD') throw new Error('BUILD ATTESTATION: wrong type.');
const actualCommit = process.env.GITHUB_SHA || (() => { try { return cp.execSync('git rev-parse HEAD', { encoding: 'utf8' }).trim(); } catch { return ''; } })();
if (!/^[0-9a-f]{40}$/i.test(actualCommit) || a.source.git_commit_sha !== actualCommit) throw new Error('BUILD ATTESTATION: commit mismatch.');
const lockHash = sha256(fs.readFileSync('package-lock.json'));
if (a.source.package_lock_sha256 !== lockHash) throw new Error('BUILD ATTESTATION: package-lock hash mismatch.');
const outputs = a.source.outputs;
if (!Array.isArray(outputs) || outputs.length === 0) throw new Error('BUILD ATTESTATION: no build outputs recorded.');
for (const output of outputs) {
  const p = path.resolve(output.path);
  if (!fs.existsSync(p)) throw new Error(`BUILD ATTESTATION: missing output ${output.path}.`);
  const bytes = fs.readFileSync(p);
  if (sha256(bytes) !== output.sha256 || bytes.length !== output.size_bytes) throw new Error(`BUILD ATTESTATION: output mismatch ${output.path}.`);
}
const root = sha256(outputs.map((o: any) => `${o.path}:${o.sha256}:${o.size_bytes}`).join('\n'));
if (root !== a.build_output_root_sha256) throw new Error('BUILD ATTESTATION: output root mismatch.');
console.log(`BUILD ATTESTATION: PASS (${outputs.length} outputs, commit ${actualCommit})`);
