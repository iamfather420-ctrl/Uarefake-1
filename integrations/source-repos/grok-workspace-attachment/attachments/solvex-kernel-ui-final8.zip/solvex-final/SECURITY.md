# Security deployment requirements

- Set `SOLVEX_AUTH_SECRET` to a random secret of at least 32 bytes in production.
- Provision users through `SOLVEX_AUTH_USERS_JSON` using `AuthService.hashPassword()` output (`scrypt$...`).
- Do not use SHA-256 password hashes. Legacy hashes are intentionally rejected.
- Access tokens expire after 15 minutes and are revoked on logout.
- PayPal credentials are server-side only.
- Order prices are server-persisted; payment capture never accepts a client-supplied amount.
- Custom SMT submissions are authenticated and capped at 64 KiB.


## Release-hardening requirements

- `PLATFORM_ADMIN` is the only role permitted to cross tenant boundaries or create tenants. `OWNER` is tenant-scoped.
- Proof bundles and verification runs are tenant-scoped unless explicitly marked as platform-global.
- Custom SMT execution is disabled by default. Enable `SOLVEX_ALLOW_CUSTOM_SMT=true` only in isolated trusted environments; requests are rate-limited and capped at 32 KiB.
- PayPal live capture requires Neon persistence and a unique `(tenant_id, order_id, idempotency_key)` constraint. Capture evidence remains reconcilable if finalization fails.
- Authentication revocations are persisted to `SOLVEX_REVOCATION_FILE` (default `.sovereign_data/revoked_tokens.json`). In horizontally scaled deployments, place this on shared durable storage or replace it with a shared session store.
- The browser must use API clients for authenticated proof, theorem, Marketplace, and payment operations; server-side engines are not authority in React components.


## Release-hardening controls

- Production authentication state is shared through Neon when `NEON_DATABASE_URL` is configured. Token revocations and login-failure throttling are stored in `auth_revocations` and `auth_login_failures`; authentication fails closed if that shared state is unavailable.
- Production PayPal capture atomically reserves `(tenant_id, order_id, idempotency_key)` in Neon before any live provider request. The unique index is required; live capture fails closed if it cannot be established.
- Payment reservations are reused for finalization, preventing a second database record for the same idempotency key. A `PENDING_CAPTURE` reservation must be reconciled before retrying after an uncertain external outcome.
- Production responses include a strict Content Security Policy and standard browser security headers. Legacy inline Blink picker/bootstrap scripts are no longer part of the production document.
- The application does not replace `window.fetch`; API requests remain explicit and status/content-type driven.
