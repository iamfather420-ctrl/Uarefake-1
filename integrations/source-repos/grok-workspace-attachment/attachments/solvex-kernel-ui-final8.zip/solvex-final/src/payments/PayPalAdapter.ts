import { computeSha256 } from '../database/DatabaseSchema';
import { SqliteStore } from '../database/SqliteStore';
import { NeonStore } from '../database/NeonPersistence';

export interface PayPalCredentials {
  clientId: string;
  clientSecret: string;
  environment: 'sandbox' | 'live';
}

export type PayPalGatewayState =
  | 'NOT_CONFIGURED'
  | 'CONFIGURED'
  | 'AUTHENTICATED'
  | 'ORDER_CREATED'
  | 'ORDER_CAPTURED'
  | 'RESPONSE_VALIDATED'
  | 'TRANSACTION_IDENTITY_VERIFIED'
  | 'SANDBOX_VERIFIED'
  | 'PRODUCTION_VERIFIED'
  | 'EXTERNAL_PROVIDER_REQUIRED'
  | 'PAYPAL_API_ERROR';

export interface PaymentCaptureResult {
  success: boolean;
  status: 'COMPLETED' | 'EXTERNAL_PROVIDER_REQUIRED' | 'AUTHENTICATION_FAILED' | 'PAYPAL_API_ERROR' | 'IDEMPOTENCY_CONFLICT' | 'PERSISTENCE_FAILURE';
  claim_scope: 'SANDBOX' | 'PRODUCTION' | 'LOCAL';
  gateway_state: PayPalGatewayState;
  payment?: {
    order_id: string;
    amount_cents: number;
    currency: string;
    provider: string;
    status: string;
    idempotency_key: string;
    receipt_hash: string;
    paypal_order_id?: string;
    paypal_capture_id?: string;
    raw_provider_response?: any;
    created_at: number;
  };
  error?: string;
}

export interface PayPalVerificationTestResult {
  valid: boolean;
  status_code: number;
  environment: 'sandbox' | 'live';
  gateway_state: PayPalGatewayState;
  client_id_preview: string;
  app_id?: string;
  token_type?: string;
  expires_in?: number;
  message: string;
  timestamp: number;
}

export class PayPalAdapter {
  private static instance: PayPalAdapter | null = null;
  private sessionCredentials: PayPalCredentials | null = null;

  private constructor() {
    // Strictly server-authoritative in-memory credentials only.
    // Client secrets MUST NEVER be written to or read from browser localStorage, sessionStorage, or IndexedDB.
  }

  public static getInstance(): PayPalAdapter {
    if (!PayPalAdapter.instance) {
      PayPalAdapter.instance = new PayPalAdapter();
    }
    return PayPalAdapter.instance;
  }

  public getActiveEnvironment(): 'sandbox' | 'live' {
    if (typeof process === 'undefined' || !process.env) return 'sandbox';
    const active = process.env.PAYPAL_ACTIVE_ENVIRONMENT || process.env.PAYPAL_ENVIRONMENT || process.env.SOLVEX_ENV;
    if (active && (active.toLowerCase() === 'live' || active.toLowerCase() === 'production')) {
      return 'live';
    }
    return 'sandbox';
  }

  public getSandboxCredentials(): PayPalCredentials | null {
    if (typeof process === 'undefined' || !process.env) return null;
    const cid = process.env.PAYPAL_SANDBOX_CLIENT_ID || process.env.PAYPAL_SANDBOX_ID || (this.getActiveEnvironment() === 'sandbox' ? process.env.PAYPAL_CLIENT_ID : undefined);
    const sec = process.env.PAYPAL_SANDBOX_CLIENT_SECRET || process.env.PAYPAL_SANDBOX_SECRET || process.env.PAYPAL_SANDBOX_KEY || process.env.PAYPAL_CLIENT_SECRET;
    if (cid && sec) {
      return {
        clientId: cid.trim(),
        clientSecret: sec.trim(),
        environment: 'sandbox'
      };
    }
    return null;
  }

  public getLiveCredentials(): PayPalCredentials | null {
    if (typeof process === 'undefined' || !process.env) return null;
    const cid = process.env.PAYPAL_LIVE_CLIENT_ID || process.env.PAYPAL_LIVE_ID || (this.getActiveEnvironment() === 'live' ? process.env.PAYPAL_CLIENT_ID : undefined);
    const sec = process.env.PAYPAL_LIVE_CLIENT_SECRET || process.env.PAYPAL_LIVE_SECRET || process.env.PAYPAL_LIVE_LIVE_NT_SECRET || (this.getActiveEnvironment() === 'live' ? process.env.PAYPAL_CLIENT_SECRET : undefined);
    if (cid && sec) {
      return {
        clientId: cid.trim(),
        clientSecret: sec.trim(),
        environment: 'live'
      };
    }
    return null;
  }

  public getEffectiveCredentials(): PayPalCredentials | null {
    // Production is environment-authoritative: browser/session credentials can never override live deployment secrets.
    const productionLocked = typeof process !== 'undefined' && process.env?.SOLVEX_ENV?.toLowerCase() === 'production';
    if (!productionLocked && this.sessionCredentials && this.sessionCredentials.clientId && this.sessionCredentials.clientSecret) {
      return this.sessionCredentials;
    }
    const envMode = this.getActiveEnvironment();
    if (envMode === 'live') {
      return this.getLiveCredentials();
    }
    return this.getSandboxCredentials();
  }

  public setSessionCredentials(clientId: string, clientSecret: string, environment: 'sandbox' | 'live' = 'sandbox'): boolean {
    if (typeof process !== 'undefined' && process.env?.SOLVEX_ENV?.toLowerCase() === 'production') {
      return false;
    }
    this.sessionCredentials = {
      clientId: clientId.trim(),
      clientSecret: clientSecret.trim(),
      environment
    };
    // Strictly in-memory; never stored in localStorage/sessionStorage
    return true;
  }

  public clearSessionCredentials(): void {
    this.sessionCredentials = null;
  }

  public hasActiveCredentials(): boolean {
    const creds = this.getEffectiveCredentials();
    return Boolean(creds && creds.clientId && creds.clientSecret);
  }

  public getMaskedCredentialsInfo(): {
    configured: boolean;
    source: 'ENVIRONMENT' | 'SESSION' | 'NONE';
    environment: 'sandbox' | 'live';
    gateway_state: PayPalGatewayState;
    masked_client_id: string;
    masked_secret: string;
  } {
    const creds = this.getEffectiveCredentials();
    if (!creds) {
      return {
        configured: false,
        source: 'NONE',
        environment: 'sandbox',
        gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
        masked_client_id: 'Not Configured',
        masked_secret: 'Not Configured'
      };
    }
    const source = this.sessionCredentials ? 'SESSION' : 'ENVIRONMENT';
    const mask = (str: string) => str.length > 8 ? `${str.slice(0, 4)}...${str.slice(-4)}` : '••••••••';
    return {
      configured: true,
      source,
      environment: creds.environment,
      gateway_state: 'CONFIGURED',
      masked_client_id: mask(creds.clientId),
      masked_secret: mask(creds.clientSecret)
    };
  }

  public async acquireOAuthToken(creds?: PayPalCredentials): Promise<{
    access_token?: string;
    token_type?: string;
    app_id?: string;
    expires_in?: number;
    status_code: number;
    error?: string;
  }> {
    const activeCreds = creds || this.getEffectiveCredentials();
    if (!activeCreds || !activeCreds.clientId || !activeCreds.clientSecret) {
      return { status_code: 401, error: 'PayPal credentials missing from runtime environment.' };
    }

    const host = activeCreds.environment === 'live'
      ? 'https://api-m.paypal.com'
      : 'https://api-m.sandbox.paypal.com';

    const authHeader = typeof btoa === 'function'
      ? btoa(`${activeCreds.clientId}:${activeCreds.clientSecret}`)
      : Buffer.from(`${activeCreds.clientId}:${activeCreds.clientSecret}`).toString('base64');

    try {
      const response = await fetch(`${host}/v1/oauth2/token`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${authHeader}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'grant_type=client_credentials'
      });

      const body = await response.json();
      if (response.ok && body.access_token) {
        return {
          access_token: body.access_token,
          token_type: body.token_type,
          app_id: body.app_id,
          expires_in: body.expires_in,
          status_code: response.status
        };
      }
      return {
        status_code: response.status,
        error: body.error_description || body.error || `HTTP ${response.status} Authentication Failed`
      };
    } catch (err: any) {
      return {
        status_code: 0,
        error: `Network failure connecting to PayPal REST endpoint: ${err.message}`
      };
    }
  }

  public async testLiveCredentials(
    overrideClientId?: string,
    overrideSecret?: string,
    overrideEnv?: 'sandbox' | 'live'
  ): Promise<PayPalVerificationTestResult> {
    const creds = overrideClientId && overrideSecret
      ? { clientId: overrideClientId, clientSecret: overrideSecret, environment: overrideEnv || 'sandbox' }
      : this.getEffectiveCredentials();

    if (!creds || !creds.clientId || !creds.clientSecret) {
      return {
        valid: false,
        status_code: 401,
        environment: 'sandbox',
        gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
        client_id_preview: 'NONE',
        message: 'No PayPal Client ID and Secret provided. Server-authoritative fail-closed enforced.',
        timestamp: Date.now()
      };
    }

    const oauth = await this.acquireOAuthToken(creds);

    if (oauth.access_token) {
      return {
        valid: true,
        status_code: oauth.status_code,
        environment: creds.environment,
        gateway_state: 'AUTHENTICATED',
        client_id_preview: creds.clientId.substring(0, 8) + '...',
        app_id: oauth.app_id,
        token_type: oauth.token_type,
        expires_in: oauth.expires_in,
        message: `Successfully authenticated with PayPal ${creds.environment.toUpperCase()} REST API! OAuth2 token obtained.`,
        timestamp: Date.now()
      };
    }

    return {
      valid: false,
      status_code: oauth.status_code,
      environment: creds.environment,
      gateway_state: 'PAYPAL_API_ERROR',
      client_id_preview: creds.clientId.substring(0, 8) + '...',
      message: `PayPal authentication failed: ${oauth.error}`,
      timestamp: Date.now()
    };
  }

  /**
   * Real Server-Authoritative PayPal Order Capture
   * Follows strict state machine:
   * 1. Check credentials -> if absent, fail closed: EXTERNAL_PROVIDER_REQUIRED.
   * 2. Call OAuth2 token acquisition -> if fails, fail closed: AUTHENTICATION_FAILED.
   * 3. Call Orders v2 API -> POST /v2/checkout/orders
   * 4. Call Orders v2 Capture -> POST /v2/checkout/orders/{id}/capture
   * 5. Validate status, amounts, capture IDs, timestamps.
   * 6. Commit evidence and idempotent receipt hash to SQLite.
   */
  public async captureOrderPayment(
    orderId: string,
    amountCents: number,
    idempotencyKey: string,
    tenantId: string
  ): Promise<PaymentCaptureResult> {
    const sqlite = SqliteStore.getInstance();
    const creds = this.getEffectiveCredentials();
    const production = creds?.environment === 'live';
    if (!production) {
      const existing = sqlite.findTenantRecords<any>('payments', tenantId).find((p: any) => p.order_id === orderId && p.idempotency_key === idempotencyKey);
      if (existing) {
        if (existing.amount_cents !== amountCents) return { success: false, status: 'IDEMPOTENCY_CONFLICT', claim_scope: 'LOCAL', gateway_state: 'PAYPAL_API_ERROR', error: 'Idempotency key already used with a different amount.' };
        if (existing.status === 'COMPLETED') return { success: true, status: 'COMPLETED', claim_scope: 'SANDBOX', gateway_state: 'SANDBOX_VERIFIED', payment: existing };
        return { success: false, status: 'IDEMPOTENCY_CONFLICT', claim_scope: 'LOCAL', gateway_state: 'PAYPAL_API_ERROR', error: `Payment attempt already exists with status ${existing.status}.` };
      }
    }
    const receiptHash = computeSha256(`PAYPAL_RECEIPT:${orderId}:${amountCents}:${idempotencyKey}`);
    const neon = NeonStore.getInstance();
    const paymentId = `pay_${Date.now()}_${idempotencyKey}`;
    const providerRequestId = `solvex-order-${orderId}`;
    const providerCaptureRequestId = `solvex-order-${orderId}-capture`;
    let productionOrderLeaseHeld = false;
    try {
    if (production) {
      const connected = await neon.connect();
      if (!connected) return { success: false, status: 'PERSISTENCE_FAILURE', claim_scope: 'PRODUCTION', gateway_state: 'EXTERNAL_PROVIDER_REQUIRED', error: 'Neon production persistence connection failed; live PayPal execution blocked.' };
      await neon.runMigrations();
      const constraintReady = await neon.ensurePaymentIdempotencyConstraint();
      const leaseTableReady = await neon.ensurePaymentOrderLeaseTable();
      if (!leaseTableReady) return { success: false, status: 'PERSISTENCE_FAILURE', claim_scope: 'PRODUCTION', gateway_state: 'EXTERNAL_PROVIDER_REQUIRED', error: 'Payment order lease table could not be established; live PayPal execution blocked.' };
      if (!constraintReady) return { success: false, status: 'PERSISTENCE_FAILURE', claim_scope: 'PRODUCTION', gateway_state: 'EXTERNAL_PROVIDER_REQUIRED', error: 'Payment idempotency constraint could not be established; live PayPal execution blocked.' };
      productionOrderLeaseHeld = await neon.acquirePaymentOrderLease(tenantId, orderId, providerRequestId);
      if (!productionOrderLeaseHeld) return { success: false, status: 'IDEMPOTENCY_CONFLICT', claim_scope: 'PRODUCTION', gateway_state: 'PAYPAL_API_ERROR', error: 'Another payment capture for this order is already in progress; retry after reconciliation.' };
      const reservation = await neon.reservePaymentAttempt(tenantId, orderId, amountCents, idempotencyKey, paymentId, receiptHash);
      if (!reservation.reserved) {
        const durableExisting = reservation.existing;
        if (!durableExisting) return { success: false, status: 'PERSISTENCE_FAILURE', claim_scope: 'PRODUCTION', gateway_state: 'EXTERNAL_PROVIDER_REQUIRED', error: 'Could not atomically reserve the payment idempotency key; live PayPal execution blocked.' };
        if (Number(durableExisting.amount_cents) !== amountCents) return { success: false, status: 'IDEMPOTENCY_CONFLICT', claim_scope: 'PRODUCTION', gateway_state: 'PAYPAL_API_ERROR', error: 'Idempotency key already used with a different amount.' };
        if (durableExisting.status === 'COMPLETED' || durableExisting.status === 'CAPTURED_UNFINALIZED') return { success: true, status: 'COMPLETED', claim_scope: 'PRODUCTION', gateway_state: 'PRODUCTION_VERIFIED', payment: durableExisting };
        return { success: false, status: 'IDEMPOTENCY_CONFLICT', claim_scope: 'PRODUCTION', gateway_state: 'PAYPAL_API_ERROR', error: `Payment attempt already exists with status ${durableExisting.status}; reconcile before retrying.` };
      }
    }

    if (!creds || !creds.clientId || !creds.clientSecret) {
      const paymentRecord = {
        order_id: orderId,
        amount_cents: amountCents,
        currency: 'USD',
        provider: 'PAYPAL_DN35',
        status: 'EXTERNAL_PROVIDER_REQUIRED',
        idempotency_key: idempotencyKey,
        receipt_hash: receiptHash,
        created_at: Date.now()
      };

      try {
        sqlite.insertRecord('payments', {
          id: `pay_${Date.now()}`,
          tenant_id: tenantId,
          ...paymentRecord
        });
      } catch {}

      return {
        success: false,
        status: 'EXTERNAL_PROVIDER_REQUIRED',
        claim_scope: 'LOCAL',
        gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
        payment: paymentRecord,
        error: 'PayPal credentials missing from runtime environment. Server-authoritative fail-closed enforced; zero fake receipts.'
      };
    }

    // Step 1: Real OAuth2 Authentication
    const oauth = await this.acquireOAuthToken(creds);
    if (!oauth.access_token) {
      return {
        success: false,
        status: 'AUTHENTICATION_FAILED',
        claim_scope: creds.environment === 'live' ? 'PRODUCTION' : 'SANDBOX',
        gateway_state: 'PAYPAL_API_ERROR',
        error: `PayPal OAuth2 failed: ${oauth.error}. Refusing execution; fail-closed active.`
      };
    }

    const host = creds.environment === 'live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
    const amountFormatted = (amountCents / 100).toFixed(2);

    // Production money movement is fail-closed on durable persistence.
    // We must establish the Neon evidence record before creating/capturing a live PayPal order.
    if (production) {
      if (!neon.isConfigured()) {
        return {
          success: false,
          status: 'PERSISTENCE_FAILURE',
          claim_scope: 'PRODUCTION',
          gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
          error: 'Neon production persistence is required before live PayPal execution.'
        };
      }
      const connected = await neon.connect();
      if (!connected) {
        return {
          success: false,
          status: 'PERSISTENCE_FAILURE',
          claim_scope: 'PRODUCTION',
          gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
          error: 'Neon production persistence connection failed; live PayPal execution blocked.'
        };
      }
      const migrated = await neon.runMigrations();
      if (!migrated.success) {
        return {
          success: false,
          status: 'PERSISTENCE_FAILURE',
          claim_scope: 'PRODUCTION',
          gateway_state: 'EXTERNAL_PROVIDER_REQUIRED',
          error: `Neon production schema initialization failed: ${migrated.error || 'unknown error'}`
        };
      }
    }

    try {
      // Step 2: Create Order in PayPal Orders v2 API
      const createOrderRes = await fetch(`${host}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${oauth.access_token}`,
          'Content-Type': 'application/json',
          'PayPal-Request-Id': providerRequestId
        },
        body: JSON.stringify({
          intent: 'CAPTURE',
          purchase_units: [
            {
              reference_id: orderId,
              amount: {
                currency_code: 'USD',
                value: amountFormatted
              },
              description: `Project AGATE Sovereign Solution: Order ${orderId}`
            }
          ]
        })
      });

      const orderBody = await createOrderRes.json();
      if (!createOrderRes.ok || !orderBody.id) {
        return {
          success: false,
          status: 'PAYPAL_API_ERROR',
          claim_scope: creds.environment === 'live' ? 'PRODUCTION' : 'SANDBOX',
          gateway_state: 'PAYPAL_API_ERROR',
          error: `PayPal order creation rejected (${createOrderRes.status}): ${orderBody.message || JSON.stringify(orderBody)}`
        };
      }

      const paypalOrderId = orderBody.id;
      if (production) {
        const recorded = await neon.updatePaymentAttempt(paymentId, tenantId, { paypal_order_id: paypalOrderId, status: 'PAYPAL_ORDER_CREATED' });
        if (!recorded) return { success: false, status: 'PERSISTENCE_FAILURE', claim_scope: 'PRODUCTION', gateway_state: 'EXTERNAL_PROVIDER_REQUIRED', error: 'Could not persist the PayPal order identifier; capture blocked to preserve recoverability.' };
      }

      // Step 3: Capture the Created Order
      const captureRes = await fetch(`${host}/v2/checkout/orders/${paypalOrderId}/capture`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${oauth.access_token}`,
          'Content-Type': 'application/json',
          'PayPal-Request-Id': providerCaptureRequestId
        }
      });

      const captureBody = await captureRes.json();
      const captures = captureBody.purchase_units?.[0]?.payments?.captures;
      const primaryCapture = captures?.[0];

      const capturedAmount = Number(primaryCapture?.amount?.value);
      const capturedCurrency = primaryCapture?.amount?.currency_code;
      const responseOrderId = captureBody.id;
      const referenceId = captureBody.purchase_units?.[0]?.reference_id;
      const captureMatchesOrder = responseOrderId === paypalOrderId && referenceId === orderId && Boolean(primaryCapture?.id);
      if (captureRes.ok && (captureBody.status === 'COMPLETED' || primaryCapture?.status === 'COMPLETED') && capturedCurrency === 'USD' && capturedAmount === Number(amountFormatted) && captureMatchesOrder) {
        const captureId = primaryCapture?.id || paypalOrderId;
        const confirmedScope = creds.environment === 'live' ? 'PRODUCTION' : 'SANDBOX';
        const confirmedState = creds.environment === 'live' ? 'PRODUCTION_VERIFIED' : 'SANDBOX_VERIFIED';

        const paymentRecord = {
          order_id: orderId,
          amount_cents: amountCents,
          currency: 'USD',
          provider: `PAYPAL_DN35_${creds.environment.toUpperCase()}`,
          status: 'COMPLETED',
          idempotency_key: idempotencyKey,
          receipt_hash: receiptHash,
          paypal_order_id: paypalOrderId,
          paypal_capture_id: captureId,
          raw_provider_response: captureBody,
          created_at: Date.now()
        };

        try {
          sqlite.insertRecord('payments', {
            id: production ? paymentId : `pay_${Date.now()}`,
            tenant_id: tenantId,
            ...paymentRecord,
            raw_provider_response: JSON.stringify(captureBody)
          });
        } catch {}

        if (production) {
          const persisted = await neon.insertRecord('payments', {
            id: paymentId,
            tenant_id: tenantId,
            ...paymentRecord,
            raw_provider_response: captureBody
          });
          if (!persisted) {
            return {
              success: false,
              status: 'PERSISTENCE_FAILURE',
              claim_scope: 'PRODUCTION',
              gateway_state: 'PRODUCTION_VERIFIED',
              payment: { ...paymentRecord, status: 'CAPTURED_UNFINALIZED' },
              error: 'PayPal Live capture completed but Neon evidence finalization failed. Durable pending evidence remains for reconciliation.'
            };
          }
        }

        if (production && productionOrderLeaseHeld) await neon.releasePaymentOrderLease(tenantId, orderId, providerRequestId);
        return {
          success: true,
          status: 'COMPLETED',
          claim_scope: confirmedScope,
          gateway_state: confirmedState,
          payment: paymentRecord
        };
      } else {
        return {
          success: false,
          status: 'PAYPAL_API_ERROR',
          claim_scope: creds.environment === 'live' ? 'PRODUCTION' : 'SANDBOX',
          gateway_state: 'PAYPAL_API_ERROR',
          error: `PayPal capture was not completed (${captureRes.status}): status=${captureBody.status}, message=${captureBody.message || 'Capture not confirmed'}`
        };
      }
    } catch (netErr: any) {
      return {
        success: false,
        status: 'PAYPAL_API_ERROR',
        claim_scope: creds.environment === 'live' ? 'PRODUCTION' : 'SANDBOX',
        gateway_state: 'PAYPAL_API_ERROR',
        error: `Network failure executing PayPal REST capture: ${netErr.message}`
      };
    }
    } finally {
      if (production && productionOrderLeaseHeld) await neon.releasePaymentOrderLease(tenantId, orderId, providerRequestId);
    }
  }
}
