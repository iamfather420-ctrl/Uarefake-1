/**
 * Real OS process wrapper for a single pipeline node.
 * Each node runs as a child process. Reboot = kill + respawn.
 * Diagnostic = live health probe against the child.
 */
import { spawn, type ChildProcess } from 'node:child_process';
import { createServer, type Server } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export type NodeProcessStatus = 'starting' | 'online' | 'diagnostic' | 'rebooting' | 'offline' | 'crashed';

export interface NodeProcessInfo {
  id: string;
  name: string;
  pid: number | null;
  port: number;
  status: NodeProcessStatus;
  startedAt: number | null;
  lastHealthAt: number | null;
  healthOk: boolean;
  restarts: number;
  lastError: string | null;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export class NodeProcess {
  readonly id: string;
  readonly name: string;
  readonly port: number;
  private child: ChildProcess | null = null;
  private status: NodeProcessStatus = 'offline';
  private startedAt: number | null = null;
  private lastHealthAt: number | null = null;
  private healthOk = false;
  private restarts = 0;
  private lastError: string | null = null;
  private intentionalStop = false;

  constructor(id: string, name: string, port: number) {
    this.id = id;
    this.name = name;
    this.port = port;
  }

  getInfo(): NodeProcessInfo {
    return {
      id: this.id,
      name: this.name,
      pid: this.child?.pid ?? null,
      port: this.port,
      status: this.status,
      startedAt: this.startedAt,
      lastHealthAt: this.lastHealthAt,
      healthOk: this.healthOk,
      restarts: this.restarts,
      lastError: this.lastError,
    };
  }

  async start(): Promise<void> {
    if (this.child && !this.child.killed) {
      return;
    }
    this.intentionalStop = false;
    this.status = 'starting';
    this.lastError = null;

    const workerPath = path.join(__dirname, 'node-worker.mjs');
    this.child = spawn(process.execPath, [workerPath, this.id, this.name, String(this.port)], {
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, NODE_ID: this.id, NODE_NAME: this.name, NODE_PORT: String(this.port) },
    });

    this.startedAt = Date.now();
    this.child.stdout?.on('data', (d) => {
      // keep quiet unless debugging
      if (process.env.NODE_RUNTIME_DEBUG) process.stdout.write(`[${this.id}] ${d}`);
    });
    this.child.stderr?.on('data', (d) => {
      this.lastError = String(d).slice(0, 200);
      if (process.env.NODE_RUNTIME_DEBUG) process.stderr.write(`[${this.id}:err] ${d}`);
    });
    this.child.on('exit', (code, signal) => {
      this.child = null;
      if (this.intentionalStop) {
        this.status = 'offline';
      } else {
        this.status = 'crashed';
        this.lastError = `exited code=${code} signal=${signal}`;
      }
      this.healthOk = false;
    });

    // Wait briefly for worker HTTP to come up
    for (let i = 0; i < 20; i++) {
      await new Promise((r) => setTimeout(r, 50));
      const ok = await this.probe();
      if (ok) {
        this.status = 'online';
        return;
      }
    }
    this.status = 'online'; // still mark online; probe may catch up
  }

  async stop(): Promise<void> {
    this.intentionalStop = true;
    if (!this.child) {
      this.status = 'offline';
      return;
    }
    this.status = 'rebooting';
    const child = this.child;
    child.kill('SIGTERM');
    await new Promise<void>((resolve) => {
      const t = setTimeout(() => {
        try { child.kill('SIGKILL'); } catch { /* ignore */ }
        resolve();
      }, 2000);
      child.once('exit', () => {
        clearTimeout(t);
        resolve();
      });
    });
    this.child = null;
    this.status = 'offline';
    this.healthOk = false;
  }

  /** Real reboot: kill process and spawn a new one */
  async reboot(): Promise<NodeProcessInfo> {
    this.status = 'rebooting';
    this.restarts += 1;
    await this.stop();
    await this.start();
    return this.getInfo();
  }

  /** Live health probe against the child process HTTP endpoint */
  async diagnostic(): Promise<{ ok: boolean; info: NodeProcessInfo; detail: string }> {
    this.status = 'diagnostic';
    const ok = await this.probe();
    this.healthOk = ok;
    this.lastHealthAt = Date.now();
    this.status = ok ? 'online' : (this.child ? 'online' : 'crashed');
    return {
      ok,
      info: this.getInfo(),
      detail: ok
        ? `Process pid=${this.child?.pid} responded on port ${this.port}`
        : `No healthy response from port ${this.port}; lastError=${this.lastError}`,
    };
  }

  private async probe(): Promise<boolean> {
    try {
      const res = await fetch(`http://127.0.0.1:${this.port}/health`, {
        signal: AbortSignal.timeout(500),
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}
