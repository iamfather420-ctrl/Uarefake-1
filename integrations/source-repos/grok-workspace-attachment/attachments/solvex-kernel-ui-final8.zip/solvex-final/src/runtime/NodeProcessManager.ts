/**
 * Owns the full set of 54 real OS processes for the Solvex pipeline nodes.
 * Start / stop / reboot / diagnostic operate on actual child processes.
 */
import { NodeProcess, type NodeProcessInfo } from './NodeProcess.ts';
import { NodeRegistry } from '../nodes/NodeRegistry.ts';

const BASE_PORT = 41001; // 41001 .. 41054

export class NodeProcessManager {
  private static instance: NodeProcessManager | null = null;
  private nodes = new Map<string, NodeProcess>();
  private started = false;

  private constructor() {
    const registry = NodeRegistry.getInstance().getAllNodes();
    registry.forEach((n, idx) => {
      const port = BASE_PORT + idx;
      this.nodes.set(n.id, new NodeProcess(n.id, n.name, port));
    });
  }

  static getInstance(): NodeProcessManager {
    if (!NodeProcessManager.instance) {
      NodeProcessManager.instance = new NodeProcessManager();
    }
    return NodeProcessManager.instance;
  }

  async startAll(): Promise<{ started: number; total: number }> {
    if (this.started) return { started: this.nodes.size, total: this.nodes.size };
    const list = Array.from(this.nodes.values());
    // Start in small batches to avoid fork storm
    const batchSize = 8;
    for (let i = 0; i < list.length; i += batchSize) {
      const batch = list.slice(i, i + batchSize);
      await Promise.all(batch.map((n) => n.start()));
    }
    this.started = true;
    return { started: list.length, total: list.length };
  }

  async stopAll(): Promise<void> {
    const list = Array.from(this.nodes.values());
    await Promise.all(list.map((n) => n.stop()));
    this.started = false;
  }

  list(): NodeProcessInfo[] {
    return Array.from(this.nodes.values()).map((n) => n.getInfo());
  }

  get(id: string): NodeProcess | undefined {
    return this.nodes.get(id);
  }

  async reboot(id: string): Promise<NodeProcessInfo> {
    const n = this.nodes.get(id);
    if (!n) throw new Error(`Unknown node ${id}`);
    return n.reboot();
  }

  async diagnostic(id: string): Promise<{ ok: boolean; info: NodeProcessInfo; detail: string }> {
    const n = this.nodes.get(id);
    if (!n) throw new Error(`Unknown node ${id}`);
    return n.diagnostic();
  }

  summary(): { total: number; online: number; offline: number; crashed: number; rebooting: number } {
    const infos = this.list();
    return {
      total: infos.length,
      online: infos.filter((i) => i.status === 'online').length,
      offline: infos.filter((i) => i.status === 'offline').length,
      crashed: infos.filter((i) => i.status === 'crashed').length,
      rebooting: infos.filter((i) => i.status === 'rebooting' || i.status === 'starting').length,
    };
  }
}
