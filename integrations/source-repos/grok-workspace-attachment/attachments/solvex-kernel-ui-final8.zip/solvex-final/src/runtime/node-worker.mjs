/**
 * Worker entrypoint for a single pipeline node.
 * Runs as a real OS child process with its own HTTP health endpoint.
 */
import { createServer } from 'node:http';

const id = process.argv[2] || process.env.NODE_ID || 'UNKNOWN';
const name = process.argv[3] || process.env.NODE_NAME || 'unnamed';
const port = Number(process.argv[4] || process.env.NODE_PORT || 0);

if (!port) {
  console.error('NODE_PORT required');
  process.exit(1);
}

let requests = 0;
const startedAt = Date.now();

const server = createServer((req, res) => {
  requests += 1;
  const url = req.url || '/';
  if (url === '/health' || url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      id,
      name,
      pid: process.pid,
      uptime_ms: Date.now() - startedAt,
      requests,
      status: 'ok',
    }));
    return;
  }
  if (url === '/ping') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ pong: true, id, pid: process.pid }));
    return;
  }
  res.writeHead(404);
  res.end('not found');
});

// Exit if the supervisor dies (e.g. SIGKILL/crash): never leave orphan workers holding ports.
const supervisorPid = process.ppid;
setInterval(() => {
  if (process.ppid !== supervisorPid) process.exit(0);
}, 1000);

server.listen(port, '127.0.0.1', () => {
  console.log(JSON.stringify({ event: 'node_online', id, name, pid: process.pid, port }));
});

process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1000);
});
