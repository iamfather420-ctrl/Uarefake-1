import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect, useMemo, useState } from 'react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { apiRequest } from '@/api/client'

const GOLD = '#D4AF37'
const BG = '#05080F'
const BG_PANEL = '#0A0F1A'
const MUTED = '#6B7280'
const BORDER = '#1A2235'
const ACCENT_DIM = '#162040'
const MONO = '"IBM Plex Mono", "Courier New", monospace'
const SERIF = '"Playfair Display", "Georgia", serif'

type RiskClass = 'LOW' | 'MEDIUM' | 'HIGH'
interface Offer {
  id: string
  offer_id: string
  solution_id: string
  proof_bundle_id: string
  title: string
  description: string
  price_cents: number
  cost_basis_cents: number
  verification_complexity_factor: number
  risk_class: RiskClass
  verification_status: string
  published: boolean | number
  status?: string
}

const FILTERS = ['ALL', 'LOW RISK', 'MEDIUM RISK', 'HIGH RISK'] as const

export const Route = createFileRoute('/marketplace')({
  head: () => ({ meta: [{ title: 'Verified Marketplace · SolveX' }] }),
  component: Marketplace,
})

function Marketplace() {
  const [offers, setOffers] = useState<Offer[]>([])
  const [activeFilter, setActiveFilter] = useState<(typeof FILTERS)[number]>('ALL')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    void apiRequest<Offer[]>('/api/offers')
      .then(data => { if (active) setOffers(data.filter(o => o.published && o.verification_status === 'VERIFIED')) })
      .catch(err => { if (active) setError(err instanceof Error ? err.message : 'Marketplace request failed') })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])

  const filteredOffers = useMemo(() => {
    if (activeFilter === 'ALL') return offers
    const risk = activeFilter.replace(' RISK', '')
    return offers.filter(o => o.risk_class === risk)
  }, [offers, activeFilter])

  return (
    <DashboardLayout>
      <div style={{ borderBottom: `1px solid ${BORDER}`, padding: '10px 32px', fontFamily: MONO, fontSize: 9, letterSpacing: '0.12em', color: MUTED, textTransform: 'uppercase' }}>
        SOLVEX · VERIFIED MARKETPLACE · AUTHORITATIVE OFFERS ONLY
      </div>

      <div style={{ padding: '40px 32px 28px', textAlign: 'center' }}>
        <h1 style={{ fontFamily: SERIF, fontSize: 'clamp(28px, 4.5vw, 50px)', fontWeight: 700, color: GOLD, lineHeight: 1.15, margin: 0 }}>
          Verified Solutions,
          <br />
          When Available.
        </h1>
        <p style={{ maxWidth: 720, margin: '18px auto 0', fontFamily: MONO, fontSize: 11, lineHeight: 1.7, color: MUTED }}>
          This catalog is populated exclusively from authenticated, published offers whose solution and proof bundle are already VERIFIED by the authoritative backend. No synthetic inventory is displayed.
        </p>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: 8, padding: '0 32px 24px' }}>
        {FILTERS.map(filter => {
          const active = activeFilter === filter
          return <button key={filter} onClick={() => setActiveFilter(filter)} style={{ fontFamily: MONO, fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', padding: '7px 16px', color: active ? BG : MUTED, background: active ? GOLD : ACCENT_DIM, border: `1px solid ${active ? GOLD : BORDER}`, cursor: 'pointer' }}>{filter}</button>
        })}
      </div>

      {error && <div style={{ margin: '0 28px 24px', padding: 14, border: '1px solid #713f46', background: '#1a0d12', color: '#fda4af', fontFamily: MONO, fontSize: 11 }}>Marketplace unavailable: {error}</div>}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(310px, 1fr))', gap: 18, padding: 28 }}>
        {loading ? <EmptyState title="Loading verified offers…" /> : filteredOffers.length === 0 ? <EmptyState title="No verified offers are currently published." detail="Nothing synthetic is shown when the authoritative marketplace has no verified inventory." /> : filteredOffers.map((offer, index) => <OfferCard key={offer.id} offer={offer} index={index} />)}
      </div>

      <div style={{ padding: '24px 32px', textAlign: 'center', borderTop: `1px solid ${BORDER}` }}>
        <span style={{ fontFamily: MONO, fontSize: 9, letterSpacing: '0.1em', color: MUTED, textTransform: 'uppercase' }}>
          {filteredOffers.length} VERIFIED OFFERS DISPLAYED · SERVER AUTHORITATIVE
        </span>
      </div>
    </DashboardLayout>
  )
}

function EmptyState({ title, detail }: { title: string; detail?: string }) {
  return <div style={{ gridColumn: '1 / -1', padding: '64px 24px', textAlign: 'center', border: `1px solid ${BORDER}`, background: BG_PANEL }}><div style={{ fontFamily: SERIF, fontSize: 24, color: GOLD }}>{title}</div>{detail && <div style={{ maxWidth: 620, margin: '12px auto 0', fontFamily: MONO, fontSize: 10, lineHeight: 1.7, color: MUTED }}>{detail}</div>}</div>
}

function OfferCard({ offer, index }: { offer: Offer; index: number }) {
  return <div style={{ background: BG_PANEL, border: `1px solid ${BORDER}`, padding: 24, display: 'flex', flexDirection: 'column', gap: 14, animation: 'fadeInCard 0.35s ease-out both', animationDelay: `${Math.min(index * 30, 300)}ms` }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}><span style={{ fontFamily: MONO, fontSize: 8, letterSpacing: '0.12em', padding: '3px 8px', background: ACCENT_DIM, color: GOLD, border: `1px solid ${BORDER}` }}>VERIFIED OFFER</span><span style={{ fontFamily: MONO, fontSize: 9, color: MUTED }}>{offer.risk_class} RISK</span></div>
    <h3 style={{ fontFamily: SERIF, fontSize: 20, fontWeight: 600, color: GOLD, lineHeight: 1.35, margin: 0 }}>{offer.title}</h3>
    <p style={{ fontFamily: MONO, fontSize: 11, lineHeight: 1.7, color: 'rgba(200,210,225,0.65)', margin: 0 }}>{offer.description}</p>
    <div style={{ marginTop: 'auto' }}><div style={{ fontFamily: SERIF, fontSize: 26, fontWeight: 700, color: GOLD }}>${(offer.price_cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div><div style={{ fontFamily: MONO, fontSize: 9, color: MUTED, marginTop: 4 }}>SERVER-PERSISTED PRICE · {offer.solution_id} · {offer.proof_bundle_id}</div></div>
    <div style={{ height: 1, background: BORDER }} />
    <Link to="/app" style={{ fontFamily: MONO, fontSize: 9, fontWeight: 700, letterSpacing: '0.12em', color: GOLD, textDecoration: 'none' }}>OPEN AUTHENTICATED MARKETPLACE →</Link>
  </div>
}

const PAGE_KEYFRAMES = `@keyframes fadeInCard { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }`

void PAGE_KEYFRAMES
