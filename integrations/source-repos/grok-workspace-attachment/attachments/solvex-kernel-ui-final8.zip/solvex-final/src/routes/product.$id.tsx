import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { DashboardLayout } from '@/components/DashboardLayout'
import { apiRequest } from '@/api/client'

interface Offer { id: string; offer_id: string; solution_id: string; proof_bundle_id: string; title: string; description: string; price_cents: number; risk_class: string; verification_status: string; published: boolean | number }

export const Route = createFileRoute('/product/$id')({ head: () => ({ meta: [{ title: 'Verified Offer · SolveX' }] }), component: ProductDetail })

function ProductDetail() {
  const { id } = Route.useParams()
  const [offer, setOffer] = useState<Offer | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    void apiRequest<Offer[]>('/api/offers').then(offers => {
      const found = offers.find(o => (o.id === id || o.offer_id === id) && o.published && o.verification_status === 'VERIFIED')
      if (active) setOffer(found ?? null)
    }).catch(err => { if (active) setError(err instanceof Error ? err.message : 'Offer lookup failed') }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [id])

  return <DashboardLayout><div style={{ minHeight: '70vh', padding: '48px', maxWidth: 900 }}>
    <Link to="/marketplace" style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 10, color: '#6B7280', textDecoration: 'none' }}>← VERIFIED MARKETPLACE</Link>
    {loading ? <p style={{ marginTop: 40, color: '#D4AF37' }}>Loading authoritative offer…</p> : error ? <p style={{ marginTop: 40, color: '#fda4af' }}>{error}</p> : !offer ? <div style={{ marginTop: 40 }}><h1 style={{ color: '#D4AF37' }}>Verified offer not found</h1><p style={{ color: '#6B7280' }}>The requested offer is not currently published and verified by the authoritative marketplace.</p></div> : <div style={{ marginTop: 40 }}>
      <div style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, color: '#D4AF37', letterSpacing: '0.15em' }}>VERIFIED OFFER · {offer.risk_class} RISK</div>
      <h1 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 42, color: 'white', margin: '14px 0' }}>{offer.title}</h1>
      <p style={{ fontFamily: 'IBM Plex Mono, monospace', fontSize: 12, lineHeight: 1.8, color: '#A0ABC0' }}>{offer.description}</p>
      <div style={{ marginTop: 28, padding: 24, border: '1px solid #1A2235', background: '#05080F' }}>
        <div style={{ color: '#6B7280', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9 }}>SERVER-PERSISTED PRICE</div>
        <div style={{ color: '#D4AF37', fontFamily: 'Playfair Display, Georgia, serif', fontSize: 32, marginTop: 6 }}>${(offer.price_cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        <div style={{ color: '#6B7280', fontFamily: 'IBM Plex Mono, monospace', fontSize: 9, marginTop: 12 }}>SOLUTION {offer.solution_id} · PROOF BUNDLE {offer.proof_bundle_id}</div>
      </div>
    </div>}
  </div></DashboardLayout>
}
