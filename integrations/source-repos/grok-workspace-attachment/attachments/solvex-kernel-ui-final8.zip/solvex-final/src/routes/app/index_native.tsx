import { createFileRoute } from '@tanstack/react-router'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

/**
 * Dashboard home — `/app` (this file is the index of the `/app` segment, so its
 * path is `/app`, NOT `/app/index`). Rendered inside the sidebar shell defined in
 * `src/routes/app.tsx`.
 *
 * This auxiliary route intentionally exposes only real application navigation.
 * Production data is loaded by the canonical Solvex application routes.
 */
export const Route = createFileRoute('/app/')({
  head: () => ({
    meta: [
      { title: 'Dashboard · Blink App' },
      { name: 'description', content: 'Your app dashboard.' },
    ],
  }),
  component: DashboardHome,
})

function DashboardHome() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Solvex Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">Use the authenticated application routes to view live marketplace, order, and verification data.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Card><CardHeader><CardTitle className="text-sm font-medium">Marketplace</CardTitle></CardHeader><CardContent><a className="text-sm underline" href="/marketplace">Open marketplace</a></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-sm font-medium">Orders</CardTitle></CardHeader><CardContent><a className="text-sm underline" href="/orders">View orders</a></CardContent></Card>
        <Card><CardHeader><CardTitle className="text-sm font-medium">Verification</CardTitle></CardHeader><CardContent><a className="text-sm underline" href="/verification">View verification</a></CardContent></Card>
      </div>
    </div>
  )
}
