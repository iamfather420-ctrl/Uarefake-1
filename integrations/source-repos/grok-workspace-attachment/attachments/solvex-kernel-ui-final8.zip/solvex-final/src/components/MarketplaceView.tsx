import React, { useEffect, useState } from 'react';
import { ShoppingCart, Lock, FileCode, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { apiRequest } from '../api/client';
import { calculateDefensiblePrice, DefensiblePriceResult, RiskClass } from '../marketplace/pricing';
import type { UserContext } from '../auth/AuthService';

interface Offer { id: string; offer_id: string; solution_id: string; proof_bundle_id: string; title: string; description: string; price_cents: number; cost_basis_cents: number; verification_complexity_factor: number; risk_class: RiskClass; verification_status: string; published: boolean | number; }
interface Order { id: string; offer_id: string; solution_id: string; proof_bundle_id: string; price_cents: number; status: string; payment_id?: string | null; created_at: number; }

interface Props { currentUser: UserContext; onNavigateToPayPal: () => void; onNavigateToEvidence: (proofId: string) => void; }

export const MarketplaceView: React.FC<Props> = ({ currentUser, onNavigateToPayPal, onNavigateToEvidence }) => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [costBasisUsd, setCostBasisUsd] = useState(250);
  const [complexityFactor, setComplexityFactor] = useState(1.5);
  const [riskClass, setRiskClass] = useState<RiskClass>('MEDIUM');
  const [calculatedPrice, setCalculatedPrice] = useState<DefensiblePriceResult>(() => calculateDefensiblePrice(25000, 1.5, 'MEDIUM'));

  const load = async () => {
    setError(null);
    try {
      const [loadedOffers, loadedOrders] = await Promise.all([
        apiRequest<Offer[]>('/api/offers'),
        apiRequest<Order[]>('/api/orders')
      ]);
      setOffers(loadedOffers.filter(o => o.published && o.verification_status === 'VERIFIED'));
      setOrders(loadedOrders);
    } catch (e) { setError(e instanceof Error ? e.message : 'Marketplace request failed'); }
  };
  useEffect(() => { void load(); }, [currentUser.tenant_id]);

  const recalc = (basis: number, complexity: number, risk: RiskClass) => {
    setCostBasisUsd(basis); setComplexityFactor(complexity); setRiskClass(risk);
    try { setCalculatedPrice(calculateDefensiblePrice(Math.round(basis * 100), complexity, risk)); setError(null); }
    catch (e) { setError(e instanceof Error ? e.message : 'Invalid pricing inputs'); }
  };

  const createOrder = async (offerId: string) => {
    setBusy(offerId); setError(null); setMessage(null);
    try {
      const order = await apiRequest<Order>('/api/orders', { method: 'POST', body: JSON.stringify({ offer_id: offerId }) });
      setOrders(prev => [order, ...prev.filter(o => o.id !== order.id)]);
      setMessage(`Order ${order.id} created at the server-persisted price of $${(order.price_cents / 100).toFixed(2)}.`);
    } catch (e) { setError(e instanceof Error ? e.message : 'Order creation failed'); }
    finally { setBusy(null); }
  };

  const capture = async (orderId: string) => {
    setBusy(orderId); setError(null); setMessage(null);
    try {
      const result = await apiRequest<{ order: Order; payment?: { paypal_capture_id?: string; receipt_hash?: string } }>('/api/payments/capture', {
        method: 'POST', body: JSON.stringify({ order_id: orderId, idempotency_key: `capture_${orderId}` })
      });
      setOrders(prev => prev.map(o => o.id === orderId ? result.order : o));
      setMessage(`Payment captured for ${orderId}.`);
    } catch (e) { setError(e instanceof Error ? e.message : 'Payment capture failed'); }
    finally { setBusy(null); }
  };

  const transition = async (orderId: string, targetState: string) => {
    setBusy(orderId); setError(null);
    try {
      const order = await apiRequest<Order>('/api/orders/transition', { method: 'POST', body: JSON.stringify({ order_id: orderId, target_state: targetState }) });
      setOrders(prev => prev.map(o => o.id === orderId ? order : o));
    } catch (e) { setError(e instanceof Error ? e.message : 'Order transition failed'); }
    finally { setBusy(null); }
  };

  return <div className="space-y-6">
    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
      <div><div className="flex items-center gap-2 mb-1"><ShoppingCart className="w-4 h-4 text-emerald-400"/><h2 className="text-xl font-bold text-white">Enterprise B2B Solution Marketplace</h2></div><p className="text-sm text-slate-400">Authenticated catalog, tenant-scoped orders, and server-authoritative payment capture.</p></div>
      <button onClick={onNavigateToPayPal} className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold flex items-center gap-2"><Lock className="w-3.5 h-3.5"/>Manage PayPal Gateway</button>
    </div>

    {error && <div className="p-3 rounded-xl border border-rose-800 bg-rose-950/30 text-rose-300 text-sm flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0"/>{error}</div>}
    {message && <div className="p-3 rounded-xl border border-emerald-800 bg-emerald-950/30 text-emerald-300 text-sm flex gap-2"><CheckCircle2 className="w-4 h-4 shrink-0"/>{message}</div>}

    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <section className="lg:col-span-7 space-y-4"><h3 className="text-sm font-semibold text-white uppercase tracking-wider flex items-center gap-2"><FileCode className="w-4 h-4 text-cyan-400"/>Available Verified Solutions</h3>
        {offers.length === 0 ? <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900 text-slate-400">No verified offers are currently published.</div> : offers.map(offer => <div key={offer.id} className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-4"><div className="flex items-start justify-between gap-4"><div><div className="text-xs text-emerald-300 font-mono">{offer.solution_id} · {offer.proof_bundle_id}</div><h4 className="text-base font-semibold text-white mt-1">{offer.title}</h4><p className="text-xs text-slate-400 mt-1">{offer.description}</p></div><div className="text-right"><div className="text-lg font-bold text-emerald-400">${(offer.price_cents / 100).toFixed(2)}</div><div className="text-[11px] text-slate-500">server price</div></div></div><div className="flex gap-2"><button disabled={!!busy} onClick={() => void createOrder(offer.id)} className="px-4 py-2 rounded-lg bg-emerald-600 disabled:opacity-50 text-white text-xs font-semibold">{busy === offer.id ? 'Working…' : 'Create Order'}</button><button onClick={() => onNavigateToEvidence(offer.proof_bundle_id)} className="px-4 py-2 rounded-lg bg-slate-800 text-slate-200 text-xs">View Evidence</button></div></div>)}
      </section>

      <section className="lg:col-span-5 bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-4"><h3 className="text-sm font-semibold text-white">Pricing Calculator</h3><div><label className="text-xs text-slate-400">Cost basis (USD)</label><input type="number" min="0" value={costBasisUsd} onChange={e => recalc(Number(e.target.value), complexityFactor, riskClass)} className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white"/></div><div><label className="text-xs text-slate-400">Complexity factor</label><input type="number" min="0.01" max="100" step="0.01" value={complexityFactor} onChange={e => recalc(costBasisUsd, Number(e.target.value), riskClass)} className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white"/></div><div><label className="text-xs text-slate-400">Risk class</label><select value={riskClass} onChange={e => recalc(costBasisUsd, complexityFactor, e.target.value as RiskClass)} className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white"><option>LOW</option><option>MEDIUM</option><option>HIGH</option></select></div><div className="pt-3 border-t border-slate-800 flex justify-between"><span className="text-emerald-400">Calculated value</span><strong className="text-emerald-400">${(calculatedPrice.final_price_cents / 100).toFixed(2)}</strong></div><div className="text-[10px] text-slate-500 break-all">{calculatedPrice.calculation_hash}</div><p className="text-[11px] text-slate-500">Calculator output is informational. Orders and payments use the persisted offer price from the authenticated API.</p></section>
    </div>

    <section className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5"><h3 className="text-sm font-semibold text-white mb-4">Your Orders</h3>{orders.length === 0 ? <p className="text-sm text-slate-500">No orders for this tenant.</p> : <div className="space-y-2">{orders.map(order => <div key={order.id} className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3 bg-slate-950 rounded-lg border border-slate-800"><div><div className="text-xs font-mono text-white">{order.id}</div><div className="text-xs text-slate-500">{order.status} · ${(order.price_cents / 100).toFixed(2)}</div></div><div className="flex gap-2">{order.status === 'ORDER_CREATED' && <button disabled={!!busy} onClick={() => void capture(order.id)} className="px-3 py-1.5 rounded bg-blue-600 text-white text-xs">Capture PayPal</button>}{order.status === 'ESCROW_FUNDED' && <button disabled={!!busy} onClick={() => void transition(order.id, 'SANDBOX_PROVISIONED')} className="px-3 py-1.5 rounded bg-slate-800 text-white text-xs">Provision Sandbox</button>}</div></div>)}</div>}</section>
  </div>;
};
