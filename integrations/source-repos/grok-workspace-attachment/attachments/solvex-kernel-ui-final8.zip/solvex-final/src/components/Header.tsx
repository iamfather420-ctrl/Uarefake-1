import React from 'react';
import { Key, CheckCircle2, AlertTriangle, LogOut } from 'lucide-react';
import type { UserContext } from '../auth/AuthService';

interface HeaderProps {
  currentUser: UserContext;
  chainValid: boolean;
  auditHead: string;
  paypalConnected: boolean;
  onOpenPayPalHub: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentUser, chainValid, auditHead, paypalConnected, onOpenPayPalHub, onLogout }) => <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50 px-4 lg:px-8 py-3"><div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4"><div><div className="font-bold tracking-tight text-white text-lg">Project AGATE <span className="text-xs text-cyan-400 font-mono">SOLVEX B2B</span></div><p className="text-xs text-slate-400 font-mono">{currentUser.email} · {currentUser.role} · {currentUser.tenant_id}</p></div><div className="flex flex-wrap items-center gap-3"><div className="hidden sm:flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-lg px-3 py-1.5 text-xs font-mono"><span className="text-slate-400">Merkle:</span><span className={chainValid ? 'text-emerald-400' : 'text-rose-400'}>{auditHead ? `${auditHead.slice(0, 10)}...` : 'GENESIS'}</span>{chainValid ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400"/> : <AlertTriangle className="w-3.5 h-3.5 text-rose-500"/>}</div><button onClick={onOpenPayPalHub} className="flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium bg-slate-950 border-slate-800 text-slate-200"><span>PayPal DN-35</span>{paypalConnected ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400"/> : <Key className="w-3.5 h-3.5 text-amber-400"/>}</button><button onClick={onLogout} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs"><LogOut className="w-3.5 h-3.5"/>Sign out</button></div></div></header>;
