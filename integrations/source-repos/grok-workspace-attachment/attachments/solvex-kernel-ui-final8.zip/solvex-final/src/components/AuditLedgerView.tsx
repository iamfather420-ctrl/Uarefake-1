import React, { useEffect, useState } from 'react';
import { Database, CheckCircle2, AlertTriangle } from 'lucide-react';
import { apiRequest } from '../api/client';

export const AuditLedgerView: React.FC = () => {
  const [data, setData] = useState<any>(null); const [error, setError] = useState<string | null>(null);
  useEffect(() => { void apiRequest('/api/audit/chain').then(setData).catch(e => setError(e instanceof Error ? e.message : 'Audit request failed')); }, []);
  if (error) return <div className="p-4 rounded-xl border border-rose-800 bg-rose-950/30 text-rose-300">{error}</div>;
  return <div className="space-y-4"><div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6"><h2 className="text-lg font-bold text-white flex items-center gap-2"><Database className="w-4 h-4 text-cyan-400"/>Audit Ledger</h2>{data && <div className={`mt-3 text-sm ${data.valid ? 'text-emerald-300' : 'text-rose-300'}`}>{data.valid ? <CheckCircle2 className="inline w-4 h-4 mr-2"/> : <AlertTriangle className="inline w-4 h-4 mr-2"/>}{data.valid ? 'Chain verified' : 'Chain verification failed'} · {data.total_records} records</div>}</div><div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6"><pre className="text-[10px] text-slate-400 overflow-auto max-h-[60vh]">{JSON.stringify(data?.chain || [], null, 2)}</pre></div></div>;
};
