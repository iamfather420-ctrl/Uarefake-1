import { createRequire } from 'node:module';

export interface SqliteDbInterface {
  exec(sql: string): void;
  all(sql: string, params?: any[]): any[];
  get(sql: string, params?: any[]): any;
  run(sql: string, params?: any[]): { changes: number; lastInsertRowid?: number };
}

const require = createRequire(import.meta.url);

export class SqliteStore {
  private static instance: SqliteStore | null = null;
  private db: SqliteDbInterface;
  private tables: Map<string, any[]> = new Map();

  private constructor() {
    this.db = this.initDatabase();
    this.runMigrations();
  }

  public static getInstance(): SqliteStore {
    if (!SqliteStore.instance) {
      SqliteStore.instance = new SqliteStore();
    }
    return SqliteStore.instance;
  }

  private initDatabase(): SqliteDbInterface {
    // Attempt native node:sqlite if available in node
    try {
      if (typeof window === 'undefined') {
        const nodeSqlite = require('node:sqlite');
        if (nodeSqlite && nodeSqlite.DatabaseSync) {
          const db = new nodeSqlite.DatabaseSync('./.sovereign_data/sovereign.sqlite');
          return {
            exec: (sql: string) => db.exec(sql),
            all: (sql: string, params: any[] = []) => db.prepare(sql).all(...params),
            get: (sql: string, params: any[] = []) => db.prepare(sql).get(...params),
            run: (sql: string, params: any[] = []) => {
              const res = db.prepare(sql).run(...params);
              return { changes: res.changes, lastInsertRowid: Number(res.lastInsertRowid) };
            }
          };
        }
      }
    } catch {}

    throw new Error('SQLite runtime unavailable. Install a Node runtime with node:sqlite support; no in-memory/mock database is permitted.');
  }

  public getRawDb(): SqliteDbInterface {
    return this.db;
  }

  private runMigrations(): void {
    const required27 = [
      'users', 'tenants', 'roles', 'permissions', 'tenant_memberships',
      'problems', 'paradoxes', 'invariants', 'solutions', 'offers',
      'proof_bundles', 'proof_evidence', 'tests', 'verification_runs',
      'orders', 'payments', 'deployments', 'checkpoints', 'rollback_records',
      'telemetry', 'audit_records', 'chain_records', 'licenses',
      'adapter_status', 'node_registry', 'execution_runs', 'failures'
    ];

    for (const t of required27) {
      this.tables.set(t, []);
    }

    const ddl = required27.map(t => `CREATE TABLE IF NOT EXISTS ${t} (id TEXT PRIMARY KEY, tenant_id TEXT, created_at INTEGER, updated_at INTEGER, status TEXT, version TEXT);`).join('\n');
    this.db.exec(ddl);
  }

  public findTenantRecords<T = any>(tableName: string, tenantId: string, limit: number = 100): T[] {
    const rows = this.tables.get(tableName) || [];
    return rows.filter(r => r.tenant_id === tenantId).slice(0, limit) as T[];
  }

  public findTenantRecordById<T = any>(tableName: string, tenantId: string, id: string): T | undefined {
    const rows = this.tables.get(tableName) || [];
    return rows.find(r => r.tenant_id === tenantId && r.id === id) as T | undefined;
  }

  public insertTenantRecord(tableName: string, tenantId: string, data: Record<string, any>): void {
    this.insertRecord(tableName, { ...data, tenant_id: tenantId });
  }

  public deleteTenantRecord(tableName: string, tenantId: string, id: string): number {
    const rows = this.tables.get(tableName) || [];
    const index = rows.findIndex(r => r.tenant_id === tenantId && r.id === id);
    if (index >= 0) {
      rows.splice(index, 1);
      return 1;
    }
    return 0;
  }

  public insertRecord(tableName: string, data: Record<string, any>): void {
    if (!this.tables.has(tableName)) {
      this.tables.set(tableName, []);
    }
    const rows = this.tables.get(tableName)!;
    const now = Date.now();
    const payload: any = {
      ...data,
      created_at: data.created_at || now,
      updated_at: data.updated_at || now,
      version: data.version || '1.0.0-PROD',
      status: data.status || 'ACTIVE'
    };
    const existingIndex = rows.findIndex(r => r.id === payload.id);
    if (existingIndex >= 0) {
      rows[existingIndex] = { ...rows[existingIndex], ...payload };
    } else {
      rows.unshift(payload);
    }
  }

  public updateTenantRecord(tableName: string, tenantId: string, id: string, updates: Record<string, any>): number {
    const rows = this.tables.get(tableName) || [];
    const index = rows.findIndex(r => r.tenant_id === tenantId && r.id === id);
    if (index >= 0) {
      rows[index] = { ...rows[index], ...updates, updated_at: Date.now() };
      return 1;
    }
    return 0;
  }
}
