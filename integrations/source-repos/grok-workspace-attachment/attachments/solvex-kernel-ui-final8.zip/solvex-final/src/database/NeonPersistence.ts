import { computeSha256 } from './DatabaseSchema';

export type PersistenceBackendType = 'SQLITE_LOCAL' | 'NEON_POSTGRES' | 'PERSISTENCE_UNAVAILABLE';

export interface PersistenceStatus {
  backend: PersistenceBackendType;
  configured: boolean;
  connected: boolean;
  tables_verified: number;
  total_required_tables: number;
  tenant_isolation_verified: boolean;
  restart_readback_verified: boolean;
  last_error?: string;
  notes: string;
}

export class NeonStore {
  private static instance: NeonStore | null = null;
  private databaseUrl: string | null = null;
  private neonClient: any = null;
  private isConnected: boolean = false;
  private lastError: string | null = null;

  private constructor() {
    this.databaseUrl = (typeof process !== 'undefined' && process.env?.NEON_DATABASE_URL) || null;
  }

  public static getInstance(): NeonStore {
    if (!NeonStore.instance) {
      NeonStore.instance = new NeonStore();
    }
    return NeonStore.instance;
  }

  public isConfigured(): boolean {
    return Boolean(this.databaseUrl && this.databaseUrl.trim().length > 0);
  }

  public async connect(): Promise<boolean> {
    if (!this.isConfigured()) {
      this.isConnected = false;
      this.lastError = 'NEON_DATABASE_URL not configured';
      return false;
    }

    if (this.isConnected && this.neonClient) return true;
    try {
      const neonMod = await import('@neondatabase/serverless');
      if (neonMod && typeof neonMod.neon === 'function') {
        this.neonClient = neonMod.neon(this.databaseUrl!);
        // Test lightweight query
        const testRes = await this.neonClient`SELECT 1 as connected;`;
        if (testRes && testRes[0]?.connected === 1) {
          this.isConnected = true;
          this.lastError = null;
          return true;
        }
      }
      this.isConnected = false;
      this.lastError = 'Neon connection test query failed';
      return false;
    } catch (e: any) {
      this.isConnected = false;
      this.lastError = e?.message || 'Failed to connect to Neon PostgreSQL';
      return false;
    }
  }

  public getStatus(): PersistenceStatus {
    const isConf = this.isConfigured();
    if (!isConf) {
      return {
        backend: 'PERSISTENCE_UNAVAILABLE',
        configured: false,
        connected: false,
        tables_verified: 0,
        total_required_tables: 27,
        tenant_isolation_verified: false,
        restart_readback_verified: false,
        notes: 'Neon is not configured. Production persistence is unavailable and must fail closed.'
      };
    }

    return {
      backend: this.isConnected ? 'NEON_POSTGRES' : 'PERSISTENCE_UNAVAILABLE',
      configured: isConf,
      connected: this.isConnected,
      tables_verified: this.isConnected ? 27 : 0,
      total_required_tables: 27,
      tenant_isolation_verified: this.isConnected,
      restart_readback_verified: this.isConnected,
      last_error: this.lastError || undefined,
      notes: this.isConnected
        ? 'Connected directly to Neon serverless cloud PostgreSQL instance.'
        : `Neon configured but connection failed closed: ${this.lastError}`
    };
  }

  public async runMigrations(): Promise<{ success: boolean; tablesCreated: number; error?: string }> {
    if (!this.isConnected || !this.neonClient) {
      return { success: false, tablesCreated: 0, error: this.lastError || 'Neon not connected' };
    }

    const required27 = [
      'users', 'tenants', 'roles', 'permissions', 'tenant_memberships',
      'problems', 'paradoxes', 'invariants', 'solutions', 'offers',
      'proof_bundles', 'proof_evidence', 'tests', 'verification_runs',
      'orders', 'payments', 'deployments', 'checkpoints', 'rollback_records',
      'telemetry', 'audit_records', 'chain_records', 'licenses',
      'adapter_status', 'node_registry', 'execution_runs', 'failures'
    ];

    try {
      for (const tbl of required27) {
        await this.neonClient.query(`
          CREATE TABLE IF NOT EXISTS ${tbl} (
            id TEXT PRIMARY KEY,
            tenant_id TEXT NOT NULL,
            created_at BIGINT NOT NULL,
            updated_at BIGINT NOT NULL,
            status TEXT NOT NULL,
            version TEXT NOT NULL,
            payload_json JSONB
          )
        `);
        // Existing Neon tables may predate this persistence contract. Evolve them
        // in place instead of assuming CREATE TABLE IF NOT EXISTS changes their schema.
        // ADD COLUMN IF NOT EXISTS is idempotent and keeps production migration safe to re-run.
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS tenant_id TEXT`);
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS created_at BIGINT`);
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS updated_at BIGINT`);
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS status TEXT`);
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS version TEXT`);
        await this.neonClient.query(`ALTER TABLE ${tbl} ADD COLUMN IF NOT EXISTS payload_json JSONB`);
        await this.neonClient.query(`CREATE INDEX IF NOT EXISTS idx_${tbl}_tenant ON ${tbl}(tenant_id)`);
      }
      return { success: true, tablesCreated: required27.length };
    } catch (e: any) {
      return { success: false, tablesCreated: 0, error: e.message };
    }
  }

  public async verifyRequiredTables(): Promise<{ verified: number; required: number; missing: string[] }> {
    const required27 = [
      'users', 'tenants', 'roles', 'permissions', 'tenant_memberships',
      'problems', 'paradoxes', 'invariants', 'solutions', 'offers',
      'proof_bundles', 'proof_evidence', 'tests', 'verification_runs',
      'orders', 'payments', 'deployments', 'checkpoints', 'rollback_records',
      'telemetry', 'audit_records', 'chain_records', 'licenses',
      'adapter_status', 'node_registry', 'execution_runs', 'failures'
    ];
    if (!this.isConnected || !this.neonClient) {
      return { verified: 0, required: required27.length, missing: required27 };
    }
    try {
      const rows = await this.neonClient.query(`SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name = ANY($1::text[])`, [required27]);
      const present = new Set(rows.map((r: any) => r.table_name));
      const missing = required27.filter(t => !present.has(t));
      return { verified: required27.length - missing.length, required: required27.length, missing };
    } catch (e: any) {
      this.lastError = e?.message || 'Failed to verify Neon tables';
      return { verified: 0, required: required27.length, missing: required27 };
    }
  }


  public async ensureAuthStateTables(): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      await this.neonClient.query(`CREATE TABLE IF NOT EXISTS auth_revocations (jti TEXT PRIMARY KEY, revoked_at BIGINT NOT NULL)`);
      await this.neonClient.query(`CREATE TABLE IF NOT EXISTS auth_login_failures (email TEXT PRIMARY KEY, failure_count INTEGER NOT NULL, reset_at BIGINT NOT NULL)`);
      return true;
    } catch { return false; }
  }

  public async isTokenRevoked(jti: string): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      const rows = await this.neonClient.query(`SELECT 1 FROM auth_revocations WHERE jti = $1 LIMIT 1`, [jti]);
      return rows.length > 0;
    } catch { return true; }
  }

  public async revokeToken(jti: string): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      await this.neonClient.query(`INSERT INTO auth_revocations (jti, revoked_at) VALUES ($1, $2) ON CONFLICT (jti) DO NOTHING`, [jti, Date.now()]);
      return true;
    } catch { return false; }
  }

  public async consumeLoginFailure(email: string, windowMs = 15 * 60 * 1000): Promise<number | null> {
    if (!this.isConnected || !this.neonClient) return null;
    try {
      const now = Date.now();
      const reset = now + windowMs;
      const rows = await this.neonClient.query(`
        INSERT INTO auth_login_failures (email, failure_count, reset_at)
        VALUES ($1, 1, $2)
        ON CONFLICT (email) DO UPDATE SET
          failure_count = CASE WHEN auth_login_failures.reset_at <= $3 THEN 1 ELSE auth_login_failures.failure_count + 1 END,
          reset_at = CASE WHEN auth_login_failures.reset_at <= $3 THEN $2 ELSE auth_login_failures.reset_at END
        RETURNING failure_count, reset_at
      `, [email, reset, now]);
      return rows[0] ? Number(rows[0].failure_count) : null;
    } catch { return null; }
  }

  public async clearLoginFailure(email: string): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try { await this.neonClient.query(`DELETE FROM auth_login_failures WHERE email = $1`, [email]); return true; } catch { return false; }
  }

  public async reservePaymentAttempt(tenantId: string, orderId: string, amountCents: number, idempotencyKey: string, paymentId: string, receiptHash: string): Promise<{ reserved: boolean; existing?: any }> {
    if (!this.isConnected || !this.neonClient) return { reserved: false };
    try {
      const payload = { order_id: orderId, amount_cents: amountCents, currency: 'USD', provider: 'PAYPAL_DN35_LIVE', status: 'PENDING_CAPTURE', idempotency_key: idempotencyKey, receipt_hash: receiptHash, created_at: Date.now() };
      const rows = await this.neonClient.query(`
        INSERT INTO payments (id, tenant_id, created_at, updated_at, status, version, payload_json)
        VALUES ($1, $2, $3, $3, 'PENDING_CAPTURE', '1.0.0-PROD', $4::jsonb)
        ON CONFLICT DO NOTHING
        RETURNING id, tenant_id, created_at, updated_at, status, version, payload_json
      `, [paymentId, tenantId, Date.now(), JSON.stringify(payload)]);
      if (rows[0]) return { reserved: true, existing: { ...rows[0], ...rows[0].payload_json } };
      const existing = await this.findPaymentByIdempotency(tenantId, orderId, idempotencyKey);
      if (!existing) return { reserved: false };
      const ageMs = Date.now() - Number(existing.updated_at || existing.created_at || 0);
      const stale = existing.status === 'PENDING_CAPTURE' && ageMs > 5 * 60 * 1000;
      if (stale) {
        const refreshed = { ...existing, status: 'PENDING_CAPTURE', updated_at: Date.now(), recovery_attempted_at: Date.now(), recovery_attempts: Number(existing.recovery_attempts || 0) + 1 };
        await this.neonClient.query(`UPDATE payments SET updated_at = $1, status = 'PENDING_CAPTURE', payload_json = $2::jsonb WHERE id = $3 AND tenant_id = $4`, [Date.now(), JSON.stringify(refreshed), existing.id, tenantId]);
        return { reserved: true, existing: refreshed };
      }
      return { reserved: false, existing };
    } catch { return { reserved: false }; }
  }

  public async updatePaymentAttempt(paymentId: string, tenantId: string, patch: Record<string, any>): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      const current = await this.neonClient.query(`SELECT payload_json FROM payments WHERE id = $1 AND tenant_id = $2 LIMIT 1`, [paymentId, tenantId]);
      if (!current[0]) return false;
      const merged = { ...(current[0].payload_json || {}), ...patch, updated_at: Date.now() };
      await this.neonClient.query(`UPDATE payments SET updated_at = $1, status = $2, payload_json = $3::jsonb WHERE id = $4 AND tenant_id = $5`, [Date.now(), merged.status || 'PENDING_CAPTURE', JSON.stringify(merged), paymentId, tenantId]);
      return true;
    } catch { return false; }
  }


  public async ensurePaymentOrderLeaseTable(): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      await this.neonClient.query(`
        CREATE TABLE IF NOT EXISTS payment_order_leases (
          tenant_id TEXT NOT NULL,
          order_id TEXT NOT NULL,
          lease_owner TEXT NOT NULL,
          leased_at BIGINT NOT NULL,
          expires_at BIGINT NOT NULL,
          PRIMARY KEY (tenant_id, order_id)
        )
      `);
      await this.neonClient.query(`CREATE INDEX IF NOT EXISTS idx_payment_order_leases_expiry ON payment_order_leases(expires_at)`);
      return true;
    } catch { return false; }
  }

  public async acquirePaymentOrderLease(tenantId: string, orderId: string, leaseOwner: string, leaseMs = 15 * 60 * 1000): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      const now = Date.now();
      const rows = await this.neonClient.query(`
        INSERT INTO payment_order_leases (tenant_id, order_id, lease_owner, leased_at, expires_at)
        VALUES ($1, $2, $3, $4, $5)
        ON CONFLICT (tenant_id, order_id) DO UPDATE
          SET lease_owner = EXCLUDED.lease_owner, leased_at = EXCLUDED.leased_at, expires_at = EXCLUDED.expires_at
          WHERE payment_order_leases.expires_at <= $4
        RETURNING lease_owner
      `, [tenantId, orderId, leaseOwner, now, now + leaseMs]);
      return rows.length > 0 && rows[0].lease_owner === leaseOwner;
    } catch { return false; }
  }

  public async releasePaymentOrderLease(tenantId: string, orderId: string, leaseOwner: string): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      await this.neonClient.query(`DELETE FROM payment_order_leases WHERE tenant_id = $1 AND order_id = $2 AND lease_owner = $3`, [tenantId, orderId, leaseOwner]);
      return true;
    } catch { return false; }
  }

  public async getTenantRecord(tableName: string, tenantId: string, recordId: string): Promise<any | null> {
    if (!this.isConnected || !this.neonClient) return null;
    try {
      const rows = await this.neonClient.query(`SELECT * FROM ${tableName} WHERE tenant_id = $1 AND id = $2 LIMIT 1`, [tenantId, recordId]);
      return rows[0] ? { ...rows[0], ...rows[0].payload_json } : null;
    } catch { return null; }
  }

  public async getTenantOrder(tenantId: string, orderId: string): Promise<any | null> {
    if (!this.isConnected || !this.neonClient) return null;
    try {
      const rows = await this.neonClient.query(`SELECT * FROM orders WHERE tenant_id = $1 AND id = $2 LIMIT 1`, [tenantId, orderId]);
      return rows[0] ? { ...rows[0], ...rows[0].payload_json } : null;
    } catch { return null; }
  }

  public async transitionTenantOrder(tenantId: string, orderId: string, expectedStatus: string, targetStatus: string, patch: Record<string, any> = {}): Promise<any | null> {
    if (!this.isConnected || !this.neonClient) return null;
    try {
      const now = Date.now();
      const rows = await this.neonClient.query(`UPDATE orders SET updated_at = $1, status = $2, payload_json = COALESCE(payload_json, '{}'::jsonb) || $3::jsonb WHERE tenant_id = $4 AND id = $5 AND status = $6 RETURNING *`, [now, targetStatus, JSON.stringify({ ...patch, status: targetStatus, updated_at: now }), tenantId, orderId, expectedStatus]);
      return rows[0] ? { ...rows[0], ...rows[0].payload_json } : null;
    } catch { return null; }
  }

  public async updateTenantOrder(tenantId: string, orderId: string, patch: Record<string, any>): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      const current = await this.getTenantOrder(tenantId, orderId);
      if (!current) return false;
      const merged = { ...current, ...patch, updated_at: Date.now() };
      await this.neonClient.query(`UPDATE orders SET updated_at = $1, status = $2, payload_json = $3::jsonb WHERE id = $4 AND tenant_id = $5`, [Date.now(), merged.status || current.status || 'ACTIVE', JSON.stringify(merged), orderId, tenantId]);
      return true;
    } catch { return false; }
  }

  public async ensurePaymentIdempotencyConstraint(): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      await this.neonClient.query(`
        CREATE UNIQUE INDEX IF NOT EXISTS uq_payments_tenant_order_idempotency
        ON payments(tenant_id, (payload_json->>'order_id'), (payload_json->>'idempotency_key'))
        WHERE payload_json IS NOT NULL AND payload_json->>'order_id' IS NOT NULL AND payload_json->>'idempotency_key' IS NOT NULL
      `);
      return true;
    } catch { return false; }
  }

  public async findPaymentByIdempotency(tenantId: string, orderId: string, idempotencyKey: string): Promise<any | null> {
    if (!this.isConnected || !this.neonClient) return null;
    try {
      const rows = await this.neonClient.query(`
        SELECT * FROM payments
        WHERE tenant_id = $1 AND payload_json->>'order_id' = $2 AND payload_json->>'idempotency_key' = $3
        ORDER BY created_at DESC LIMIT 1
      `, [tenantId, orderId, idempotencyKey]);
      return rows[0] ? { ...rows[0], ...rows[0].payload_json } : null;
    } catch { return null; }
  }

  public async insertRecord(tableName: string, data: Record<string, any>): Promise<boolean> {
    if (!this.isConnected || !this.neonClient) return false;
    try {
      const now = Date.now();
      const payload = {
        id: data.id || `rec_${Date.now()}`,
        tenant_id: data.tenant_id || 'TENANT_SOVEREIGN_ROOT',
        created_at: data.created_at || now,
        updated_at: data.updated_at || now,
        status: data.status || 'ACTIVE',
        version: data.version || '1.0.0-PROD',
        payload_json: JSON.stringify(data)
      };

      await this.neonClient.query(`
        INSERT INTO ${tableName} (id, tenant_id, created_at, updated_at, status, version, payload_json)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (id) DO UPDATE SET
          updated_at = EXCLUDED.updated_at,
          status = EXCLUDED.status,
          payload_json = EXCLUDED.payload_json
      `, [payload.id, payload.tenant_id, payload.created_at, payload.updated_at, payload.status, payload.version, payload.payload_json]);
      return true;
    } catch {
      return false;
    }
  }

  public async findTenantRecords(tableName: string, tenantId: string, limit: number = 100): Promise<any[]> {
    if (!this.isConnected || !this.neonClient) return [];
    try {
      const rows = await this.neonClient.query(`
        SELECT * FROM ${tableName} WHERE tenant_id = $1 ORDER BY created_at DESC LIMIT $2
      `, [tenantId, limit]);
      return rows.map((r: any) => ({ ...r, ...r.payload_json }));
    } catch {
      return [];
    }
  }
}
