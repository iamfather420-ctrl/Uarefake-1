import type { UserContext } from '../auth/AuthService';

export interface ApiEnvelope<T> { status: number; data?: T; error?: string; timestamp: number; }

function token(): string | null {
  try { return sessionStorage.getItem('solvex_token'); } catch { return null; }
}

export async function apiRequest<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set('Accept', 'application/json');
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const t = token();
  if (t) headers.set('Authorization', `Bearer ${t}`);
  const response = await fetch(path, { ...init, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body?.error || `Request failed (${response.status})`);
  return (body?.data ?? body) as T;
}

export async function login(email: string, password: string): Promise<{ token: string; user: UserContext }> {
  return apiRequest('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });
}

export async function currentUser(): Promise<UserContext> {
  return apiRequest<UserContext>('/api/auth/me');
}

export async function logout(): Promise<void> {
  try { await apiRequest('/api/auth/logout', { method: 'POST' }); } finally { clearSession(); }
}

export function clearSession(): void {
  try { sessionStorage.removeItem('solvex_token'); } catch {}
}
