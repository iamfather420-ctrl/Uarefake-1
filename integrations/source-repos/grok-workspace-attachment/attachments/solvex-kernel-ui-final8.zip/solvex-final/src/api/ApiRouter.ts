import { SystemStatusService } from './SystemStatus';
import { DurableStore } from '../database/DurableStore';
import { SqliteStore } from '../database/SqliteStore';
import { NodeRegistry } from '../nodes/NodeRegistry';
import { ParadoxRegistry } from '../paradoxes/ParadoxRegistry';
import { ProofEngine } from '../proofs/ProofEngine';
import { MarketplaceEngine } from '../marketplace/MarketplaceEngine';
import { OrderLifecycleManager } from '../marketplace/OrderLifecycle';
import { PayPalAdapter } from '../payments/PayPalAdapter';
import { ExternalAdapterRegistry } from '../adapters/ExternalAdapters';
import { CrystalClearBox } from '../audit/CrystalClearBox';
import { AuthService, UserContext } from '../auth/AuthService';
import { SolutionPipeline } from '../solutions/SolutionPipeline';
import { ReversibilityEngine } from '../database/ReversibilityEngine';
import { DaisyBrain } from '../brain/DaisyBrain';
import { computeSha256 } from '../database/DatabaseSchema';
import { Z3FormalProofEngine } from '../proofs/Z3FormalProofEngine';
import { PipelineKernel } from '../kernel/PipelineKernel';
import { MessageBus } from '../bus/MessageBus';
import { NeonStore } from '../database/NeonPersistence';

export interface ApiResponse<T = any> {
  status: number;
  data?: T;
  error?: string;
  timestamp: number;
}

export class SovereignApiRouter {
  private static instance: SovereignApiRouter | null = null;
  private sqlite: SqliteStore;
  private durableStore: DurableStore;
  private authService: AuthService;
  private readonly z3RateLimits = new Map<string, { count: number; resetAt: number }>();
  private readonly paymentLocks = new Set<string>();

  private constructor() {
    this.sqlite = SqliteStore.getInstance();
    this.durableStore = DurableStore.getInstance();
    this.authService = AuthService.getInstance();
  }

  public static getInstance(): SovereignApiRouter {
    if (!SovereignApiRouter.instance) {
      SovereignApiRouter.instance = new SovereignApiRouter();
    }
    return SovereignApiRouter.instance;
  }

  private async extractAuthUser(headers: Record<string, string | string[] | undefined>): Promise<UserContext | null> {
    const authHeader = headers['authorization'] || headers['Authorization'];
    if (!authHeader || typeof authHeader !== 'string') {
      return null;
    }
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    const verified = await this.authService.verifyTokenDistributed(token);
    return verified.valid && verified.user ? verified.user : null;
  }

  public async handleRequest(
    path: string,
    method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
    payload?: any,
    headers: Record<string, string | string[] | undefined> = {}
  ): Promise<ApiResponse> {
    const timestamp = Date.now();
    const user = await this.extractAuthUser(headers);

    try {
      // 1. /api/auth
      if (path === '/api/auth/login' && method === 'POST') {
        const { email, password } = payload || {};
        if (!email || !password) return { status: 400, error: 'Email and password are required', timestamp };
        const authenticated = await this.authService.authenticateDistributed(String(email), String(password));
        if (!authenticated) return { status: 401, error: 'Invalid credentials', timestamp };
        const token = this.authService.createUserToken(authenticated);
        return { status: 200, data: { token, user: authenticated }, timestamp };
      }
      if (path === '/api/auth/logout' && method === 'POST') {
        if (!user) return { status: 401, error: 'Unauthorized', timestamp };
        const authHeader = headers['authorization'] || headers['Authorization'];
        if (typeof authHeader === 'string') {
          const token = authHeader.replace(/^Bearer\s+/i, '').trim();
          const revoked = await this.authService.revokeTokenDistributed(token);
          if (!revoked) return { status: 503, error: 'Authentication state unavailable; logout not committed', timestamp };
        }
        return { status: 200, data: { success: true }, timestamp };
      }
      if (path === '/api/auth/me' && method === 'GET') {
        if (!user) return { status: 401, error: 'Unauthorized: Missing or invalid token', timestamp };
        return { status: 200, data: user, timestamp };
      }

      // 2. /api/tenants
      if (path === '/api/tenants' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const auth = this.authService.authorize(user, 'VIEW_TENANTS');
        if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        const tenants = this.sqlite.getRawDb().all('SELECT id, name, tier, status, created_at FROM tenants');
        return { status: 200, data: tenants, timestamp };
      }
      if (path === '/api/tenants' && method === 'POST') {
        if (!user || user.role !== 'PLATFORM_ADMIN') {
          return { status: 403, error: 'Forbidden: Only PLATFORM_ADMIN can create tenants', timestamp };
        }
        const { id, name, tier = 'ENTERPRISE' } = payload || {};
        if (!id || !name) return { status: 400, error: 'Tenant id and name required', timestamp };
        const key = computeSha256(`KEY_${id}`);
        this.sqlite.insertRecord('tenants', { id, name, tier, isolated_storage_key: key, status: 'ACTIVE' });
        return { status: 201, data: { id, name, tier }, timestamp };
      }

      // 3. /api/problems
      if (path === '/api/problems' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const problems = this.sqlite.findTenantRecords('problems', targetTenant);
        return { status: 200, data: problems, timestamp };
      }
      if (path === '/api/problems' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const { raw_problem, title, domain = 'COMPUTATIONAL' } = payload || {};
        if (!raw_problem) return { status: 400, error: 'raw_problem is required', timestamp };
        const problemId = `prob_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        const problemData = {
          id: problemId,
          tenant_id: targetTenant,
          raw_problem,
          normalized_title: title || raw_problem.substring(0, 40),
          domain,
          detected_constraints: ['BOUNDED_EXECUTION', 'FINITE_CONVERGENCE'],
          invariants: ['STATE_IMMUTABILITY'],
          status: 'INTAKE',
          version: '1.0.0-PROD'
        };
        this.sqlite.insertRecord('problems', problemData);
        this.durableStore.getState().problems[problemId] = problemData as any;
        this.durableStore.appendAudit(targetTenant, user?.user_id || 'ANONYMOUS', 'PROBLEM_INTAKE', 'PROBLEM', problemId, {
          title: problemData.normalized_title
        });
        this.durableStore.persist();
        return { status: 201, data: problemData, timestamp };
      }

      // 4. /api/paradoxes
      if (path === '/api/paradoxes' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        const paradoxes = ParadoxRegistry.getInstance().getAllParadoxes();
        return { status: 200, data: paradoxes, timestamp };
      }

      // 5. /api/invariants
      if (path === '/api/invariants' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const invariants = this.sqlite.findTenantRecords('invariants', targetTenant);
        return { status: 200, data: invariants, timestamp };
      }

      // 6. /api/solutions
      if (path === '/api/solutions' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const solutions = Object.values(this.durableStore.getState().solutions).filter((solution: any) => solution.tenant_id === user.tenant_id || (user.role === 'PLATFORM_ADMIN' && solution.tenant_id === 'TENANT_SOVEREIGN_ROOT'));
        return { status: 200, data: solutions, timestamp };
      }
      if (path === '/api/solutions/pipeline' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        {
          const auth = this.authService.authorize(user, 'RUN_PIPELINE');
          if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        }
        const { paradox_code = 'DH-P-001', code_solution } = payload || {};
        const pipeline = SolutionPipeline.getInstance();
        const res = pipeline.runPipeline(paradox_code, code_solution || 'export function defaultSolve() { return true; }', user.tenant_id);
        return { status: 200, data: res, timestamp };
      }

      // 7. /api/verification
      if (path === '/api/verification' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const runs = this.sqlite.findTenantRecords('verification_runs', user.tenant_id, 20);
        return { status: 200, data: runs, timestamp };
      }

      // 8. /api/proofs
      if (path === '/api/proofs' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const bundles = ProofEngine.getInstance().getAllBundles().filter((b: any) => !b.tenant_id || b.tenant_id === user.tenant_id || user.role === 'PLATFORM_ADMIN');
        return { status: 200, data: bundles, timestamp };
      }
      if (path.startsWith('/api/proofs/evidence/') && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const proofId = path.replace('/api/proofs/evidence/', '');
        const bundle = ProofEngine.getInstance().getBundle(proofId);
        if (!bundle) return { status: 404, error: 'Proof bundle not found', timestamp };
        if (bundle.tenant_id && bundle.tenant_id !== user.tenant_id && user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: proof belongs to another tenant', timestamp };
        const evidence = CrystalClearBox.projectCustomerEvidence(bundle);
        return { status: 200, data: evidence, timestamp };
      }

      // 8b. Real Z3 Automated Theorem Prover
      if (path === '/api/proofs/z3/theorems' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const engine = Z3FormalProofEngine.getInstance();
        return { status: 200, data: engine.getCatalog(), timestamp };
      }
      if (path === '/api/proofs/z3/prove' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const { theorem_id, custom_name, custom_smt_script, expected_result } = payload || {};
        const engine = Z3FormalProofEngine.getInstance();
        const now = Date.now();
        const rate = this.z3RateLimits.get(user.user_id);
        if (!rate || now >= rate.resetAt) this.z3RateLimits.set(user.user_id, { count: 1, resetAt: now + 60_000 });
        else {
          if (rate.count >= 10) return { status: 429, error: 'Z3 rate limit exceeded; try again later', timestamp };
          rate.count += 1;
        }
        if (custom_smt_script) {
          if (process.env.SOLVEX_ALLOW_CUSTOM_SMT !== 'true') return { status: 403, error: 'Custom SMT execution is disabled; use the vetted theorem catalog.', timestamp };
          if (typeof custom_smt_script !== 'string' || custom_smt_script.length > 32 * 1024) return { status: 413, error: 'custom_smt_script exceeds 32 KiB limit', timestamp };
          if (typeof custom_name === 'string' && custom_name.length > 200) return { status: 400, error: 'custom_name too long', timestamp };
          const res = await engine.verifyCustomSmtScript(custom_name || 'CustomTheorem', custom_smt_script, expected_result || 'unsat');
          return { status: 200, data: res, timestamp };
        }
        if (theorem_id) {
          const res = await engine.proveCatalogTheorem(theorem_id);
          return { status: 200, data: res, timestamp };
        }
        return { status: 400, error: 'theorem_id or custom_smt_script required', timestamp };
      }

      // 9. /api/offers
      if (path === '/api/offers' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const neon = NeonStore.getInstance();
        if (process.env.NODE_ENV === 'production') {
          if (!(await neon.connect())) return { status: 503, error: 'Production marketplace persistence unavailable', timestamp };
          const offers = await neon.findTenantRecords('offers', 'TENANT_SOVEREIGN_ROOT');
          return { status: 200, data: offers.filter((o: any) => o.published && o.verification_status === 'VERIFIED'), timestamp };
        }
        const offers = Object.values(this.durableStore.getState().offers);
        return { status: 200, data: offers, timestamp };
      }
      if (path === '/api/offers/publish' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required to publish offer', timestamp };
        const auth = this.authService.authorize(user, 'PUBLISH_OFFER');
        if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        const { solution_id, proof_bundle_id, title, description, cost_basis, complexity, risk_class } = payload || {};
        const market = MarketplaceEngine.getInstance();
        if (process.env.NODE_ENV === 'production') {
          const neon = NeonStore.getInstance();
          if (!(await neon.connect())) return { status: 503, error: 'Production marketplace persistence unavailable', timestamp };
          const solution = await neon.getTenantRecord('solutions', 'TENANT_SOVEREIGN_ROOT', solution_id);
          const bundle = await neon.getTenantRecord('proof_bundles', 'TENANT_SOVEREIGN_ROOT', proof_bundle_id);
          if (!solution || solution.verification_status !== 'VERIFIED') return { status: 400, error: `Fail-closed Publication Blocked: Solution [${solution_id}] is missing or not VERIFIED`, timestamp };
          if (!bundle || bundle.verification_status !== 'VERIFIED') return { status: 400, error: `Fail-closed Publication Blocked: Proof Bundle [${proof_bundle_id}] is missing or not VERIFIED`, timestamp };
          const priced = market.calculateDefensiblePrice(Number(cost_basis), Number(complexity), risk_class);
          const offerId = `off_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
          const offer = { id: offerId, offer_id: offerId, tenant_id: 'TENANT_SOVEREIGN_ROOT', solution_id, proof_bundle_id, title, description, cost_basis_cents: Number(cost_basis), verification_complexity_factor: Number(complexity), risk_class, price_cents: priced.final_price_cents, sla_tier: '99.99%_DETERMINISTIC_SLA', published: true, verification_status: 'VERIFIED', created_at: Date.now(), status: 'ACTIVE' };
          if (!(await neon.insertRecord('offers', offer))) return { status: 503, error: 'Production offer persistence failed', timestamp };
          return { status: 201, data: offer, timestamp };
        }
        const res = market.publishOffer(solution_id, proof_bundle_id, title, description, cost_basis, complexity, risk_class);
        if (!res.success) return { status: 400, error: res.error, timestamp };
        return { status: 201, data: res.offer, timestamp };
      }

      // 10. /api/orders
      if (path === '/api/orders' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const neon = NeonStore.getInstance();
        if (process.env.NODE_ENV === 'production') {
          if (!(await neon.connect())) return { status: 503, error: 'Production order persistence unavailable', timestamp };
          const orders = await neon.findTenantRecords('orders', targetTenant);
          return { status: 200, data: orders, timestamp };
        }
        const orders = this.sqlite.findTenantRecords('orders', targetTenant);
        return { status: 200, data: orders, timestamp };
      }
      if (path === '/api/orders' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const { offer_id } = payload || {};
        if (!offer_id) return { status: 400, error: 'offer_id is required', timestamp };
        const market = MarketplaceEngine.getInstance();
        if (process.env.NODE_ENV === 'production') {
          const neon = NeonStore.getInstance();
          if (!(await neon.connect())) return { status: 503, error: 'Production marketplace persistence unavailable; order creation blocked', timestamp };
          const offer = await neon.getTenantRecord('offers', 'TENANT_SOVEREIGN_ROOT', offer_id);
          if (!offer || !offer.published || offer.verification_status !== 'VERIFIED') return { status: 400, error: 'Fail-closed: offer is missing or not VERIFIED', timestamp };
          const order = { id: `ord_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, tenant_id: targetTenant, offer_id, solution_id: offer.solution_id, proof_bundle_id: offer.proof_bundle_id, price_cents: offer.price_cents, status: 'ORDER_CREATED', created_at: Date.now() };
          if (!(await neon.insertRecord('orders', order))) return { status: 503, error: 'Production order persistence failed; order creation blocked', timestamp };
          return { status: 201, data: order, timestamp };
        }
        const res = market.createOrder(targetTenant, offer_id);
        if (!res.success) return { status: 400, error: res.error, timestamp };
        return { status: 201, data: res.order, timestamp };
      }
      if (path.startsWith('/api/orders/transition') && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required to transition order', timestamp };
        const { order_id, target_state, evidence_payload } = payload || {};
        if (!order_id || !target_state) return { status: 400, error: 'order_id and target_state required', timestamp };
        const lifecycle = OrderLifecycleManager.getInstance();
        const res = await lifecycle.transitionOrderDistributed(order_id, target_state, user, evidence_payload);
        if (!res.success) return { status: 400, error: res.error, timestamp };
        return { status: 200, data: res.order, timestamp };
      }

      // 11. /api/payments
      if (path === '/api/payments/capture' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const { order_id, idempotency_key } = payload || {};
        if (typeof idempotency_key !== 'string' || idempotency_key.length < 8 || idempotency_key.length > 128) return { status: 400, error: 'A valid idempotency_key (8-128 chars) is required', timestamp };
        if (!order_id) return { status: 400, error: 'order_id is required', timestamp };
        let order: any;
        const neon = NeonStore.getInstance();
        if (process.env.NODE_ENV === 'production') {
          if (!(await neon.connect())) return { status: 503, error: 'Production order persistence unavailable', timestamp };
          order = await neon.getTenantOrder(user.tenant_id, order_id);
        } else {
          order = this.sqlite.getRawDb().get('SELECT * FROM orders WHERE id = ?', [order_id]) as any;
        }
        if (!order) return { status: 404, error: 'Order not found', timestamp };
        if (order.tenant_id !== user.tenant_id) return { status: 403, error: 'Forbidden: order belongs to another tenant', timestamp };
        if (order.status === 'ESCROW_FUNDED') {
          return { status: 409, error: 'Order is already ESCROW_FUNDED; payment state must be reconciled from the production payment ledger.', timestamp };
        }
        if (order.status !== 'ORDER_CREATED') return { status: 409, error: `Order must be ORDER_CREATED before payment capture (current=${order.status})`, timestamp };
        const paymentLock = `${user.tenant_id}:${order_id}:${idempotency_key}`;
        if (this.paymentLocks.has(paymentLock)) return { status: 409, error: 'Payment capture for this idempotency key is already in progress', timestamp };
        this.paymentLocks.add(paymentLock);
        try {
        const amountCents = Number(order.price_cents);
        if (!Number.isInteger(amountCents) || amountCents <= 0) return { status: 409, error: 'Order has invalid persisted price', timestamp };
        const paypal = PayPalAdapter.getInstance();
        const res = await paypal.captureOrderPayment(order_id, amountCents, idempotency_key, order.tenant_id);
        if (!res.success) return { status: 502, data: res, error: res.error, timestamp };
        const lifecycle = OrderLifecycleManager.getInstance();
        const transition = await lifecycle.transitionOrderDistributed(order_id, 'ESCROW_FUNDED', user, { payment_id: res.payment?.paypal_capture_id || res.payment?.receipt_hash });
        if (!transition.success) return { status: 503, error: `Payment captured but production order finalization failed; reconciliation required: ${transition.error}`, timestamp };
        return { status: 200, data: { ...res, order: transition.order }, timestamp };
        } finally {
          this.paymentLocks.delete(paymentLock);
        }
      }

      if (path === '/api/payments/paypal/status' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const auth = this.authService.authorize(user, 'VIEW_PAYPAL_STATUS');
        if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        const paypal = PayPalAdapter.getInstance();
        const info = paypal.getMaskedCredentialsInfo();
        return { status: 200, data: info, timestamp };
      }
      if (path === '/api/payments/paypal/test' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const auth = this.authService.authorize(user, 'MANAGE_PAYPAL');
        if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        const { client_id, client_secret, environment } = payload || {};
        const paypal = PayPalAdapter.getInstance();
        const res = await paypal.testLiveCredentials(client_id, client_secret, environment);
        return { status: 200, data: res, timestamp };
      }
      if (path === '/api/payments/paypal/configure' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const auth = this.authService.authorize(user, 'MANAGE_PAYPAL');
        if (!auth.authorized) return { status: 403, error: auth.reason, timestamp };
        const { client_id, client_secret, environment = 'sandbox' } = payload || {};
        if (!client_id || !client_secret) return { status: 400, error: 'client_id and client_secret required', timestamp };
        const paypal = PayPalAdapter.getInstance();
        const configured = paypal.setSessionCredentials(client_id, client_secret, environment);
        if (!configured) return { status: 403, error: 'Production PayPal credentials are deployment-authoritative and cannot be overridden at runtime.', timestamp };
        return { status: 200, data: { success: true, message: 'PayPal credentials updated in active session.' }, timestamp };
      }

      // 12. /api/deployments
      if (path === '/api/deployments' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const deployments = this.sqlite.findTenantRecords('deployments', targetTenant);
        return { status: 200, data: deployments, timestamp };
      }

      // 13. /api/telemetry
      if (path === '/api/telemetry' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const telemetry = this.sqlite.findTenantRecords('telemetry', targetTenant, 50);
        return { status: 200, data: telemetry, timestamp };
      }

      // 14. /api/audit
      if (path === '/api/audit' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const targetTenant = user.tenant_id;
        const records = this.sqlite.findTenantRecords('audit_records', targetTenant, 50);
        return { status: 200, data: records, timestamp };
      }

      // 15. /api/audit/chain
      if (path === '/api/audit/chain' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform audit chain is restricted to PLATFORM_ADMIN', timestamp };
        const verification = this.durableStore.verifyChain();
        return {
          status: 200,
          data: {
            valid: verification.valid,
            total_records: verification.total_records,
            chain: this.durableStore.getState().audit_chain
          },
          timestamp
        };
      }
      if (path === '/api/audit/chain/verify' && method === 'POST') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform audit chain is restricted to PLATFORM_ADMIN', timestamp };
        const verification = this.durableStore.verifyChain();
        return { status: 200, data: verification, timestamp };
      }

      // 16. /api/rollback
      if (path === '/api/rollback' && method === 'POST') {
        if (!user || user.role !== 'PLATFORM_ADMIN') {
          return { status: 403, error: 'Forbidden: rollback is restricted to PLATFORM_ADMIN', timestamp };
        }
        const { checkpoint_id, reason = 'Operator triggered rollback' } = payload || {};
        if (!checkpoint_id) return { status: 400, error: 'checkpoint_id required', timestamp };
        const engine = ReversibilityEngine.getInstance();
        const res = engine.executeRollback(checkpoint_id, reason);
        if (!res.success) return { status: 400, error: res.error, timestamp };
        return { status: 200, data: res, timestamp };
      }

      // 17. /api/nodes
      if (path === '/api/nodes' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        const nodes = NodeRegistry.getInstance().getAllNodes();
        return { status: 200, data: nodes, timestamp };
      }

      // 18. /api/adapters
      if (path === '/api/adapters' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        const inventory = ExternalAdapterRegistry.getInventory();
        return { status: 200, data: inventory, timestamp };
      }

      // 19. /api/system/status
      if (path === '/api/system/status' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        const status = SystemStatusService.computeStatus();
        return { status: 200, data: status, timestamp };
      }

      // 20. /api/system/health
      if (path === '/api/system/health' && method === 'GET') {
        return { status: 200, data: { status: 'HEALTHY' }, timestamp };
      }

      // 21. /api/system/readiness
      if (path === '/api/system/readiness' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        const nodes = NodeRegistry.getInstance().getAllNodes();
        const executed = nodes.filter(n => n.execution_mode === 'CODE_EXECUTED').length;
        const ready = executed > 0;
        return {
          status: 200,
          data: {
            ready,
            nodes_active: executed,
            sandbox_status: 'DETERMINISTIC_SANDBOX_READY'
          },
          timestamp
        };
      }

      // 22. /api/brain/state
      if (path === '/api/brain/state' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        const brain = DaisyBrain.getInstance();
        return { status: 200, data: brain.getLiveBrainState(), timestamp };
      }

      // 23. /api/kernel/* — single Pipeline Kernel (user-space supervisor of 54 real OS processes)
      if (path === '/api/kernel/status' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        if (user.role !== 'PLATFORM_ADMIN') return { status: 403, error: 'Forbidden: platform status access restricted', timestamp };
        return { status: 200, data: PipelineKernel.getInstance().getStatus(), timestamp };
      }
      if (path === '/api/kernel/reboot' && method === 'POST') {
        if (!user || !['PLATFORM_ADMIN', 'OWNER', 'ADMIN'].includes(user.role)) {
          return { status: 403, error: 'Forbidden: kernel reboot requires OWNER/ADMIN', timestamp };
        }
        const status = await PipelineKernel.getInstance().reboot();
        return { status: 200, data: { ok: true, status }, timestamp };
      }

      // 24. /api/grid/nodes — registry joined with LIVE process state from the kernel
      if (path === '/api/grid/nodes' && method === 'GET') {
        const kernel = PipelineKernel.getInstance();
        const live = kernel.getState() === 'running' ? kernel.listNodes() : [];
        const byId = new Map(live.map((n: any) => [n.id, n]));
        const merged = NodeRegistry.getInstance().getAllNodes().map((r) => {
          const l: any = byId.get(r.id);
          const online = l?.status === 'online';
          return {
            id: r.id,
            name: r.name,
            category: r.category,
            purpose: r.purpose,
            execution_mode: r.execution_mode,
            status: l?.status ?? 'offline',
            pid: l?.pid ?? null,
            port: l?.port ?? null,
            healthOk: l?.healthOk ?? false,
            restarts: l?.restarts ?? 0,
            latency: 0, // not measured by the kernel yet; do not fabricate
            utilization: 0, // not measured; do not fabricate
            cryptHealth: online && l?.healthOk ? 100 : 0,
            lastPing: l?.lastHealthAt ?? null,
            jobType: r.category,
          };
        });
        return { status: 200, data: merged, timestamp };
      }
      const gridAction = path.match(/^\/api\/grid\/nodes\/([^/]+)\/(reboot|diagnostic)$/);
      if (gridAction && method === 'POST') {
        const id = decodeURIComponent(gridAction[1]);
        if (!NodeRegistry.getInstance().getNode(id)) {
          return { status: 404, error: `Unknown node ${id}`, timestamp };
        }
        const kernel = PipelineKernel.getInstance();
        if (!user) return { status: 401, error: 'Unauthorized: node actions require a bearer token', timestamp };
        if (gridAction[2] === 'reboot') {
          if (!['PLATFORM_ADMIN', 'OWNER', 'ADMIN'].includes(user.role)) {
            return { status: 403, error: 'Forbidden: node reboot requires PLATFORM_ADMIN/OWNER/ADMIN', timestamp };
          }
          const info: any = await kernel.rebootNode(id);
          return { status: 200, data: { ok: true, info, message: `Kernel killed and respawned process for ${id} (new pid=${info.pid}).` }, timestamp };
        }
        const result: any = await kernel.diagnosticNode(id);
        return { status: 200, data: { ...result, detail: result.ok ? `Live health probe OK: ${result.detail}` : `Health probe FAILED: ${result.detail}` }, timestamp };
      }

      // 25. /api/bus/* — real HTTP message bus
      if (path === '/api/bus/recent' && method === 'GET') {
        if (!user) return { status: 401, error: 'Authentication required', timestamp };
        return { status: 200, data: MessageBus.getInstance().getRecent(), timestamp };
      }
      if (path === '/api/bus/publish' && method === 'POST') {
        if (!user) return { status: 401, error: 'Unauthorized', timestamp };
        const b = payload || {};
        await MessageBus.getInstance().publish(b.topic || 'default', b.from || user.email || 'api', b.payload ?? {});
        return { status: 200, data: { ok: true }, timestamp };
      }

      return { status: 404, error: `Endpoint ${method} ${path} not found in Sovereign API router`, timestamp };
    } catch (e: any) {
      return { status: 500, error: e.message || 'Internal Server Error', timestamp };
    }
  }

  // HTTP Connect/Vite/Express middleware handler
  public handleHttpRequest(req: any, res: any): void {
    const url = new URL(req.originalUrl || req.url, `http://${req.headers?.host || 'localhost'}`);
    const pathname = url.pathname;
    const method = req.method as any;
    let bodyData = '';
    const MAX_BODY_BYTES = 1024 * 1024;
    let bodyBytes = 0;
    let rejected = false;
    const declaredLength = Number(req.headers?.['content-length'] || 0);
    if (Number.isFinite(declaredLength) && declaredLength > MAX_BODY_BYTES) {
      res.writeHead(413, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Request body too large', status: 413 }));
      return;
    }

    req.on('data', (chunk: any) => {
      if (rejected) return;
      const size = Buffer.isBuffer(chunk) ? chunk.length : Buffer.byteLength(String(chunk));
      bodyBytes += size;
      if (bodyBytes > MAX_BODY_BYTES) {
        rejected = true;
        res.writeHead(413, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Request body too large', status: 413 }));
        req.destroy();
        return;
      }
      bodyData += chunk;
    });
    req.on('end', async () => {
      if (rejected) return;
      let payload: any = undefined;
      if (bodyData) {
        try { payload = JSON.parse(bodyData); } catch (e) {}
      }
      const response = await this.handleRequest(pathname, method, payload, req.headers || {});
      res.writeHead(response.status, {
        'Content-Type': 'application/json',
        'X-Sovereign-Version': '1.0.0-PROD',
        'X-Sovereign-Audit-Hash': this.durableStore.getState().audit_chain.slice(-1)[0]?.record_hash || '0'.repeat(64)
      });
      res.end(JSON.stringify(response.data || { error: response.error, status: response.status }));
    });
  }
}
