/**
 * Solvex Pipeline Kernel (single)
 *
 * One user-space supervisor that owns:
 *  - 54 real OS child processes (nodes)
 *  - HTTP message bus
 *  - boot / halt / reboot of the pipeline
 *  - health aggregation
 *
 * This is the single kernel of the Solvex system — not a host OS kernel.
 */
import { NodeProcessManager } from '../runtime/NodeProcessManager.ts';
import { MessageBus } from '../bus/MessageBus.ts';
import { NodeRegistry } from '../nodes/NodeRegistry.ts';

export type KernelState = 'halted' | 'booting' | 'running' | 'halting' | 'error';

export interface KernelStatus {
  state: KernelState;
  bootedAt: number | null;
  uptimeMs: number;
  nodes: { total: number; online: number; offline: number; crashed: number; rebooting: number };
  busPort: number;
  version: string;
  kind: 'pipeline-kernel';
  hostOs: string;
}

export class PipelineKernel {
  private static instance: PipelineKernel | null = null;
  private state: KernelState = 'halted';
  private bootedAt: number | null = null;
  private lastError: string | null = null;
  private readonly version = '1.0.0';
  private readonly busPort = 40999;

  private constructor() {}

  static getInstance(): PipelineKernel {
    if (!PipelineKernel.instance) {
      PipelineKernel.instance = new PipelineKernel();
    }
    return PipelineKernel.instance;
  }

  getState(): KernelState {
    return this.state;
  }

  getStatus(): KernelStatus {
    const mgr = NodeProcessManager.getInstance();
    const summary = this.state === 'halted'
      ? { total: NodeRegistry.getInstance().getAllNodes().length, online: 0, offline: 0, crashed: 0, rebooting: 0 }
      : mgr.summary();

    return {
      state: this.state,
      bootedAt: this.bootedAt,
      uptimeMs: this.bootedAt ? Date.now() - this.bootedAt : 0,
      nodes: summary,
      busPort: this.busPort,
      version: this.version,
      kind: 'pipeline-kernel',
      hostOs: process.platform,
    };
  }

  /** Boot the single pipeline kernel: bus + all node processes */
  async boot(): Promise<KernelStatus> {
    if (this.state === 'running' || this.state === 'booting') {
      return this.getStatus();
    }
    this.state = 'booting';
    this.lastError = null;
    try {
      const bus = MessageBus.getInstance();
      await bus.start(this.busPort);

      const mgr = NodeProcessManager.getInstance();
      await mgr.startAll();

      this.bootedAt = Date.now();
      this.state = 'running';

      await bus.publish('kernel', 'pipeline-kernel', {
        event: 'boot_complete',
        status: this.getStatus(),
      });

      return this.getStatus();
    } catch (e: any) {
      this.state = 'error';
      this.lastError = String(e?.message || e);
      throw e;
    }
  }

  /** Halt: stop all node processes and the bus */
  async halt(): Promise<KernelStatus> {
    if (this.state === 'halted') return this.getStatus();
    this.state = 'halting';
    try {
      await NodeProcessManager.getInstance().stopAll();
      await MessageBus.getInstance().stop();
    } finally {
      this.state = 'halted';
      this.bootedAt = null;
    }
    return this.getStatus();
  }

  /** Full pipeline reboot: halt then boot */
  async reboot(): Promise<KernelStatus> {
    await this.halt();
    return this.boot();
  }

  /** Reboot a single node process through the kernel */
  async rebootNode(id: string) {
    this.ensureRunning();
    const info = await NodeProcessManager.getInstance().reboot(id);
    await MessageBus.getInstance().publish('kernel.node', 'pipeline-kernel', {
      event: 'node_reboot',
      id,
      info,
    });
    return info;
  }

  /** Live diagnostic of a single node process */
  async diagnosticNode(id: string) {
    this.ensureRunning();
    const result = await NodeProcessManager.getInstance().diagnostic(id);
    await MessageBus.getInstance().publish('kernel.node', 'pipeline-kernel', {
      event: 'node_diagnostic',
      id,
      result,
    });
    return result;
  }

  listNodes() {
    this.ensureRunning();
    return NodeProcessManager.getInstance().list();
  }

  private ensureRunning(): void {
    if (this.state !== 'running') {
      throw new Error(`Pipeline kernel is ${this.state}; boot required`);
    }
  }
}
