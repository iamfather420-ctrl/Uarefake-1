import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { NeonStore } from '../database/NeonPersistence';

export type SovereignRole = 'PLATFORM_ADMIN' | 'OWNER' | 'ADMIN' | 'VERIFIER' | 'CUSTOMER';

export interface UserContext {
  user_id: string;
  tenant_id: string;
  email: string;
  role: SovereignRole;
  issued_at: number;
  expires_at: number;
}

interface AuthUser extends UserContext { password_hash: string; }
type TokenPayload = UserContext & { jti: string };


export class AuthService {
  private static instance: AuthService | null = null;
  private readonly secret: string;
  private readonly ttlMs = 15 * 60 * 1000;
  private readonly revokedTokens = new Set<string>();
  private readonly maxLoginFailures = 8;
  private readonly loginFailures = new Map<string, { count: number; resetAt: number }>();
  private readonly revocationFile = process.env.SOLVEX_REVOCATION_FILE || path.resolve('.sovereign_data', 'revoked_tokens.json');

  private constructor() {
    this.secret = process.env.SOLVEX_AUTH_SECRET || '';
    this.loadRevocations();
    if (process.env.NODE_ENV === 'production') {
      if (this.secret.length < 32) throw new Error('SOLVEX_AUTH_SECRET must be configured with at least 32 characters in production');
      if (!process.env.NEON_DATABASE_URL) throw new Error('NEON_DATABASE_URL is required in production for distributed authentication state');
    }
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) AuthService.instance = new AuthService();
    return AuthService.instance;
  }

  private loadRevocations(): void {
    try {
      if (fs.existsSync(this.revocationFile)) {
        const raw = JSON.parse(fs.readFileSync(this.revocationFile, 'utf8'));
        if (Array.isArray(raw)) raw.filter((v): v is string => typeof v === 'string').forEach(v => this.revokedTokens.add(v));
      }
    } catch {}
  }

  private persistRevocations(): void {
    try {
      fs.mkdirSync(path.dirname(this.revocationFile), { recursive: true });
      const tmp = `${this.revocationFile}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(Array.from(this.revokedTokens)), { mode: 0o600 });
      fs.renameSync(tmp, this.revocationFile);
    } catch {}
  }

  private signingSecret(): string {
    if (this.secret) return this.secret;
    return 'development-only-secret-change-me';
  }

  private sign(payloadB64: string): string {
    return crypto.createHmac('sha256', this.signingSecret()).update(payloadB64).digest('hex');
  }

  private encode(payload: object): string {
    return Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  }

  private decode<T>(value: string): T {
    return JSON.parse(Buffer.from(value, 'base64url').toString('utf8')) as T;
  }

  public hashPassword(password: string): string {
    if (typeof password !== 'string' || password.length < 12) throw new Error('Password must contain at least 12 characters');
    const salt = crypto.randomBytes(16);
    const N = 16384, r = 8, p = 1, keylen = 64;
    const digest = crypto.scryptSync(password, salt, keylen, { N, r, p, maxmem: 64 * 1024 * 1024 });
    return `scrypt$${N}$${r}$${p}$${salt.toString('base64url')}$${digest.toString('base64url')}`;
  }

  private verifyPassword(password: string, encoded: string): boolean {
    try {
      const [scheme, nRaw, rRaw, pRaw, saltRaw, digestRaw] = encoded.split('$');
      if (scheme !== 'scrypt' || !nRaw || !rRaw || !pRaw || !saltRaw || !digestRaw) return false;
      const N = Number(nRaw), r = Number(rRaw), p = Number(pRaw);
      if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p)) return false;
      const salt = Buffer.from(saltRaw, 'base64url');
      const expected = Buffer.from(digestRaw, 'base64url');
      const actual = crypto.scryptSync(password, salt, expected.length, { N, r, p, maxmem: 64 * 1024 * 1024 });
      return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
    } catch { return false; }
  }

  private loginAllowed(email: string): boolean {
    const now = Date.now();
    const entry = this.loginFailures.get(email);
    if (!entry || now >= entry.resetAt) { this.loginFailures.delete(email); return true; }
    return entry.count < this.maxLoginFailures;
  }

  private recordLoginFailure(email: string): void {
    const now = Date.now();
    const entry = this.loginFailures.get(email);
    if (!entry || now >= entry.resetAt) this.loginFailures.set(email, { count: 1, resetAt: now + 15 * 60 * 1000 });
    else entry.count += 1;
  }

  private clearLoginFailures(email: string): void { this.loginFailures.delete(email); }

  private configuredUsers(): AuthUser[] {
    const raw = process.env.SOLVEX_AUTH_USERS_JSON;
    if (!raw) return [];
    try {
      const users = JSON.parse(raw);
      if (!Array.isArray(users)) return [];
      return users.filter((u) => u && typeof u.email === 'string' && typeof u.password_hash === 'string' && u.tenant_id && u.role);
    } catch {
      return [];
    }
  }

  public authenticate(email: string, password: string): UserContext | null {
    const normalized = email.trim().toLowerCase();
    if (!this.loginAllowed(normalized)) return null;
    const user = this.configuredUsers().find((u) => u.email.toLowerCase() === normalized);
    if (!user || !this.verifyPassword(password, user.password_hash)) { this.recordLoginFailure(normalized); return null; }
    this.clearLoginFailures(normalized);
    const { password_hash: _password, ...safe } = user;
    return safe;
  }

  public async authenticateDistributed(email: string, password: string): Promise<UserContext | null> {
    const normalized = email.trim().toLowerCase();
    const neon = NeonStore.getInstance();
    if (neon.isConfigured()) {
      if (!(await neon.connect()) || !(await neon.ensureAuthStateTables())) return null;
      const failures = await neon.consumeLoginFailure(normalized);
      if (failures === null || failures > this.maxLoginFailures) return null;
      const user = this.configuredUsers().find((u) => u.email.toLowerCase() === normalized);
      if (!user || !this.verifyPassword(password, user.password_hash)) return null;
      await neon.clearLoginFailure(normalized);
      const { password_hash: _password, ...safe } = user;
      return safe;
    }
    return this.authenticate(email, password);
  }

  public async verifyTokenDistributed(token: string): Promise<{ valid: boolean; user?: UserContext; error?: string }> {
    const base = this.verifyToken(token);
    if (!base.valid || !base.user) return base;
    const neon = NeonStore.getInstance();
    if (neon.isConfigured()) {
      if (!(await neon.connect()) || !(await neon.ensureAuthStateTables())) return { valid: false, error: 'Authentication state unavailable' };
      if (await neon.isTokenRevoked((base.user as TokenPayload).jti)) return { valid: false, error: 'Token revoked' };
    }
    return base;
  }

  public async revokeTokenDistributed(token: string): Promise<boolean> {
    this.revokeToken(token);
    const neon = NeonStore.getInstance();
    if (!neon.isConfigured()) return true;
    if (!(await neon.connect()) || !(await neon.ensureAuthStateTables())) return false;
    try {
      const [b64] = token.split('.', 1);
      const payload = this.decode<TokenPayload>(b64);
      return payload.jti ? await neon.revokeToken(payload.jti) : false;
    } catch { return false; }
  }

  public createSignedToken(userId: string, tenantId: string, email: string, role: SovereignRole): string {
    const issuedAt = Date.now();
    const payload: TokenPayload = { user_id: userId, tenant_id: tenantId, email, role, issued_at: issuedAt, expires_at: issuedAt + this.ttlMs, jti: crypto.randomUUID() };
    const b64 = this.encode(payload);
    return `${b64}.${this.sign(b64)}`;
  }

  public createUserToken(user: UserContext): string {
    return this.createSignedToken(user.user_id, user.tenant_id, user.email, user.role);
  }

  public verifyToken(token: string): { valid: boolean; user?: UserContext; error?: string } {
    if (!token || !token.includes('.')) return { valid: false, error: 'Malformed token structure' };
    const [b64, sig] = token.split('.', 2);
    const expected = this.sign(b64);
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return { valid: false, error: 'Invalid token signature' };
    try {
      const user = this.decode<TokenPayload>(b64);
      if (!user.jti || this.revokedTokens.has(user.jti)) return { valid: false, error: 'Token revoked' };
      if (!user.expires_at || Date.now() >= user.expires_at) return { valid: false, error: 'Token expired' };
      if (!user.user_id || !user.tenant_id || !user.email || !user.role) return { valid: false, error: 'Invalid token claims' };
      return { valid: true, user };
    } catch { return { valid: false, error: 'Invalid token payload' }; }
  }

  public revokeToken(token: string): void {
    try { const [b64] = token.split('.', 1); const payload = this.decode<TokenPayload>(b64); if (payload.jti) { this.revokedTokens.add(payload.jti); this.persistRevocations(); } } catch {}
  }

  public authorize(user: UserContext, action: string, targetTenantId?: string): { authorized: boolean; reason?: string } {
    if (targetTenantId && targetTenantId !== user.tenant_id && user.role !== 'PLATFORM_ADMIN') {
      return { authorized: false, reason: `Cross-Tenant Access Violation: ${user.role} cannot access ${targetTenantId}` };
    }
    const roleCaps: Record<string, SovereignRole[]> = {
      DEPLOY_RUNTIME: ['PLATFORM_ADMIN', 'OWNER', 'ADMIN'],
      PUBLISH_OFFER: ['PLATFORM_ADMIN'],
      RUN_PIPELINE: ['PLATFORM_ADMIN', 'OWNER', 'ADMIN', 'VERIFIER'],
      MANAGE_PAYPAL: ['PLATFORM_ADMIN', 'OWNER', 'ADMIN'],
      VIEW_PAYPAL_STATUS: ['PLATFORM_ADMIN', 'OWNER', 'ADMIN'],
      VIEW_TENANTS: ['PLATFORM_ADMIN'],
      CREATE_TENANT: ['PLATFORM_ADMIN']
    };
    const allowed = roleCaps[action];
    if (allowed && !allowed.includes(user.role)) return { authorized: false, reason: `RBAC Violation: Role ${user.role} lacks permission ${action}` };
    return { authorized: true };
  }
}
