import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ShoppingCart,
  Cpu,
  BookOpen,
  Eye,
  Terminal,
  Activity,
  Key,
  CheckCircle2,
  Lock,
  Layers,
  Flame,
  Database,
  Menu,
  ChevronLeft,
  ChevronRight,
  Server,
  CircleDot
} from 'lucide-react';
import { Header } from './components/Header';
import { PayPalHub } from './components/PayPalHub';
import { MarketplaceView } from './components/MarketplaceView';
import { Z3TheoremsView } from './components/Z3TheoremsView';
import { DFRLRegistryView } from './components/DFRLRegistryView';
import { ProofBundlesView } from './components/ProofBundlesView';
import { DaisyBrainView } from './components/DaisyBrainView';
import { AuditLedgerView } from './components/AuditLedgerView';
import { EnterpriseAuditRunner } from './components/EnterpriseAuditRunner';
import type { UserContext } from './auth/AuthService';
import { apiRequest, clearSession, currentUser as fetchCurrentUser, login, logout } from './api/client';

type ActiveTab =
  | 'OVERVIEW'
  | 'PAYPAL'
  | 'MARKETPLACE'
  | 'Z3_PROVER'
  | 'DFRL_88'
  | 'PROOF_VAULT'
  | 'DAISY_BRAIN'
  | 'MERKLE_LEDGER'
  | 'AUDIT_SUITE';

const NAV_ITEMS: Array<{ id: ActiveTab; label: string; icon: React.ReactNode; group: string }> = [
  { id: 'OVERVIEW', label: 'Control Center', icon: <Activity className="w-4 h-4" />, group: 'Workspace' },
  { id: 'MARKETPLACE', label: 'Marketplace', icon: <ShoppingCart className="w-4 h-4" />, group: 'Workspace' },
  { id: 'PAYPAL', label: 'Payment Gateway', icon: <Key className="w-4 h-4" />, group: 'Operations' },
  { id: 'MERKLE_LEDGER', label: 'Audit Ledger', icon: <Layers className="w-4 h-4" />, group: 'Evidence' },
  { id: 'PROOF_VAULT', label: 'Proof Vault', icon: <Eye className="w-4 h-4" />, group: 'Evidence' },
  { id: 'DFRL_88', label: 'DFRL Registry', icon: <BookOpen className="w-4 h-4" />, group: 'Formal Systems' },
  { id: 'Z3_PROVER', label: 'Z3 Prover', icon: <Terminal className="w-4 h-4" />, group: 'Formal Systems' },
  { id: 'DAISY_BRAIN', label: 'dAIsy Brain', icon: <Cpu className="w-4 h-4" />, group: 'Intelligence' },
  { id: 'AUDIT_SUITE', label: 'Audit Suite', icon: <ShieldCheck className="w-4 h-4" />, group: 'Governance' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('OVERVIEW');
  const [currentUser, setCurrentUser] = useState<UserContext | null>(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginBusy, setLoginBusy] = useState(false);
  const [chainValid, setChainValid] = useState(true);
  const [auditHead, setAuditHead] = useState('');
  const [paypalConnected, setPaypalConnected] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    void (async () => {
      try {
        const user = await fetchCurrentUser();
        setCurrentUser(user);
        await refreshSystemStatus(user);
      } catch { clearSession(); }
    })();
  }, []);

  const refreshSystemStatus = async (user?: UserContext) => {
    const effectiveUser = user || currentUser;
    if (effectiveUser?.role === 'PLATFORM_ADMIN') {
      try {
        const chain = await apiRequest<any>('/api/audit/chain');
      setChainValid(Boolean(chain.valid));
      const records = chain.chain || [];
        setAuditHead(records.length ? records[records.length - 1].record_hash : '');
      } catch {}
    }
    try {
      const info = await apiRequest<any>('/api/payments/paypal/status');
      setPaypalConnected(Boolean(info.configured));
    } catch { setPaypalConnected(false); }
  };

  const handleLogin = async (event: React.FormEvent) => {
    event.preventDefault(); setLoginBusy(true); setLoginError(null);
    try { const result = await login(loginEmail, loginPassword); sessionStorage.setItem('solvex_token', result.token); setCurrentUser(result.user); await refreshSystemStatus(result.user); }
    catch (e) { setLoginError(e instanceof Error ? e.message : 'Authentication failed'); }
    finally { setLoginBusy(false); }
  };

  const handleLogout = async () => { try { await logout(); } catch { clearSession(); } setCurrentUser(null); setActiveTab('OVERVIEW'); };

  if (!currentUser) return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
      <form onSubmit={handleLogin} className="w-full max-w-md sx-glass rounded-2xl p-6 space-y-4">
        <div><h1 className="text-xl font-bold">Project AGATE</h1><p className="text-sm text-slate-400 mt-1">Sign in with a server-provisioned SolveX account.</p></div>
        {loginError && <div className="text-sm text-rose-300 bg-rose-950/30 border border-rose-800 rounded-lg p-3">{loginError}</div>}
        <input required type="email" autoComplete="username" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} placeholder="Email" className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm"/>
        <input required type="password" autoComplete="current-password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} placeholder="Password" className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm"/>
        <button disabled={loginBusy} className="w-full rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 p-3 text-sm font-semibold">{loginBusy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </div>
  );

  const activeLabel = NAV_ITEMS.find(item => item.id === activeTab)?.label ?? 'Control Center';
  const groups = [...new Set(NAV_ITEMS.map(item => item.group))];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex sx-app">
      <aside className={`sx-sidebar ${sidebarOpen ? 'sx-sidebar--open' : 'sx-sidebar--collapsed'}`}>
        <div className="sx-sidebar-brand">
          <div className="sx-brand-mark"><span>◆</span></div>
          {sidebarOpen && <div className="min-w-0"><div className="text-sm font-bold tracking-tight">SOLVEX</div><div className="text-[10px] text-slate-500 uppercase tracking-[.18em]">AGATE Core</div></div>}
          <button className="sx-icon-button ml-auto" onClick={() => setSidebarOpen(v => !v)} aria-label={sidebarOpen ? 'Collapse navigation' : 'Expand navigation'}>
            {sidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        <nav className="sx-sidebar-nav sx-scrollbar" aria-label="Primary navigation">
          {groups.map(group => (
            <div key={group} className="sx-nav-group">
              {sidebarOpen && <div className="sx-nav-label">{group}</div>}
              {NAV_ITEMS.filter(item => item.group === group).map(item => (
                <button key={item.id} onClick={() => setActiveTab(item.id)} title={!sidebarOpen ? item.label : undefined}
                  className={`sx-nav-item ${activeTab === item.id ? 'is-active' : ''} ${!sidebarOpen ? 'is-collapsed' : ''}`}>
                  {item.icon}{sidebarOpen && <span>{item.label}</span>}
                  {item.id === 'PAYPAL' && <span className={`sx-nav-dot ${paypalConnected ? 'is-live' : 'is-warn'}`} />}
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="sx-sidebar-footer">
          <div className={`sx-user-chip ${!sidebarOpen ? 'justify-center' : ''}`}>
            <div className="sx-avatar">{(currentUser.email || 'U').slice(0,1).toUpperCase()}</div>
            {sidebarOpen && <div className="min-w-0"><div className="text-xs font-semibold truncate">{currentUser.email}</div><div className="text-[10px] text-slate-500">{currentUser.role}</div></div>}
          </div>
          {sidebarOpen && <button onClick={handleLogout} className="sx-signout">Sign out</button>}
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sx-topbar">
          <div className="flex items-center gap-3 min-w-0">
            <button className="sx-mobile-menu" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu className="w-5 h-5" /></button>
            <div className="min-w-0"><div className="sx-kicker">Sovereign control plane</div><h1 className="text-base sm:text-lg font-semibold truncate">{activeLabel}</h1></div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <span className={`sx-status ${chainValid ? 'sx-status--verified' : 'sx-status--blocked'}`}><span className="sx-status-dot" />{chainValid ? 'Ledger verified' : 'Ledger integrity fault'}</span>
            <span className="hidden sm:inline sx-status sx-status--pending"><Server className="w-3.5 h-3.5" />External providers explicit</span>
          </div>
        </header>

        <main className="flex-1 min-w-0 w-full max-w-[1500px] mx-auto p-4 sm:p-6 lg:p-8">
          {activeTab === 'OVERVIEW' && (
            <div className="space-y-6">
              <section className="sx-hero">
                <div className="relative z-10 max-w-4xl">
                  <div className="flex flex-wrap items-center gap-2 mb-4"><span className="sx-status sx-status--verified"><span className="sx-status-dot" />Evidence-first runtime</span><span className="sx-status">Fail-closed by default</span></div>
                  <h2 className="sx-display">The control plane for <span>verifiable execution.</span></h2>
                  <p className="sx-lede">Solvex brings payments, formal verification, audit evidence, marketplace operations, and AI execution under one observable control surface.</p>
                  <div className="flex flex-wrap gap-3 mt-6">
                    <button onClick={() => setActiveTab('AUDIT_SUITE')} className="sx-primary-button"><ShieldCheck className="w-4 h-4" />Open audit suite</button>
                    <button onClick={() => setActiveTab('PROOF_VAULT')} className="sx-secondary-button"><Eye className="w-4 h-4" />Inspect evidence</button>
                  </div>
                </div>
                <div className="sx-hero-orbit" aria-hidden="true"><div className="sx-orbit-ring sx-orbit-ring--1" /><div className="sx-orbit-ring sx-orbit-ring--2" /><div className="sx-orbit-core"><CircleDot className="w-7 h-7" /></div></div>
              </section>

              <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                <div className="sx-metric-card"><div className="sx-metric-head"><span>Ledger</span><Layers className="w-4 h-4" /></div><strong>{chainValid ? 'VERIFIED' : 'FAULT'}</strong><p>{auditHead ? `Head ${auditHead.slice(0, 12)}…` : 'No chain head exposed'}</p></div>
                <div className="sx-metric-card"><div className="sx-metric-head"><span>Payment rail</span><Key className="w-4 h-4" /></div><strong className={paypalConnected ? 'sx-good' : 'sx-warn'}>{paypalConnected ? 'CONNECTED' : 'FAIL-CLOSED'}</strong><p>{paypalConnected ? 'Provider configuration detected' : 'Provider credentials required'}</p></div>
                <div className="sx-metric-card"><div className="sx-metric-head"><span>Authority</span><ShieldCheck className="w-4 h-4" /></div><strong className="sx-good">ENFORCED</strong><p>Server-side authorization remains authoritative</p></div>
                <div className="sx-metric-card"><div className="sx-metric-head"><span>Execution</span><Cpu className="w-4 h-4" /></div><strong className="sx-cyan">OBSERVABLE</strong><p>Consequential actions expose state and evidence</p></div>
              </section>

              <section className="grid grid-cols-1 xl:grid-cols-[1.25fr_.75fr] gap-5">
                <div className="sx-panel p-5 sm:p-6">
                  <div className="flex items-start justify-between gap-4 mb-5"><div><div className="sx-kicker">System contract</div><h3 className="text-lg font-semibold mt-1">Four boundaries keep execution honest</h3></div><Lock className="w-5 h-5 text-cyan-300" /></div>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {[['01','Capability ≠ authority','Runtime access never becomes permission.'],['02','Authority ≠ authorization','Role and signed authorization are evaluated separately.'],['03','Authorization ≠ execution','Mutation gates must pass before side effects.'],['04','Execution ≠ reversibility','External irreversible actions cannot be falsely rolled back.']].map(([n,t,d]) => <div key={n} className="sx-invariant"><span>{n}</span><div><b>{t}</b><p>{d}</p></div></div>)}
                  </div>
                </div>
                <div className="sx-panel p-5 sm:p-6">
                  <div className="sx-kicker">Live posture</div><h3 className="text-lg font-semibold mt-1 mb-5">What the system knows</h3>
                  <div className="space-y-3">
                    <div className="sx-posture-row"><span>Audit chain</span><span className={chainValid ? 'sx-good' : 'sx-bad'}>{chainValid ? 'Verified' : 'Integrity fault'}</span></div>
                    <div className="sx-posture-row"><span>Payment provider</span><span className={paypalConnected ? 'sx-good' : 'sx-warn'}>{paypalConnected ? 'Configured' : 'Not configured'}</span></div>
                    <div className="sx-posture-row"><span>External evidence</span><span className="sx-warn">Required where applicable</span></div>
                    <div className="sx-posture-row"><span>UI assertions</span><span className="sx-good">Evidence-bound</span></div>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'PAYPAL' && <PayPalHub onCredentialsUpdated={refreshSystemStatus} />}
          {activeTab === 'MARKETPLACE' && <MarketplaceView currentUser={currentUser!} onNavigateToPayPal={() => setActiveTab('PAYPAL')} onNavigateToEvidence={() => setActiveTab('PROOF_VAULT')} />}
          {activeTab === 'Z3_PROVER' && <Z3TheoremsView />}
          {activeTab === 'DFRL_88' && <DFRLRegistryView />}
          {activeTab === 'PROOF_VAULT' && <ProofBundlesView />}
          {activeTab === 'DAISY_BRAIN' && <DaisyBrainView />}
          {activeTab === 'MERKLE_LEDGER' && <AuditLedgerView onChainVerified={refreshSystemStatus} />}
          {activeTab === 'AUDIT_SUITE' && <EnterpriseAuditRunner />}
        </main>

        <footer className="sx-footer"><span>Solvex / AGATE Core</span><span>Fail-closed execution · Evidence-bound UI · External actions explicit</span></footer>
      </div>
    </div>
  );
}
