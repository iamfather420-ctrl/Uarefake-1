import { computeSha256 } from '../database/DatabaseSchema';

export type RiskClass = 'LOW' | 'MEDIUM' | 'HIGH';
export interface DefensiblePriceResult {
  cost_basis_cents: number;
  complexity_factor: number;
  risk_class: RiskClass;
  risk_multiplier: number;
  margin_factor: number;
  final_price_cents: number;
  calculation_hash: string;
}

export function calculateDefensiblePrice(costBasisCents: number, complexityFactor: number, riskClass: RiskClass): DefensiblePriceResult {
  if (!Number.isInteger(costBasisCents) || costBasisCents < 0) throw new Error('costBasisCents must be a non-negative integer');
  if (!Number.isFinite(complexityFactor) || complexityFactor <= 0 || complexityFactor > 100) throw new Error('complexityFactor out of range');
  const riskMultiplier = riskClass === 'LOW' ? 1.10 : riskClass === 'MEDIUM' ? 1.25 : 1.50;
  const marginFactor = 1.35;
  const finalPriceCents = Math.round(costBasisCents * complexityFactor * riskMultiplier * marginFactor);
  const calculationHash = computeSha256(`V1.4:${costBasisCents}:${complexityFactor.toFixed(4)}:${riskClass}:${riskMultiplier}:${marginFactor}:${finalPriceCents}`);
  return { cost_basis_cents: costBasisCents, complexity_factor: complexityFactor, risk_class: riskClass, risk_multiplier: riskMultiplier, margin_factor: marginFactor, final_price_cents: finalPriceCents, calculation_hash: calculationHash };
}
