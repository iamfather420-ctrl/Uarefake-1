import fs from 'node:fs';
import path from 'node:path';
import { inflateRawSync } from 'node:zlib';

export interface ExtractedBinaryPayload {
  packageName: string;
  assetsDir: string;
  sourceFiles: { path: string; content: string }[];
}

const EOCD = 0x06054b50;
const CENTRAL = 0x02014b50;
const LOCAL = 0x04034b50;
const MAX_ENTRY_BYTES = 16 * 1024 * 1024;
const MAX_TOTAL_BYTES = 128 * 1024 * 1024;

function u16(buf: Buffer, off: number) { return buf.readUInt16LE(off); }
function u32(buf: Buffer, off: number) { return buf.readUInt32LE(off); }

function readZipEntries(file: Buffer): Array<{ name: string; data: Buffer }> {
  const minEocd = Math.max(0, file.length - 22 - 65535);
  let eocd = -1;
  for (let i = file.length - 22; i >= minEocd; i--) {
    if (u32(file, i) === EOCD) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Invalid ZIP: end-of-central-directory record not found');

  const entries = u16(file, eocd + 10);
  const centralOffset = u32(file, eocd + 16);
  if (entries > 10000 || centralOffset >= file.length) throw new Error('Invalid ZIP: unsafe central directory');

  const result: Array<{ name: string; data: Buffer }> = [];
  let cursor = centralOffset;
  let total = 0;
  for (let i = 0; i < entries; i++) {
    if (cursor + 46 > file.length || u32(file, cursor) !== CENTRAL) throw new Error('Invalid ZIP: malformed central directory');
    const flags = u16(file, cursor + 8);
    const method = u16(file, cursor + 10);
    const compressedSize = u32(file, cursor + 20);
    const uncompressedSize = u32(file, cursor + 24);
    const nameLen = u16(file, cursor + 28);
    const extraLen = u16(file, cursor + 30);
    const commentLen = u16(file, cursor + 32);
    const localOffset = u32(file, cursor + 42);
    const name = file.subarray(cursor + 46, cursor + 46 + nameLen).toString('utf8');
    cursor += 46 + nameLen + extraLen + commentLen;

    if (flags & 0x1) throw new Error(`Encrypted ZIP entry rejected: ${name}`);
    if (uncompressedSize > MAX_ENTRY_BYTES || total + uncompressedSize > MAX_TOTAL_BYTES) {
      throw new Error(`ZIP extraction size limit exceeded: ${name}`);
    }
    if (localOffset + 30 > file.length || u32(file, localOffset) !== LOCAL) throw new Error(`Invalid ZIP local header: ${name}`);
    const localNameLen = u16(file, localOffset + 26);
    const localExtraLen = u16(file, localOffset + 28);
    const dataStart = localOffset + 30 + localNameLen + localExtraLen;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > file.length) throw new Error(`Invalid ZIP data bounds: ${name}`);

    const compressed = file.subarray(dataStart, dataEnd);
    let data: Buffer;
    if (method === 0) data = Buffer.from(compressed);
    else if (method === 8) data = inflateRawSync(compressed);
    else throw new Error(`Unsupported ZIP compression method ${method}: ${name}`);
    if (data.length !== uncompressedSize) throw new Error(`ZIP size mismatch: ${name}`);
    total += data.length;
    result.push({ name, data });
  }
  return result;
}

/**
 * Ingests a binary package (APK/ZIP container), extracting only supported web assets.
 * Uses Node's built-in ZIP primitives and enforces traversal and decompression-bomb limits.
 */
export async function processBinaryPackage(filePath: string, outputDir: string): Promise<ExtractedBinaryPayload> {
  const zipEntries = readZipEntries(fs.readFileSync(filePath));
  const sourceFiles: { path: string; content: string }[] = [];
  const packageName = 'com.solvex.imported.binary';
  const outputRoot = path.resolve(outputDir);

  fs.mkdirSync(outputRoot, { recursive: true });

  for (const entry of zipEntries) {
    const entryName = entry.name.replaceAll('\\', '/');
    const normalizedTarget = path.resolve(outputRoot, entryName);
    if (!normalizedTarget.startsWith(outputRoot + path.sep) && normalizedTarget !== outputRoot) {
      throw new Error(`Unsafe archive path rejected: ${entryName}`);
    }
    if (entryName.startsWith('assets/') || entryName.endsWith('.js') || entryName.endsWith('.html')) {
      fs.mkdirSync(path.dirname(normalizedTarget), { recursive: true });
      fs.writeFileSync(normalizedTarget, entry.data);
      sourceFiles.push({ path: entryName, content: entry.data.toString('utf8') });
    }
    if (entryName === 'classes.dex') {
      fs.writeFileSync(path.join(outputRoot, 'classes.dex'), entry.data);
    }
  }

  return { packageName, assetsDir: outputRoot, sourceFiles };
}
