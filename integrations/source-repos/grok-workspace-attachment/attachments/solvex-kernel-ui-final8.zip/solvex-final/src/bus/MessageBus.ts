/**
 * Simple real message bus over localhost HTTP.
 * Nodes (or the control plane) can publish events and request-reply.
 * This uses the actual network stack — not in-process function calls.
 */
import { createServer, type Server } from 'node:http';
import { EventEmitter } from 'node:events';

export interface BusMessage {
  id: string;
  topic: string;
  from: string;
  payload: unknown;
  ts: number;
}

type Handler = (msg: BusMessage) => void | Promise<void>;

export class MessageBus extends EventEmitter {
  private static instance: MessageBus | null = null;
  private server: Server | null = null;
  private port = 40999;
  private handlers = new Map<string, Set<Handler>>();
  private recent: BusMessage[] = [];
  private maxRecent = 500;

  static getInstance(): MessageBus {
    if (!MessageBus.instance) MessageBus.instance = new MessageBus();
    return MessageBus.instance;
  }

  async start(port = 40999): Promise<void> {
    this.port = port;
    if (this.server) return;
    this.server = createServer(async (req, res) => {
      if (req.method === 'POST' && req.url === '/publish') {
        const body = await readBody(req);
        try {
          const msg = JSON.parse(body) as BusMessage;
          this.deliver(msg);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true }));
        } catch (e: any) {
          res.writeHead(400);
          res.end(JSON.stringify({ ok: false, error: String(e?.message || e) }));
        }
        return;
      }
      if (req.method === 'GET' && req.url === '/recent') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(this.recent.slice(-100)));
        return;
      }
      if (req.method === 'GET' && req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, port: this.port, recent: this.recent.length }));
        return;
      }
      res.writeHead(404);
      res.end('not found');
    });
    await new Promise<void>((resolve, reject) => {
      this.server!.listen(this.port, '127.0.0.1', () => resolve());
      this.server!.on('error', reject);
    });
  }

  async stop(): Promise<void> {
    if (!this.server) return;
    await new Promise<void>((resolve) => this.server!.close(() => resolve()));
    this.server = null;
  }

  subscribe(topic: string, handler: Handler): () => void {
    if (!this.handlers.has(topic)) this.handlers.set(topic, new Set());
    this.handlers.get(topic)!.add(handler);
    return () => this.handlers.get(topic)?.delete(handler);
  }

  /** Publish via real HTTP to the bus (works cross-process) */
  async publish(topic: string, from: string, payload: unknown): Promise<void> {
    const msg: BusMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      topic,
      from,
      payload,
      ts: Date.now(),
    };
    // Local deliver + HTTP so external processes can also publish
    this.deliver(msg);
    try {
      await fetch(`http://127.0.0.1:${this.port}/publish`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg),
        signal: AbortSignal.timeout(1000),
      });
    } catch {
      // bus may be same process; local deliver already done
    }
  }

  private deliver(msg: BusMessage): void {
    this.recent.push(msg);
    if (this.recent.length > this.maxRecent) this.recent.shift();
    const set = this.handlers.get(msg.topic);
    if (set) for (const h of set) void h(msg);
    this.emit('message', msg);
  }

  getRecent(): BusMessage[] {
    return this.recent.slice();
  }
}

function readBody(req: import('node:http').IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
