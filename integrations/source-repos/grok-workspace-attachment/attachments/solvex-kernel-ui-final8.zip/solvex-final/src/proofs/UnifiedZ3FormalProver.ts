/**
 * PROJECT AGATE / DAISY / SOLVEX
 *
 * LEGACY COMPATIBILITY FACADE
 *
 * The authoritative 32-case DH corpus is owned by DHFormalVerifier and
 * dhAuthoritativeFormalContracts. This class is retained only for API
 * compatibility with older callers. It MUST NOT maintain a second DH corpus.
 */
import { computeSha256 } from '../database/DatabaseSchema';
import { DFRLFormalVerifier } from './DFRLFormalVerifier';
import { DHFormalVerifier } from './DHFormalVerifier';

export interface DH32VerificationResult {
  code: string;
  name: string;
  domain: string;
  canonical_family: string;
  claim: string;
  mathematical_rationale: string;
  expected_result: 'unsat' | 'sat';
  actual_result: 'unsat' | 'sat' | 'unknown' | 'error';
  proved: boolean;
  solver_version: string;
  execution_id: string;
  execution_duration_ms: number;
  error?: string;
  assertion_hash: string;
  certificate_sha256: string;
  timestamp: string;
}

export interface DH32ReplayRecord {
  code: string;
  original_result: 'unsat' | 'sat' | 'unknown' | 'error';
  replay_result: 'unsat' | 'sat' | 'unknown' | 'error';
  replay_match: boolean;
  original_evidence_hash: string;
  replay_evidence_hash: string;
}

export interface Unified120Z3Report {
  timestamp: string;
  solver_version: string;
  total_cases: 120;
  total_proved: number;
  dfrl_88_cases: { total: 88; unsat_proved: number; sat: number; unknown: number; error: number; replays_matched: number; root_hash: string };
  dh_32_cases: { total: 32; proved: number; unsat: number; sat: number; unknown: number; error: number; replays_matched: number; root_hash: string; results: DH32VerificationResult[]; replays: DH32ReplayRecord[] };
  aggregate_120_root_hash: string;
}

export class UnifiedZ3FormalProver {
  private static instance: UnifiedZ3FormalProver | null = null;

  public static getInstance(): UnifiedZ3FormalProver {
    if (!UnifiedZ3FormalProver.instance) UnifiedZ3FormalProver.instance = new UnifiedZ3FormalProver();
    return UnifiedZ3FormalProver.instance;
  }

  /** @deprecated Use DHFormalVerifier directly. This adapter uses the canonical corpus. */
  public async verifyAll32DH() {
    const report = await DHFormalVerifier.getInstance().verifyAll32();
    const results: DH32VerificationResult[] = report.results.map((r: any) => ({
      code: r.case_id,
      name: r.name,
      domain: r.domain,
      canonical_family: r.domain,
      claim: r.statement,
      mathematical_rationale: r.formal_proposition,
      expected_result: r.expected_result,
      actual_result: r.actual_result,
      proved: r.verified,
      solver_version: r.solver_version,
      execution_id: r.execution_id,
      execution_duration_ms: r.duration_ms,
      error: r.error,
      assertion_hash: r.contract_hash,
      certificate_sha256: r.evidence_hash,
      timestamp: r.timestamp
    }));
    const replays: DH32ReplayRecord[] = report.replays.map((r: any) => ({
      code: r.case_id,
      original_result: r.original_result,
      replay_result: r.replay_result,
      replay_match: r.replay_match,
      original_evidence_hash: r.original_evidence_hash,
      replay_evidence_hash: r.replay_evidence_hash
    }));
    return {
      results,
      replays,
      root_hash: report.verification_root_sha256,
      unsat_count: report.unsat_count,
      sat_count: report.sat_count,
      unknown_count: report.unknown_count,
      error_count: report.error_count,
      proved_count: report.expected_result_matches,
      replays_matched: report.replay_matches
    };
  }

  public async runUnified120Verification(existingDhReport?: any): Promise<Unified120Z3Report> {
    const dfrl = await DFRLFormalVerifier.getInstance().verifyAll88();
    const dh = existingDhReport || await this.verifyAll32DH();
    const aggregate = computeSha256(`${dfrl.verification_root_sha256}:${dh.root_hash}`);
    return {
      timestamp: new Date().toISOString(),
      solver_version: 'Microsoft Research Z3 WASM 5.2.0',
      total_cases: 120,
      total_proved: dfrl.unsat_proved_count + dh.proved_count,
      dfrl_88_cases: {
        total: 88,
        unsat_proved: dfrl.unsat_proved_count,
        sat: dfrl.sat_count,
        unknown: dfrl.unknown_count,
        error: dfrl.error_count,
        replays_matched: dfrl.deterministic_replays_matched,
        root_hash: dfrl.verification_root_sha256
      },
      dh_32_cases: {
        total: 32,
        proved: dh.proved_count,
        unsat: dh.unsat_count,
        sat: dh.sat_count,
        unknown: dh.unknown_count,
        error: dh.error_count,
        replays_matched: dh.replays_matched,
        root_hash: dh.root_hash,
        results: dh.results,
        replays: dh.replays
      },
      aggregate_120_root_hash: aggregate
    };
  }
}
