# Merge notes
Base: Full-Build-main-fixed (verification-pipeline corrections). Added from Real-Runtime build: PipelineKernel, MessageBus,
NodeProcess(+Manager), node-worker, honest docs, honest node descriptions.

Fixed
- ApiRouter: added /api/kernel/*, /api/grid/nodes (+reboot, diagnostic), /api/bus/* wired to the real kernel (UI buttons had no backend).
- server.ts: boots kernel before serving, halts on SIGINT/SIGTERM; removed express.json() which would have hung POST bodies (router reads the stream itself).
- NodeGrid: shows the real result of reboot/diagnostic instead of hardcoded "health restored to 100%".
- node-worker: exits if its supervisor dies (found by test: crashed supervisor left 54 orphan processes holding ports).
- daisy-ai-os: rebuilt. Gate computed from live kernel state (was hardcoded ACTIVE); tools real (were canned); permissions table-driven
  with token auth (was subject==="daisy"); missing ApiRouter/UnifiedDaisyAIOS/UI/scripts written; LLM tool-loop agent; same-origin only (no CORS *).
Not done / still your call
- Verification artifacts in artifacts/ are NOT regenerated; run verify:* in a networked environment with deps installed.
- Latency/utilization are reported as 0 (not measured) rather than invented. Other UI panels may still use sample data (src/data.ts).
- Root /api/grid/* routes are unauthenticated, as before; the shell's own API requires the operator token.

## Bootable kernel
`machine-os/` is a minimal Multiboot i386 kernel: VGA/serial console, IDT/PIC/100 Hz PIT, preemptive kernel tasks,
Multiboot-backed physical allocator + heap, RTL8139 ARP/IPv4/ICMP. It does not host the AI shell or the 54 nodes
(`nodes` reports 0/54 native). See `machine-os/README.md`. `make test` (host shell tests + ELF structural checks) passes;
the QEMU boot test (`make qemu-test`) must be run where qemu-system-i386 is installed.

(Earlier revisions of this file said the kernel was never booted and that artifacts were not regenerated; both are superseded —
see CHANGES_REMEDIATION.md for the current state.)
